"""GameMarket v4 systems: reviews, support, dev contacts, XP, points, ranks, shops, achievements, profile.

Preserves all existing behavior. Rank set is FIXED to none/bronze/silver/gold (no platinum).
Stores are FIXED to normal/pro/promax (no VIP).
"""
import json
import time
from datetime import datetime, timezone

RANKS = ("none", "bronze", "silver", "gold")
STORES = ("normal", "pro", "promax")
STORE_MIN_RANK = {"normal": "none", "pro": "silver", "promax": "gold"}
_RANK_ORDER = {r: i for i, r in enumerate(RANKS)}
XP_PER_LEVEL = 100  # each level needs 100 XP (extensible: change one constant)

DEFAULT_THRESHOLDS = {"bronze": 50, "silver": 100, "gold": 200}


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sentiment_of(stars):
    try:
        s = float(stars)
    except Exception:
        s = 0
    return "positive" if s >= 2.5 else "negative"


def valid_stars(s):
    try:
        v = float(s)
    except Exception:
        return None
    if not (0.5 <= v <= 5):
        return None
    if round(v * 2) != v * 2:  # only whole or .5 steps
        return None
    return v


def thresholds(get_setting):
    out = {}
    for r in ("bronze", "silver", "gold"):
        try:
            out[r] = max(1, int(get_setting("rank_" + r, str(DEFAULT_THRESHOLDS[r])) or DEFAULT_THRESHOLDS[r]))
        except Exception:
            out[r] = DEFAULT_THRESHOLDS[r]
    # keep strictly increasing so upgrades are always sequential
    out["silver"] = max(out["silver"], out["bronze"] + 1)
    out["gold"] = max(out["gold"], out["silver"] + 1)
    return out


def rank_for_total(total, th):
    if total >= th["gold"]:
        return "gold"
    if total >= th["silver"]:
        return "silver"
    if total >= th["bronze"]:
        return "bronze"
    return "none"


def level_for_xp(xp):
    xp = max(0, int(xp))
    lvl = xp // XP_PER_LEVEL + 1
    cur = (xp % XP_PER_LEVEL)
    return lvl, cur, XP_PER_LEVEL


def ensure_progress(c, uid):
    row = c.execute("SELECT * FROM player_progress WHERE user_id=?", (uid,)).fetchone()
    if not row:
        c.execute("INSERT OR IGNORE INTO player_progress(user_id,xp,level,points_total,points_balance,rank) VALUES(?,0,1,0,0,'none')", (uid,))
        row = c.execute("SELECT * FROM player_progress WHERE user_id=?", (uid,)).fetchone()
    return row


def add_xp(c, uid, amount, reason):
    amount = int(amount)
    if amount <= 0:
        return None
    ensure_progress(c, uid)
    ts = now()
    c.execute("INSERT INTO xp_events(user_id,amount,reason,created_at) VALUES(?,?,?,?)", (uid, amount, reason[:200], ts))
    c.execute("UPDATE player_progress SET xp=xp+? WHERE user_id=?", (amount, uid))
    row = c.execute("SELECT xp FROM player_progress WHERE user_id=?", (uid,)).fetchone()
    lvl, _, _ = level_for_xp(row["xp"])
    c.execute("UPDATE player_progress SET level=? WHERE user_id=?", (lvl, uid))
    return lvl


def add_points(c, uid, amount, reason):
    amount = int(amount)
    if amount <= 0:
        return None
    ensure_progress(c, uid)
    ts = now()
    c.execute("INSERT INTO points_events(user_id,amount,kind,reason,created_at) VALUES(?,?,'earn',?,?)", (uid, amount, reason[:200], ts))
    c.execute("UPDATE player_progress SET points_total=points_total+?, points_balance=points_balance+? WHERE user_id=?", (amount, amount, uid))
    return maybe_promote(c, uid, None)


def db_thresholds(c):
    """Rank thresholds from the settings table (admin-configurable), falling back to the defaults."""
    vals = {r["key"]: r["value"] for r in c.execute(
        "SELECT key, value FROM settings WHERE key IN ('rank_bronze','rank_silver','rank_gold')").fetchall()}
    return thresholds(lambda k, d="": vals.get(k, d))


def maybe_promote(c, uid, get_setting=None):
    """Sequential auto-promotion on LIFETIME total. Never demotes. Every caller uses the same thresholds
    (settings table) so admin changes apply everywhere. Returns (rank, newly_promoted)."""
    ensure_progress(c, uid)
    row = c.execute("SELECT points_total, rank FROM player_progress WHERE user_id=?", (uid,)).fetchone()
    total, cur = row["points_total"], row["rank"]
    th = thresholds(get_setting) if get_setting else db_thresholds(c)
    target = rank_for_total(total, th)
    if _RANK_ORDER[target] <= _RANK_ORDER.get(cur, 0):
        return cur, False
    promoted = False
    for r in ("bronze", "silver", "gold"):
        if _RANK_ORDER[r] > _RANK_ORDER.get(cur, 0) and _RANK_ORDER[r] <= _RANK_ORDER[target]:
            c.execute("UPDATE player_progress SET rank=? WHERE user_id=?", (r, uid))
            c.execute("INSERT INTO rank_history(user_id,rank,created_at) VALUES(?,?,?)", (uid, r, now()))
            grant_rank_bonus(c, uid, r)
            cur = r
            promoted = True
    return cur, promoted


def grant_rank_bonus(c, uid, rank):
    """One-time reward for reaching a rank the first time. Goes to the SPENDABLE balance only and does NOT
    change the lifetime total, so it can never help reach the next rank. The primary key on rank_rewards
    blocks any second grant for the same rank."""
    if rank not in RANK_BONUS:
        return False
    if c.execute("SELECT 1 FROM rank_rewards WHERE user_id=? AND rank=?", (uid, rank)).fetchone():
        return False
    amount = RANK_BONUS[rank]
    ts = now()
    c.execute("INSERT INTO rank_rewards(user_id,rank,points,granted_at) VALUES(?,?,?,?)", (uid, rank, amount, ts))
    c.execute("UPDATE player_progress SET points_balance=points_balance+? WHERE user_id=?", (amount, uid))
    c.execute("INSERT INTO points_events(user_id,amount,kind,reason,created_at) VALUES(?,?,'earn',?,?)",
              (uid, amount, "rank_bonus:" + rank, ts))
    return True


def rank_meets(rank, min_rank):
    return _RANK_ORDER.get(rank or "none", 0) >= _RANK_ORDER.get(min_rank or "none", 0)


def _parse_ts(v):
    d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def priority_for(rank, created_at, ts=None):
    """Support / developer-request priority. The base level comes from rank: Bronze normal, Silver high,
    Gold highest. Every full 24h of waiting raises the level by one, capped at Gold's level, so no request is
    ignored: after 48h even a Bronze request ties with a fresh Gold request, and the older one is served first."""
    now_dt = _parse_ts(ts or now())
    waited_h = max(0.0, (now_dt - _parse_ts(created_at)).total_seconds() / 3600)
    base = PRIORITY_LEVEL.get(rank or "none", 0)
    level = min(MAX_AGING_LEVEL, base + int(waited_h // 24))
    return {"level": level, "base_level": base, "label": PRIORITY_LABEL[base], "waited_hours": round(waited_h, 1)}


def sort_by_priority(rows):
    """rows: dicts with 'rank' and 'created_at'. Returns copies with a 'priority' field, highest first, then oldest."""
    out = []
    for r in rows:
        d = dict(r)
        d["priority"] = priority_for(d.get("rank"), d["created_at"])
        out.append(d)
    out.sort(key=lambda d: (-d["priority"]["level"], _parse_ts(d["created_at"])))
    return out


def can_access_store(rank, store):
    return _RANK_ORDER.get(rank, 0) >= _RANK_ORDER.get(STORE_MIN_RANK.get(store, "none"), 0)


def progress_json(c, uid, get_setting=None):
    ensure_progress(c, uid)
    p = c.execute("SELECT * FROM player_progress WHERE user_id=?", (uid,)).fetchone()
    lvl, cur, need = level_for_xp(p["xp"])
    ach = c.execute("SELECT a.akey,a.name,a.description,a.xp_reward,a.points_reward,pa.unlocked_at FROM player_achievements pa JOIN achievements a ON a.id=pa.achievement_id WHERE pa.user_id=? ORDER BY pa.unlocked_at", (uid,)).fetchall()
    items = c.execute("SELECT si.id,si.store,si.kind,si.name_ar,si.name_en,si.price,si.css,pi.equipped,pi.acquired_at FROM player_items pi JOIN shop_items si ON si.id=pi.shop_item_id WHERE pi.user_id=? ORDER BY pi.acquired_at", (uid,)).fetchall()
    perks = c.execute("SELECT rank,perk_key,perk_value,description FROM rank_perks ORDER BY rank").fetchall()
    return {
        "xp": p["xp"], "level": lvl, "xp_into_level": cur, "xp_for_level": need,
        "rank": p["rank"], "points_total": p["points_total"], "points_balance": p["points_balance"],
        "achievements": [dict(a) for a in ach],
        "items": [dict(i) for i in items],
        "perks": [dict(x) for x in perks],
    }


SEED_SHOP = [
    ("normal", "frame", "إطار برونزي بسيط", "Simple Bronze Frame", 20, '{"border":"3px solid #cd7f32","border-radius":"12px"}'),
    ("normal", "background", "خلفية ليلية", "Night Background", 30, '{"background":"linear-gradient(135deg,#1a1033,#3b1d5e)"}'),
    ("normal", "badge", "شارة نجم", "Star Badge", 15, '{"badge":"⭐"}'),
    ("normal", "name_color", "لون اسم أزرق", "Blue Name", 25, '{"color":"#4da3ff"}'),
    ("pro", "frame", "إطار فضي لامع", "Shiny Silver Frame", 60, '{"border":"4px solid #c0c0c0","box-shadow":"0 0 12px #c0c0c0"}'),
    ("pro", "badge", "شارة المحترف", "Pro Badge", 50, '{"badge":"💎"}'),
    ("pro", "name_effect", "توهج فضي للاسم", "Silver Name Glow", 70, '{"color":"#e8e8e8","text-shadow":"0 0 8px #c0c0c0"}'),
    ("promax", "frame", "إطار ذهبي ملكي", "Royal Gold Frame", 120, '{"border":"4px solid #ffd700","box-shadow":"0 0 16px #ffd700"}'),
    ("promax", "background", "خلفية ذهبية", "Gold Background", 100, '{"background":"linear-gradient(135deg,#2a1a00,#8a6d00)"}'),
    ("promax", "badge", "شارة الأسطورة", "Legend Badge", 90, '{"badge":"👑"}'),
    ("promax", "name_effect", "توهج ذهبي للاسم", "Gold Name Glow", 110, '{"color":"#ffd700","text-shadow":"0 0 10px #ffd700"}'),
]

SEED_ACHIEVEMENTS = [
    ("first_download", "First Download", "Add your first game to the library", 10, 5),
    ("reviewer", "Reviewer", "Write your first review", 10, 10),
    ("collector_5", "Collector", "Own 5 games", 20, 15),
    ("helper", "Helper", "Contact a developer", 10, 5),
]

RANK_BONUS = {"bronze": 5, "silver": 10, "gold": 20}
PRIORITY_LEVEL = {"none": 0, "bronze": 0, "silver": 1, "gold": 2}
PRIORITY_LABEL = {0: "normal", 1: "high", 2: "highest"}
MAX_AGING_LEVEL = 2
SEED_PERKS = [
    ("bronze", "store_access", "normal", "Access to the Normal store"),
    ("bronze", "profile_badge", "bronze", "Bronze badge next to the name"),
    ("bronze", "profile_frame", "bronze", "Bronze profile frame"),
    ("bronze", "support_priority", "normal", "Normal support and developer-contact priority"),
    ("bronze", "event_access", "open", "Open events (no rank requirement)"),
    ("bronze", "reward_bonus", str(RANK_BONUS["bronze"]), "One-time bonus of %d points on reaching Bronze" % RANK_BONUS["bronze"]),
    ("silver", "store_access", "normal,pro", "Access to Normal + Pro stores"),
    ("silver", "profile_badge", "silver", "Silver badge next to the name"),
    ("silver", "profile_frame", "silver", "Silver profile frame"),
    ("silver", "support_priority", "high", "High support and developer-contact priority"),
    ("silver", "event_access", "open,silver", "Open events and Silver events"),
    ("silver", "reward_bonus", str(RANK_BONUS["silver"]), "One-time bonus of %d points on reaching Silver" % RANK_BONUS["silver"]),
    ("gold", "store_access", "normal,pro,promax", "Access to all three stores"),
    ("gold", "profile_badge", "gold", "Gold badge next to the name"),
    ("gold", "profile_frame", "gold", "Gold profile frame"),
    ("gold", "support_priority", "highest", "Highest support and developer-contact priority"),
    ("gold", "event_access", "open,silver,gold", "Open, Silver and exclusive Gold events"),
    ("gold", "reward_bonus", str(RANK_BONUS["gold"]), "One-time bonus of %d points on reaching Gold" % RANK_BONUS["gold"]),
]


def seed(c):
    ts = now()
    if not c.execute("SELECT 1 FROM shop_items LIMIT 1").fetchone():
        for store, kind, ar, en, price, css in SEED_SHOP:
            c.execute("INSERT INTO shop_items(store,kind,name_ar,name_en,price,css,active,created_at) VALUES(?,?,?,?,?,?,1,?)",
                      (store, kind, ar, en, price, css, ts))
    if not c.execute("SELECT 1 FROM achievements LIMIT 1").fetchone():
        for akey, name, desc, xp, pts in SEED_ACHIEVEMENTS:
            c.execute("INSERT OR IGNORE INTO achievements(akey,name,description,xp_reward,points_reward,active) VALUES(?,?,?,?,?,1)",
                      (akey, name, desc, xp, pts))
    # always upsert-if-missing: adds perks introduced later without touching existing rows
    for rank, k, v, d in SEED_PERKS:
        c.execute("INSERT OR IGNORE INTO rank_perks(rank,perk_key,perk_value,description) VALUES(?,?,?,?)", (rank, k, v, d))


def unlock_achievement(c, uid, akey):
    a = c.execute("SELECT * FROM achievements WHERE akey=? AND active=1", (akey,)).fetchone()
    if not a:
        return False
    if c.execute("SELECT 1 FROM player_achievements WHERE user_id=? AND achievement_id=?", (uid, a["id"])).fetchone():
        return False
    c.execute("INSERT INTO player_achievements(user_id,achievement_id,unlocked_at) VALUES(?,?,?)", (uid, a["id"], now()))
    if a["xp_reward"]:
        add_xp(c, uid, a["xp_reward"], "achievement:" + akey)
    if a["points_reward"]:
        add_points(c, uid, a["points_reward"], "achievement:" + akey)
    return True


def effective_price(c, item_id, base):
    """Price after the item's currently running discount (time-window based; expired discounts simply stop applying).
    Returns (price, discount_info_or_None)."""
    ts = now()
    row = c.execute("SELECT pct, ends_at FROM shop_discounts WHERE item_id=? AND active=1 "
                    "AND starts_at<=? AND ends_at>? ORDER BY pct DESC LIMIT 1", (item_id, ts, ts)).fetchone()
    if not row:
        return int(base), None
    price = int(base) - (int(base) * int(row["pct"])) // 100
    return max(0, price), {"pct": int(row["pct"]), "ends_at": row["ends_at"]}
