#!/bin/bash
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is not installed. Install it once from https://www.python.org/downloads/ and run this file again."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

echo "Installing the required packages - first run only, this can take a minute..."
python3 -m pip install -q -r requirements.txt || { echo "Could not install the packages."; read -n 1 -s -r; exit 1; }

export ADMIN_EMAIL=admin@local.test
export ADMIN_PASSWORD=admin-local-123
export SECRET_KEY=local-test-secret-key-change-me-0123456789
export HOST=127.0.0.1
export PORT=5000

echo ""
echo "=========================================================="
echo " GameMarket is starting at http://127.0.0.1:5000"
echo " Admin login:  admin@local.test  /  admin-local-123"
echo " Admin panel:  http://127.0.0.1:5000/admin"
echo " Keep this window open while you browse. Close it to stop."
echo "=========================================================="
echo ""
(sleep 2 && open http://127.0.0.1:5000) &
python3 app.py
