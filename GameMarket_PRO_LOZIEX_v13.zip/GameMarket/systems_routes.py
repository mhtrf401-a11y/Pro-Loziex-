"""Route registration for GameMarket v4 systems. Imported by app.py (no circular import)."""
import systems_v4 as S


def register(app, *, db, current_user, login_required, body, ApiError, approved_game, get_setting,
             audit, user_json, user_flags_fn=None):
    from flask import jsonify, request, session

    def me_required():
        u = current_user()
        if not u:
            raise ApiError("Please sign in first", 401)
        return u

    def staff():
        from flask import session as _s
        u = current_user()
        return bool(_s.get("owner") or (u and u["role"] == "admin"))

    # ---------------- reviews ----------------
    @app.get("/api/games/<int:gid>/reviews")
    def v4_list_reviews(gid):
        approved_game(gid)
        c = db()
        rows = c.execute("SELECT r.*,u.name AS user_name FROM reviews r JOIN users u ON u.id=r.user_id "
                         "WHERE r.game_id=? ORDER BY r.updated_at DESC LIMIT 100", (gid,)).fetchall()
        return jsonify(reviews=[{"user_id": x["user_id"], "user_name": x["user_name"], "stars": x["stars"],
                                 "review_text": x["review_text"], "sentiment": x["sentiment"],
                                 "created_at": x["created_at"], "updated_at": x["updated_at"]} for x in rows])

    def _upsert_review(gid, stars, text):
        u = me_required()
        r = approved_game(gid)
        if r["dev_id"] == u["id"]:
            raise ApiError("You cannot rate your own game", 403)
        v = S.valid_stars(stars)
        if v is None:
            raise ApiError("Rating must be 0.5-5 in 0.5 steps")
        text = str(text or "")[:2000]
        sent = S.sentiment_of(v)
        ts = S.now()
        c = db()
        is_new = not c.execute("SELECT 1 FROM reviews WHERE user_id=? AND game_id=?", (u["id"], gid)).fetchone()
        c.execute("INSERT INTO reviews(user_id,game_id,stars,review_text,sentiment,created_at,updated_at) VALUES(?,?,?,?,?,?,?) "
                  "ON CONFLICT(user_id,game_id) DO UPDATE SET stars=excluded.stars,review_text=excluded.review_text,"
                  "sentiment=excluded.sentiment,updated_at=excluded.updated_at",
                  (u["id"], gid, v, text, sent, ts, ts))
        # keep legacy ratings table in sync (integer mirror) so old clients/tests keep working
        legacy = int(v) if v == int(v) else int(round(v))
        legacy = max(1, min(5, legacy))
        c.execute("INSERT INTO ratings(user_id,game_id,stars) VALUES(?,?,?) "
                  "ON CONFLICT(user_id,game_id) DO UPDATE SET stars=excluded.stars", (u["id"], gid, legacy))
        S.ensure_progress(c, u["id"])
        if is_new:
            S.add_xp(c, u["id"], 10, "review:game:%d" % gid)
            S.unlock_achievement(c, u["id"], "reviewer")
            # backfill legacy text columns if present
            try:
                c.execute("UPDATE ratings SET review_text=?,updated_at=? WHERE user_id=? AND game_id=?", (text, ts, u["id"], gid))
            except Exception:
                pass
        else:
            try:
                c.execute("UPDATE ratings SET review_text=?,updated_at=? WHERE user_id=? AND game_id=?", (text, ts, u["id"], gid))
            except Exception:
                pass
        c.commit()
        avg = c.execute("SELECT AVG(stars),COUNT(*) FROM reviews WHERE game_id=?", (gid,)).fetchone()
        audit("content", "review_upsert", target=gid, detail="%.1f %s" % (v, sent))
        return jsonify(ok=True, stars=v, sentiment=sent, avg=round(avg[0] or 0, 1), count=avg[1])

    @app.post("/api/games/<int:gid>/review")
    def v4_post_review(gid):
        d = body()
        return _upsert_review(gid, d.get("stars"), d.get("review_text", d.get("text", "")))

    @app.put("/api/games/<int:gid>/review")
    def v4_put_review(gid):
        d = body()
        return _upsert_review(gid, d.get("stars"), d.get("review_text", d.get("text", "")))

    # ---------------- support tickets ----------------
    @app.post("/api/support/tickets")
    def v4_new_ticket():
        u = me_required()
        d = body()
        subject = str(d.get("subject", "")).strip()[:120]
        message = str(d.get("message", "")).strip()[:5000]
        cat = str(d.get("category", "general"))[:40]
        if len(subject) < 3:
            raise ApiError("Subject is too short")
        if len(message) < 5:
            raise ApiError("Message is too short")
        c = db()
        ts = S.now()
        tid = c.insert_id("INSERT INTO support_tickets(user_id,subject,message,category,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                           (u["id"], subject, message, cat, "open", ts, ts))
        c.commit()
        audit("content", "support_ticket", target=tid, detail=subject)
        return jsonify(ok=True, id=tid)

    @app.get("/api/support/tickets")
    def v4_my_tickets():
        u = me_required()
        c = db()
        rows = c.execute("SELECT * FROM support_tickets WHERE user_id=? ORDER BY updated_at DESC", (u["id"],)).fetchall()
        return jsonify(tickets=[dict(x) for x in rows])

    @app.get("/api/support/tickets/<int:tid>")
    def v4_ticket_detail(tid):
        u = me_required()
        c = db()
        t = c.execute("SELECT * FROM support_tickets WHERE id=?", (tid,)).fetchone()
        if not t:
            raise ApiError("Not found", 404)
        if t["user_id"] != u["id"] and not staff():
            raise ApiError("Not allowed", 403)
        reps = c.execute("SELECT * FROM support_replies WHERE ticket_id=? ORDER BY id", (tid,)).fetchall()
        return jsonify(ticket=dict(t), replies=[dict(x) for x in reps])

    @app.post("/api/support/tickets/<int:tid>/reply")
    def v4_ticket_reply(tid):
        u = me_required()
        d = body()
        msg = str(d.get("message", "")).strip()[:5000]
        if len(msg) < 2:
            raise ApiError("Message is too short")
        c = db()
        t = c.execute("SELECT * FROM support_tickets WHERE id=?", (tid,)).fetchone()
        if not t:
            raise ApiError("Not found", 404)
        if not (t["user_id"] == u["id"] or staff()):
            raise ApiError("Not allowed", 403)
        # players may only reply on their own tickets; staff may reply on any
        role = "admin" if staff() else u["role"]
        c.execute("INSERT INTO support_replies(ticket_id,author_id,author_role,message,created_at) VALUES(?,?,?,?,?)",
                  (tid, u["id"], role, msg, S.now()))
        c.execute("UPDATE support_tickets SET status=?,updated_at=? WHERE id=?",
                  ("answered" if staff() else "open", S.now(), tid))
        c.commit()
        return jsonify(ok=True)

    @app.get("/api/admin/support/tickets")
    @login_required("admin")
    def v4_admin_tickets():
        c = db()
        rows = c.execute("SELECT t.*,u.name AS user_name,u.email,p.rank AS rank FROM support_tickets t "
                         "LEFT JOIN users u ON u.id=t.user_id LEFT JOIN player_progress p ON p.user_id=t.user_id "
                         "ORDER BY t.updated_at DESC LIMIT 200").fetchall()
        return jsonify(tickets=S.sort_by_priority([dict(x) for x in rows]))

    # ---------------- dev contacts ----------------
    @app.post("/api/games/<int:gid>/contact")
    def v4_contact_request(gid):
        u = me_required()
        r = approved_game(gid)
        if r["dev_id"] == u["id"]:
            raise ApiError("This is your own game", 400)
        c = db()
        ex = c.execute("SELECT * FROM dev_contacts WHERE game_id=? AND player_id=?", (gid, u["id"])).fetchone()
        if ex and ex["status"] in ("pending", "accepted"):
            return jsonify(ok=True, id=ex["id"], status=ex["status"])
        ts = S.now()
        cid = c.insert_id("INSERT INTO dev_contacts(game_id,player_id,dev_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                           (gid, u["id"], r["dev_id"], "pending", ts, ts))
        c.commit()
        S.unlock_achievement(c, u["id"], "helper")
        try:
            c.commit()
        except Exception:
            pass
        audit("content", "dev_contact_request", target=gid, detail="contact %d" % cid)
        return jsonify(ok=True, id=cid, status="pending")

    @app.get("/api/my/contacts")
    def v4_my_contacts():
        u = me_required()
        c = db()
        rows = c.execute("SELECT dc.*,g.title AS game_title FROM dev_contacts dc JOIN games g ON g.id=dc.game_id "
                         "WHERE dc.player_id=? ORDER BY dc.updated_at DESC", (u["id"],)).fetchall()
        return jsonify(contacts=[dict(x) for x in rows])

    @app.get("/api/dev/contacts")
    @login_required("developer", "admin")
    def v4_dev_inbox():
        u = current_user()
        c = db()
        if u["role"] == "admin" and not session.get("owner"):
            rows = c.execute("SELECT dc.*,p.rank AS rank,g.title AS game_title,u2.name AS player_name FROM dev_contacts dc "
                             "JOIN games g ON g.id=dc.game_id JOIN users u2 ON u2.id=dc.player_id LEFT JOIN player_progress p ON p.user_id=dc.player_id "
                             "ORDER BY dc.updated_at DESC LIMIT 200").fetchall()
        else:
            # a developer sees ONLY conversations for their own games
            rows = c.execute("SELECT dc.*,p.rank AS rank,g.title AS game_title,u2.name AS player_name FROM dev_contacts dc "
                             "JOIN games g ON g.id=dc.game_id JOIN users u2 ON u2.id=dc.player_id LEFT JOIN player_progress p ON p.user_id=dc.player_id "
                             "WHERE dc.dev_id=? ORDER BY dc.updated_at DESC LIMIT 200", (u["id"],)).fetchall()
        return jsonify(contacts=S.sort_by_priority([dict(x) for x in rows]))

    @app.post("/api/dev/contacts/<int:cid>/respond")
    @login_required("developer", "admin")
    def v4_dev_respond(cid):
        u = current_user()
        d = body()
        action = str(d.get("action", "")).lower()
        if action not in ("accept", "reject"):
            raise ApiError("action must be accept or reject")
        c = db()
        ct = c.execute("SELECT * FROM dev_contacts WHERE id=?", (cid,)).fetchone()
        if not ct:
            raise ApiError("Not found", 404)
        if u["role"] != "admin" and ct["dev_id"] != u["id"]:
            raise ApiError("This conversation belongs to another developer", 403)
        ns = "accepted" if action == "accept" else "rejected"
        c.execute("UPDATE dev_contacts SET status=?,updated_at=? WHERE id=?", (ns, S.now(), cid))
        c.commit()
        return jsonify(ok=True, status=ns)

    def _contact_or_403(cid, u):
        c = db()
        ct = c.execute("SELECT * FROM dev_contacts WHERE id=?", (cid,)).fetchone()
        if not ct:
            raise ApiError("Not found", 404)
        allowed = (u["id"] in (ct["player_id"], ct["dev_id"])) or u["role"] == "admin" or session.get("owner")
        if not allowed:
            raise ApiError("Not allowed", 403)
        return ct, c

    @app.get("/api/contacts/<int:cid>/messages")
    def v4_messages(cid):
        u = me_required()
        # developers may only open their own games' chats (admin/owner excepted)
        if u["role"] == "developer":
            ct, c = _contact_or_403(cid, u)
            if ct["dev_id"] != u["id"]:
                raise ApiError("This conversation belongs to another developer", 403)
        else:
            ct, c = _contact_or_403(cid, u)
        if ct["status"] == "pending":
            return jsonify(status=ct["status"], messages=[])
        rows = c.execute("SELECT m.*,u2.name AS sender_name FROM dev_messages m JOIN users u2 ON u2.id=m.sender_id "
                         "WHERE m.contact_id=? ORDER BY m.id LIMIT 500", (cid,)).fetchall()
        return jsonify(status=ct["status"], messages=[dict(x) for x in rows])

    @app.post("/api/contacts/<int:cid>/messages")
    def v4_send_message(cid):
        u = me_required()
        d = body()
        msg = str(d.get("message", "")).strip()[:3000]
        if len(msg) < 1:
            raise ApiError("Empty message")
        if u["role"] == "developer":
            ct, c = _contact_or_403(cid, u)
            if ct["dev_id"] != u["id"]:
                raise ApiError("This conversation belongs to another developer", 403)
        else:
            ct, c = _contact_or_403(cid, u)
        if ct["status"] != "accepted":
            raise ApiError("The developer has not accepted this chat yet", 403)
        c.execute("INSERT INTO dev_messages(contact_id,sender_id,message,created_at) VALUES(?,?,?,?)",
                  (cid, u["id"], msg, S.now()))
        c.execute("UPDATE dev_contacts SET updated_at=? WHERE id=?", (S.now(), cid))
        c.commit()
        return jsonify(ok=True)

    # ---------------- profile / progress ----------------
    @app.get("/api/my/progress")
    def v4_my_progress():
        u = me_required()
        c = db()
        pj = S.progress_json(c, u["id"], lambda k, d="": get_setting(k) or d)
        uj = user_json(u)
        uj.update(rank=pj["rank"], level=pj["level"])
        return jsonify(user=uj, progress=pj)

    @app.get("/api/profile/<int:uid>")
    def v4_public_profile(uid):
        c = db()
        u = c.execute("SELECT id,name,role FROM users WHERE id=? AND active=1", (uid,)).fetchone()
        if not u:
            raise ApiError("Not found", 404)
        pj = S.progress_json(c, uid)
        return jsonify(user={"id": u["id"], "name": u["name"], "role": u["role"],
                             "rank": pj["rank"], "level": pj["level"]}, progress=pj)

    # ---------------- shops ----------------
    @app.get("/api/shop")
    def v4_shop():
        store = (request.args.get("store", "normal") or "normal").lower()
        if store not in S.STORES:
            raise ApiError("Unknown store")
        u = current_user()
        rank = "none"
        if u:
            c = db()
            S.ensure_progress(c, u["id"])
            rank = c.execute("SELECT rank FROM player_progress WHERE user_id=?", (u["id"],)).fetchone()["rank"]
        if not S.can_access_store(rank, store):
            need = {"pro": "Silver", "promax": "Gold"}.get(store, "?")
            raise ApiError("This store needs rank %s. Your rank: %s" % (need, rank), 403)
        c = db()
        rows = c.execute("SELECT * FROM shop_items WHERE store=? AND active=1 ORDER BY price", (store,)).fetchall()
        owned = set()
        if u:
            owned = {x[0] for x in c.execute("SELECT shop_item_id FROM player_items WHERE user_id=?", (u["id"],))}
        items = []
        for x in rows:
            d = dict(x)
            d["owned"] = x["id"] in owned
            d["original_price"] = x["price"]
            d["price"], d["discount"] = S.effective_price(c, x["id"], x["price"])
            items.append(d)
        return jsonify(store=store, rank=rank, items=items)

    @app.post("/api/shop/<int:item_id>/buy")
    def v4_buy(item_id):
        u = me_required()
        c = db()
        it = c.execute("SELECT * FROM shop_items WHERE id=? AND active=1", (item_id,)).fetchone()
        if not it:
            raise ApiError("Item not found", 404)
        S.ensure_progress(c, u["id"])
        p = c.execute("SELECT * FROM player_progress WHERE user_id=?", (u["id"],)).fetchone()
        if not S.can_access_store(p["rank"], it["store"]):
            raise ApiError("Your rank cannot enter this store", 403)
        if c.execute("SELECT 1 FROM player_items WHERE user_id=? AND shop_item_id=?", (u["id"], item_id)).fetchone():
            raise ApiError("You already own this item", 409)
        price, _disc = S.effective_price(c, item_id, it["price"])
        if p["points_balance"] < price:
            raise ApiError("Not enough GameMarket Points", 402)
        c.execute("UPDATE player_progress SET points_balance=points_balance-? WHERE user_id=?", (price, u["id"]))
        c.execute("INSERT INTO points_events(user_id,amount,kind,reason,created_at) VALUES(?,?,'spend',?,?)",
                  (u["id"], price, "shop:item:%d" % item_id, S.now()))
        c.execute("INSERT INTO player_items(user_id,shop_item_id,equipped,acquired_at) VALUES(?,?,0,?)",
                  (u["id"], item_id, S.now()))
        c.commit()
        audit("content", "shop_buy", target=item_id, detail=it["name_en"])
        return jsonify(ok=True)

    @app.post("/api/shop/equip/<int:item_id>")
    def v4_equip(item_id):
        u = me_required()
        c = db()
        own = c.execute("SELECT * FROM player_items WHERE user_id=? AND shop_item_id=?", (u["id"], item_id)).fetchone()
        if not own:
            raise ApiError("You do not own this item", 403)
        it = c.execute("SELECT kind FROM shop_items WHERE id=?", (item_id,)).fetchone()
        # one equipped item per kind (decorative items are separate from rank perks)
        c.execute("UPDATE player_items SET equipped=0 WHERE user_id=? AND shop_item_id IN "
                  "(SELECT id FROM shop_items WHERE kind=?)", (u["id"], it["kind"] if it else ""))
        c.execute("UPDATE player_items SET equipped=1 WHERE user_id=? AND shop_item_id=?", (u["id"], item_id))
        c.commit()
        return jsonify(ok=True)

    # ---------------- admin: points/XP/ranks/shops ----------------
    @app.post("/api/admin/grant")
    @login_required("admin")
    def v4_grant():
        d = body()
        try:
            uid = int(d.get("user_id"))
        except Exception:
            raise ApiError("user_id required")
        c = db()
        if not c.execute("SELECT 1 FROM users WHERE id=?", (uid,)).fetchone():
            raise ApiError("User not found", 404)
        if "xp" in d:
            S.add_xp(c, uid, int(d["xp"]), str(d.get("reason", "admin grant")))
        if "points" in d:
            S.add_points(c, uid, int(d["points"]), str(d.get("reason", "admin grant")))
        rank, promoted = S.maybe_promote(c, uid, lambda k, dd="": get_setting(k) or dd)
        c.commit()
        audit("admin", "grant", target=uid, detail=d.get("reason", ""))
        return jsonify(ok=True, rank=rank, promoted=promoted)

    @app.get("/api/admin/ranks")
    @login_required("admin")
    def v4_ranks():
        return jsonify(thresholds=S.thresholds(lambda k, d="": get_setting(k) or d), ranks=["bronze", "silver", "gold"])

    @app.get("/api/owner/ranks")
    def v4_owner_ranks():
        if not session.get("owner"):
            raise ApiError("Sign in", 401)
        return jsonify(thresholds=S.thresholds(lambda k, d="": get_setting(k) or d), ranks=["bronze", "silver", "gold"])

    @app.get("/api/achievements")
    def v4_ach():
        c = db()
        rows = c.execute("SELECT * FROM achievements WHERE active=1 ORDER BY id").fetchall()
        return jsonify(achievements=[dict(x) for x in rows])

    @app.get("/api/ranks/info")
    def v4_rank_info():
        c = db()
        perks = c.execute("SELECT rank,perk_key,perk_value,description FROM rank_perks ORDER BY rank").fetchall()
        return jsonify(ranks=["bronze", "silver", "gold"],
                       thresholds=S.thresholds(lambda k, d="": get_setting(k) or d),
                       perks=[dict(x) for x in perks], bonuses=S.RANK_BONUS)
