"""Upload scanning.

IMPORTANT: this is NOT a replacement for a real antivirus engine. It provides
  1. an optional ClamAV hook (clamd over TCP or a unix socket) - the only real malware-signature engine here;
  2. built-in structural checks that run everywhere: EICAR test signature, unsafe ZIP paths, zip bombs,
     encrypted entries, script/autorun payloads, double extensions, and APK sanity (manifest + dex).
Result statuses: clean | suspicious | unscanned | infected.
  infected   -> the upload is rejected
  suspicious -> accepted but flagged for the admin/owner (reject instead with SCAN_BLOCK_SUSPICIOUS=1)
  unscanned  -> format cannot be inspected (.7z/.rar) and no ClamAV configured; flagged
"""
import os
import re
import socket
import struct
import zipfile
from pathlib import Path

EICAR = b"X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*"
SCRIPT_EXTS = {".vbs", ".vbe", ".jse", ".wsf", ".hta", ".ps1", ".scr", ".pif", ".lnk", ".cpl", ".reg", ".inf", ".bat", ".cmd"}
EXEC_EXTS = {".exe", ".dll", ".msi", ".com", ".sys"}
DOC_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".txt", ".pdf", ".doc", ".docx", ".mp3", ".mp4", ".zip"}
MAX_UNZIPPED = 3 * 1024 ** 3
SEVERITY = {"clean": 0, "unscanned": 1, "suspicious": 2, "infected": 3}


def worst(a, b):
    a, b = a or "clean", b or "clean"
    return a if SEVERITY.get(a, 0) >= SEVERITY.get(b, 0) else b


def engine_name():
    if os.environ.get("CLAMAV_SOCKET") or os.environ.get("CLAMAV_HOST"):
        return "clamav+builtin"
    return "builtin"


def clamav_scan(path):
    """Stream a file to clamd (INSTREAM). Returns ('clean'|'infected', note) or raises OSError."""
    sock_path, host = os.environ.get("CLAMAV_SOCKET"), os.environ.get("CLAMAV_HOST")
    if sock_path:
        s = socket.socket(socket.AF_UNIX)
        s.settimeout(120)
        s.connect(sock_path)
    elif host:
        s = socket.create_connection((host, int(os.environ.get("CLAMAV_PORT", "3310"))), timeout=120)
    else:
        raise OSError("ClamAV not configured")
    try:
        s.sendall(b"zINSTREAM\0")
        with open(path, "rb") as f:
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                s.sendall(struct.pack(">I", len(chunk)) + chunk)
        s.sendall(struct.pack(">I", 0))
        resp = b""
        while not resp.endswith(b"\0") and len(resp) < 4096:
            part = s.recv(4096)
            if not part:
                break
            resp += part
    finally:
        s.close()
    text = resp.strip(b"\0\n ").decode("utf-8", "replace")
    if text.endswith("OK"):
        return "clean", "ClamAV: clean"
    if text.endswith("FOUND"):
        return "infected", "ClamAV: " + text.replace("stream:", "").replace("FOUND", "").strip()
    raise OSError("ClamAV error: " + text[:120])


def _scan_zip(path, kind):
    status, notes = "clean", []

    def flag(level, msg):
        nonlocal status
        status = worst(status, level)
        if msg not in notes and len(notes) < 8:
            notes.append(msg)

    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        return "infected", ["corrupted or invalid ZIP structure"]
    with z:
        infos = z.infolist()
        total = sum(i.file_size for i in infos)
        comp = sum(i.compress_size for i in infos) or 1
        if total > MAX_UNZIPPED or (total > 200 * 1024 ** 2 and total / comp > 200):
            flag("infected", "zip bomb (unpacked size/ratio is abnormal)")
        names = set()
        execs = []
        for i in infos:
            n = i.filename.replace("\\", "/")
            names.add(n)
            parts = n.split("/")
            if n.startswith("/") or ".." in parts or (len(n) > 1 and n[1] == ":"):
                flag("infected", "unsafe path inside archive")
                continue
            if i.flag_bits & 0x1:
                flag("suspicious", "contains encrypted entries that cannot be scanned")
                continue
            low = n.lower()
            ext = Path(low).suffix
            base = low.rsplit("/", 1)[-1]
            if ext in SCRIPT_EXTS or base == "autorun.inf":
                flag("suspicious", f"script/autorun file: {base}")
            if ext in EXEC_EXTS:
                execs.append(base)
                parts2 = base.split(".")
                if len(parts2) > 2 and "." + parts2[-2] in DOC_EXTS:
                    flag("suspicious", f"double extension disguised executable: {base}")
            if 0 < i.file_size <= 2 * 1024 * 1024 and i.compress_size and ext not in (".png", ".jpg", ".jpeg", ".mp3", ".ogg"):
                try:
                    with z.open(i) as fh:
                        if EICAR in fh.read(2 * 1024 * 1024):
                            flag("infected", f"EICAR test signature in {base}")
                except Exception:
                    flag("suspicious", f"unreadable entry: {base}")
        if execs:
            # Executables are normal in PC game builds, so this is information only, not a flag.
            notes.append(f"{len(execs)} executable file(s) inside (normal for PC builds)")
        if kind == "app":
            if "AndroidManifest.xml" not in names or not any(n.endswith(".dex") for n in names):
                flag("infected", "not a valid APK (AndroidManifest.xml or classes.dex missing)")
            elif not any(n.startswith("META-INF/") and n.endswith((".RSA", ".DSA", ".EC", ".SF")) for n in names):
                flag("suspicious", "APK is not signed (no META-INF signature)")
    return status, notes


def scan_file(path, ext, kind="game"):
    """Scan a staged upload. Returns {'status': ..., 'note': str, 'engine': str}."""
    path = Path(path)
    status, notes, engine = "clean", [], engine_name()
    ext = ext.lower()
    if ext in (".zip", ".apk"):
        s, n = _scan_zip(path, kind)
        status = worst(status, s)
        notes += n
    elif ext in (".7z", ".rar"):
        status = worst(status, "unscanned")
        notes.append("archive format cannot be inspected by the built-in scanner")
    else:                                         # single .html etc.
        with open(path, "rb") as f:
            if EICAR in f.read(2 * 1024 * 1024):
                status = worst(status, "infected")
                notes.append("EICAR test signature")
    if os.environ.get("CLAMAV_SOCKET") or os.environ.get("CLAMAV_HOST"):
        try:
            s, n = clamav_scan(path)
            notes.append(n)
            if s == "infected":
                status = "infected"
            elif status == "unscanned":
                status = "clean"                  # ClamAV did inspect the archive contents
        except OSError as e:
            notes.append(f"ClamAV unavailable ({e}); only built-in checks ran")
    return {"status": status, "note": "; ".join(notes)[:500], "engine": engine}
