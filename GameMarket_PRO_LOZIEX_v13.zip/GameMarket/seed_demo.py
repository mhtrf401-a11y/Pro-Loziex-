"""Optional, LOCAL PREVIEW ONLY: fills the store with a few sample games so you can see
the layout before any real developer has submitted anything.

Usage: python seed_demo.py
This is a development convenience, not a feature of the live site, and it is not meant
to be run against a production database. Demo covers are tiny local placeholder PNGs
(no external network calls), and demo "builds" are tiny placeholder zips.
Remove the demo games later from the admin panel (All games -> Delete) before going live
with real submissions, or simply don't run this script against your production GM_DATA.
"""
import io
import uuid
import zipfile

import app

GAMES = [
    ("Neon Horizon", "PC", "Action", "A fast-paced neon-soaked arena shooter."),
    ("Pixel Warriors", "PC", "Action", "Retro pixel-art brawler with local co-op."),
    ("Cyber Drift", "PC", "Racing", "Arcade drifting through a procedurally lit city."),
    ("Mystic Valley", "PC", "Adventure", "A gentle exploration game about a forgotten valley."),
    ("Shadow Quest", "PC", "RPG", "A short turn-based RPG with a branching story."),
    ("Puzzle Lab", "Web", "Puzzle", "Bite-sized physics puzzles you can finish on a break."),
]

TINY_PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64

c = app.connect()
dev = c.execute("SELECT id FROM users WHERE email='demo@gamemarket.local'").fetchone()
if not dev:
    dev_id = c.insert_id("INSERT INTO users(email,name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                         ("demo@gamemarket.local", "Demo Studio", app.generate_password_hash(uuid.uuid4().hex),
                          "developer", app.now()))
else:
    dev_id = dev["id"]

for title, plat, genre, desc in GAMES:
    if c.execute("SELECT 1 FROM games WHERE title=? AND dev_id=?", (title, dev_id)).fetchone():
        continue
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("README.txt", f"{title} - demo placeholder build.\n")
    build_name = uuid.uuid4().hex + ".zip"
    tmp = app.TMP / build_name
    tmp.write_bytes(buf.getvalue())
    app.storage.put_build(build_name, tmp)
    cover_name = uuid.uuid4().hex + ".png"
    app.storage.put_cover(cover_name, TINY_PNG)
    gid = c.insert_id(
        "INSERT INTO games(dev_id,title,description,platform,genre,cover,build,build_size,status,created_at,reviewed_at)"
        " VALUES(?,?,?,?,?,?,?,?,'approved',?,?)",
        (dev_id, title, desc, plat, genre, cover_name, build_name, len(buf.getvalue()), app.now(), app.now()))
    c.execute("UPDATE games SET slug=? WHERE id=?", (app.make_slug(title, gid), gid))
c.commit()
print("Demo games added. Remember: this is for local preview only, not a real catalog.")
