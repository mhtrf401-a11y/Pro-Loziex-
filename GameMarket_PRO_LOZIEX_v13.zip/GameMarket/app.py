"""GameMarket - free indie games store (Flask + SQLite).

Run:  python app.py
Env:  ADMIN_EMAIL, ADMIN_PASSWORD  (first-run admin account)
      ADMIN_PATH      (URL of the admin panel, default /admin)
      GM_DATA         (data folder: database, uploads, secret key)
      COOKIE_SECURE=1 (set when serving over HTTPS)
      HOST, PORT

Policy: every game on this store is 100% free. There is no payment
gateway, no subscription and no advertising anywhere in this codebase.
"""
import gzip
import hashlib
import hmac
import json
import mimetypes
import os
import re
import secrets
import sys
import tempfile
import threading
import time
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from urllib.parse import urlparse

from flask import (Flask, Response, g, has_request_context, jsonify, redirect, request, send_file,
                   send_from_directory, session)
from itsdangerous import BadSignature, URLSafeSerializer
from markupsafe import escape
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

import database
import scanner
import storage as storage_mod
import totp

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("GM_DATA", BASE / "instance"))
DATA.mkdir(parents=True, exist_ok=True)
TMP = DATA / "tmp"                        # staging area for uploads before they are validated
TMP.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA / "gamemarket.db"          # used only when DATABASE_URL is not set
database.configure(DB_PATH)
storage = storage_mod.make_storage(DATA / "uploads")   # local disk, or S3/R2 when configured

SITE_NAME = "PRO LOZIEX"
GENRES = ["Action", "Adventure", "RPG", "Puzzle", "Racing"]
PLATFORMS = ["PC", "Android", "Web", "Console"]
KINDS = ("game", "app")
APP_CATEGORIES = ["Tools", "Productivity", "Education", "Entertainment", "Social", "Utilities"]
VISIBILITIES = ("public", "hidden", "paused")       # owner-controlled; independent of the review status
VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._+\-]{0,23}$")
YOUTUBE_RE = re.compile(r"^https://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?(?:[^#\s]*&)?v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})(?:[&?#/][^\s]*)?$")
MAX_VERSIONS_PER_GAME = 100
DOWNLOAD_LIMIT_PER_HOUR = int(os.environ.get("DOWNLOAD_LIMIT_PER_HOUR", 30))
BUILD_TYPES = {".zip": b"PK", ".apk": b"PK", ".7z": b"7z\xbc\xaf\x27\x1c", ".rar": b"Rar!"}
MAX_COVER = 3 * 1024 * 1024
MAX_BUILD = 300 * 1024 * 1024
MAX_PENDING_PER_DEV = 10
MAX_SCREENSHOTS = 5

# ---- Browser-playable HTML5 games ("Play Now" + 10-minute trial) ----
PLAY_MODES = ("none", "free", "trial")      # none = download only, free = unlimited in-browser, trial = timed
TRIAL_SECONDS = int(os.environ.get("TRIAL_SECONDS", 10 * 60))
MAX_PLAY = 100 * 1024 * 1024                 # uploaded HTML5 zip
MAX_PLAY_UNZIPPED = 300 * 1024 * 1024
MAX_PLAY_FILES = 3000
PLAY_EXTS = {"", ".html", ".htm", ".js", ".mjs", ".css", ".json", ".map", ".txt", ".xml", ".csv", ".atlas", ".fnt", ".tmx", ".tsx",
             ".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif", ".svg", ".ico", ".bmp",
             ".mp3", ".ogg", ".wav", ".m4a", ".aac", ".opus", ".mp4", ".webm",
             ".woff", ".woff2", ".ttf", ".otf", ".wasm", ".glb", ".gltf", ".bin", ".data", ".unityweb", ".mem", ".dat", ".pck"}
# Optional: serve games from a separate (sub)domain, e.g. https://play.yoursite.com, pointing at this same app.
# Then games get their own origin (localStorage works) and can never touch the store's cookies.
PLAY_ORIGIN = os.environ.get("PLAY_ORIGIN", "").strip().rstrip("/")
PLAY_HOST = urlparse(PLAY_ORIGIN).netloc if PLAY_ORIGIN else ""
PLAY_SANDBOX = "allow-scripts allow-pointer-lock" + (" allow-same-origin" if PLAY_ORIGIN else "")
ADMIN_PATH = "/" + os.environ.get("ADMIN_PATH", "/admin").strip("/")
# Owner dashboard: disabled unless BOTH a secret path and credentials are configured.
OWNER_PATH = "/" + os.environ["OWNER_PATH"].strip("/") if os.environ.get("OWNER_PATH") else None
OWNER_EMAIL = os.environ.get("OWNER_EMAIL", "").strip().lower()
OWNER_PW_HASH = generate_password_hash(os.environ["OWNER_PASSWORD"]) if os.environ.get("OWNER_PASSWORD") else None
OWNER_ENABLED = bool(OWNER_PATH and OWNER_EMAIL and OWNER_PW_HASH)
OWNER_PW_WEAK = len(os.environ.get("OWNER_PASSWORD", "")) < 12      # shown as a warning in the owner dashboard
OWNER_TOTP_SECRET = os.environ.get("OWNER_TOTP_SECRET", "").strip().replace(" ", "")   # optional 2FA (base32)
OWNER_IDLE_SECONDS = 2 * 3600
PROCESS_STARTED = time.time()

app = Flask(__name__, static_folder=str(BASE / "static"), static_url_path="/static")
# Behind Render's proxy every request would otherwise look like it comes from one IP,
# which breaks the login throttle and visitor counting. Only trust the header when told to.
if os.environ.get("TRUST_PROXY") == "1" or os.environ.get("RENDER"):
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
app.config.update(
    MAX_CONTENT_LENGTH=MAX_BUILD + MAX_PLAY + MAX_COVER * (MAX_SCREENSHOTS + 1) + 2 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",
    PERMANENT_SESSION_LIFETIME=14 * 24 * 3600,
    JSON_SORT_KEYS=False,
    SEND_FILE_MAX_AGE_DEFAULT=31536000,
)


def _secret():
    if os.environ.get("SECRET_KEY"):          # set this on hosts with a throw-away disk
        return os.environ["SECRET_KEY"]
    f = DATA / "secret_key"
    if not f.exists():
        f.write_text(secrets.token_hex(32))
        os.chmod(f, 0o600)
    return f.read_text().strip()


app.secret_key = _secret()
play_signer = URLSafeSerializer(app.secret_key, salt="gm-play-session")

# --------------------------------------------------------------------------- db
connect = database.connect
IntegrityErrors = database.IntegrityErrors


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def make_slug(title, gid):
    base = re.sub(r"[^a-z0-9]+", "-", (title or "").lower()).strip("-")[:60]
    return f"{base or 'game'}-{gid}"


def init_db():
    database.init_schema()
    c = connect()
    if not c.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        email = os.environ.get("ADMIN_EMAIL", "admin@gamemarket.local").strip().lower()
        pw = os.environ.get("ADMIN_PASSWORD")
        generated = pw is None
        if generated:
            pw = secrets.token_urlsafe(14)
        try:
            c.execute("INSERT INTO users(email,name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                      (email, "Admin", generate_password_hash(pw), "admin", now()))
            c.commit()
        except IntegrityErrors:                 # another worker created the admin first
            c.rollback()
            generated = False
        if generated:
            f = DATA / "admin_credentials.txt"
            f.write_text(f"email: {email}\npassword: {pw}\n(change/delete this file after first login)\n")
            os.chmod(f, 0o600)
            print(f"[GameMarket] Admin created -> {f}")
    c.close()


def migrate():
    """Idempotent upgrade for SQLite databases created by an older version of this app."""
    if database.IS_PG:
        return                    # PostgreSQL schema is always created in its final form
    c = connect()
    cols = {r["name"] for r in c.execute("PRAGMA table_info(games)")}
    for col, ddl in (("requirements", "ALTER TABLE games ADD COLUMN requirements TEXT"),
                      ("slug", "ALTER TABLE games ADD COLUMN slug TEXT"),
                      ("play_file", "ALTER TABLE games ADD COLUMN play_file TEXT"),
                      ("play_mode", "ALTER TABLE games ADD COLUMN play_mode TEXT NOT NULL DEFAULT 'none'")):
        if col not in cols:
            c.execute(ddl)
    c.commit()
    rows = c.execute("SELECT id,title FROM games WHERE slug IS NULL OR slug=''").fetchall()
    for r in rows:
        c.execute("UPDATE games SET slug=? WHERE id=?", (make_slug(r["title"], r["id"]), r["id"]))
    # Store-wide policy: every game is free. Normalize any pricing left over
    # from an older version of the app so the whole catalog is consistently free.
    c.execute("UPDATE games SET price_cents=0, old_price_cents=NULL "
              "WHERE price_cents!=0 OR old_price_cents IS NOT NULL")
    c.commit()
    c.close()


def db():
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_):
    c = g.pop("db", None)
    if c:
        c.close()


# ------------------------------------------------------------------- helpers
class ApiError(Exception):
    def __init__(self, msg, code=400):
        self.msg, self.code = msg, code


@app.errorhandler(ApiError)
def _api_error(e):
    return jsonify(error=e.msg), e.code


@app.errorhandler(413)
def _too_big(_):
    return jsonify(error="Upload too large (game file max 300 MB, cover/screenshot max 3 MB each)"), 413


@app.errorhandler(404)
def _nf(_):
    if request.path.startswith("/api/"):
        return jsonify(error="Not found"), 404
    return "Not found", 404


@app.errorhandler(405)
def _na(_):
    return jsonify(error="Method not allowed"), 405


@app.errorhandler(Exception)
def _unhandled(e):
    if isinstance(e, ApiError):
        return _api_error(e)
    from werkzeug.exceptions import HTTPException
    if isinstance(e, HTTPException):
        raise e
    app.logger.exception("Unhandled error")
    if request.path.startswith("/api/"):
        return jsonify(error="Something went wrong. Please try again."), 500
    return "Something went wrong. Please try again.", 500


def current_user():
    if "user" not in g:
        g.user = None
        uid = session.get("uid")
        if uid:
            r = db().execute("SELECT * FROM users WHERE id=? AND active=1", (uid,)).fetchone()
            g.user = r
            if not r:
                session.clear()
    return g.user


def user_json(u):
    return {"id": u["id"], "name": u["name"], "email": u["email"], "role": u["role"]} if u else None


def login_required(*roles):
    def deco(fn):
        @wraps(fn)
        def wrap(*a, **kw):
            u = current_user()
            if not u:
                raise ApiError("Please sign in first", 401)
            if roles and u["role"] not in roles:
                raise ApiError("You do not have permission for this", 403)
            return fn(*a, **kw)
        return wrap
    return deco


_hits = {}


def throttle(key, limit, window):
    t = time.time()
    lst = [x for x in _hits.get(key, []) if t - x < window]
    ok = len(lst) < limit
    if ok:
        lst.append(t)
    _hits[key] = lst
    return ok


def ip():
    return request.remote_addr or "?"


EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[^@\s]+$")


@app.before_request
def play_host_only():
    if PLAY_HOST and request.host == PLAY_HOST and not request.path.startswith("/files/"):
        return "Not found", 404


@app.before_request
def csrf_protect():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.path.startswith("/api/"):
        tok, sent = session.get("csrf"), request.headers.get("X-CSRF-Token", "")
        if not tok or not hmac.compare_digest(tok, sent):
            return jsonify(error="Invalid or missing security token. Reload the page."), 403


@app.after_request
def headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    if request.path.startswith("/files/"):        # game files set their own (sandboxed) headers
        return resp
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; "
        "style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'; "
        f"frame-src 'self' https://www.youtube-nocookie.com{' ' + PLAY_ORIGIN if PLAY_ORIGIN else ''}; "
        "base-uri 'none'; form-action 'self'")
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


def body():
    return request.get_json(silent=True) or {}


# ------------------------------------------------ settings, audit log, maintenance
SETTING_DEFAULTS = {"maintenance": "0", "maintenance_message": "", "allow_registration": "1",
                    "allow_submissions": "1", "announcement": "", "trial_seconds": ""}
_settings_cache = {"t": 0.0, "v": {}}


def _conn():
    """The request's connection inside a request, a short-lived one elsewhere (background jobs, scripts)."""
    return (db(), False) if has_request_context() else (connect(), True)


def all_settings():
    if time.time() - _settings_cache["t"] > 5:           # other workers pick changes up within ~5 s
        c, own = _conn()
        try:
            _settings_cache["v"] = {r["key"]: r["value"] for r in c.execute("SELECT key,value FROM settings")}
            _settings_cache["t"] = time.time()
        except Exception:
            app.logger.exception("could not load settings")
        finally:
            if own:
                c.close()
    return {**SETTING_DEFAULTS, **_settings_cache["v"]}


def get_setting(key):
    return all_settings().get(key, SETTING_DEFAULTS.get(key, ""))


def set_setting(key, value, conn=None):
    c, own = (conn, False) if conn else _conn()
    try:
        c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (key, str(value)))
        c.commit()
        _settings_cache["t"] = 0.0
    finally:
        if own:
            c.close()


def trial_seconds():
    v = get_setting("trial_seconds")
    return int(v) if v.isdigit() and 30 <= int(v) <= 86400 else TRIAL_SECONDS


def ip_hash():
    """Non-reversible short fingerprint of the caller's IP (raw IPs are never stored)."""
    return hmac.new(app.secret_key.encode(), f"ip|{request.remote_addr or '?'}".encode(), hashlib.sha256).hexdigest()[:12]


def audit(category, action, target=None, detail=None, actor_type=None, actor=None, conn=None):
    """Append to the audit log. Categories: auth, security, content, admin, owner, system.
    Never raises: logging must not break the action being logged. Call it AFTER the action's own commit."""
    try:
        c, own = (conn, False) if conn else _conn()
        if has_request_context():
            if actor_type is None:
                if session.get("owner"):
                    actor_type, actor = "owner", "owner"
                else:
                    u = current_user()
                    actor_type, actor = (u["role"], u["email"]) if u else ("anonymous", None)
            who_ip = ip_hash()
        else:
            who_ip = None
        if isinstance(detail, (dict, list)):
            detail = json.dumps(detail, ensure_ascii=False)
        ts = now()
        c.execute("INSERT INTO audit_log(ts,day,category,actor_type,actor,action,target,detail,ip) VALUES(?,?,?,?,?,?,?,?,?)",
                  (ts, ts[:10], category, actor_type or "system", actor, action,
                   None if target is None else str(target)[:200], None if detail is None else str(detail)[:500], who_ip))
        c.commit()
        if own:
            c.close()
    except Exception:
        app.logger.exception("audit log write failed")
        try:
            c.rollback()
        except Exception:
            pass


def is_public(r):
    """Store-visible = approved by review AND not hidden/paused by the owner."""
    return r["status"] == "approved" and r["visibility"] == "public"


def viewer_privileged(r):
    """Owner session, admins and the game's own developer may see/play/download non-public items."""
    u = current_user()
    return bool(session.get("owner") or (u and (u["role"] == "admin" or (r and u["id"] == r["dev_id"]))))


MAINTENANCE_HTML = """<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title>PRO LOZIEX — Maintenance / صيانة</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0d0817;color:#f7f2ff;font-family:Tahoma,Segoe UI,Arial,sans-serif;text-align:center;padding:20px}
.b{max-width:460px;line-height:1.9}h1{font-size:24px;margin:0 0 6px}p{color:#cbbddb;margin:6px 0}.m{color:#ffc24e;margin-top:14px}</style></head>
<body><div class="b"><h1>🛠 الموقع تحت الصيانة</h1><p>نرجع قريبًا — شكرًا لصبرك.</p><div class="m">__MSG__</div>
<hr style="border:0;border-top:1px solid #30213f;margin:18px 0"><h1 dir="ltr">Under maintenance</h1><p dir="ltr">We'll be back shortly.</p></div></body></html>"""


def _maintenance_exempt():
    p = request.path
    if p.startswith("/static/") or p in ("/robots.txt", "/healthz", "/api/me", "/api/login", "/api/logout", ADMIN_PATH):
        return True
    return OWNER_ENABLED and (p == OWNER_PATH or p.startswith("/api/owner/"))


@app.get("/healthz")
def healthz():
    """Health check for the host (Render). Confirms the app can reach its database. Exposes nothing else."""
    try:
        db().execute("SELECT 1").fetchone()
    except Exception:
        return jsonify(status="error"), 503
    return jsonify(status="ok")


@app.before_request
def maintenance_gate():
    if request.path.startswith("/api/admin/") or get_setting("maintenance") != "1" or _maintenance_exempt():
        return None
    u = current_user()
    if session.get("owner") or (u and u["role"] == "admin"):
        return None                               # owner/admin can still browse the live site during maintenance
    msg = get_setting("maintenance_message")
    if request.path.startswith("/api/"):
        return jsonify(error=msg or "The site is under maintenance. Please come back soon.", maintenance=True), 503, {"Retry-After": "300"}
    return Response(MAINTENANCE_HTML.replace("__MSG__", str(escape(msg))), 503,
                    {"Content-Type": "text/html; charset=utf-8", "Retry-After": "300", "Cache-Control": "no-store"})


# ---------------------------------------------------------------------- auth
@app.get("/api/me")
def me():
    user = user_json(current_user())              # may clear the session (disabled/banned account) -> do this first
    if "csrf" not in session:
        session["csrf"] = secrets.token_urlsafe(24)
    st = all_settings()
    return jsonify(user=user, csrf=session["csrf"],
                   genres=GENRES, platforms=PLATFORMS, max_screenshots=MAX_SCREENSHOTS,
                   app_categories=APP_CATEGORIES, announcement=st["announcement"],
                   maintenance=st["maintenance"] == "1", allow_registration=st["allow_registration"] == "1",
                   allow_submissions=st["allow_submissions"] == "1", trial_seconds=trial_seconds())


@app.post("/api/register")
def register():
    d = body()
    name = str(d.get("name", "")).strip()
    email = str(d.get("email", "")).strip().lower()
    pw = str(d.get("password", ""))
    role = d.get("role", "player")
    if get_setting("allow_registration") != "1":
        raise ApiError("New sign-ups are temporarily closed.", 403)
    if not throttle("reg:" + ip(), 10, 3600):
        audit("security", "register_blocked", detail="rate limit")
        raise ApiError("Too many sign-ups from this address. Try later.", 429)
    if not 2 <= len(name) <= 40:
        raise ApiError("Name must be 2-40 characters")
    if not EMAIL_RE.match(email) or len(email) > 120:
        raise ApiError("Enter a valid email address")
    if not 8 <= len(pw) <= 128:
        raise ApiError("Password must be at least 8 characters")
    if role not in ("player", "developer"):
        raise ApiError("Invalid account type")
    try:
        uid = db().insert_id("INSERT INTO users(email,name,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                             (email, name, generate_password_hash(pw), role, now()))
        db().commit()
    except IntegrityErrors:
        db().rollback()
        raise ApiError("This email is already registered", 409)
    audit("auth", "register", target=email, detail=role, actor_type=role, actor=email)
    return _start_session(uid)


def _start_session(uid):
    session.clear()
    session.permanent = True
    session["uid"] = uid
    session["csrf"] = secrets.token_urlsafe(24)
    g.pop("user", None)
    return jsonify(user=user_json(current_user()), csrf=session["csrf"])


_DUMMY = generate_password_hash("dummy-password")


@app.post("/api/login")
def login():
    d = body()
    email = str(d.get("email", "")).strip().lower()
    pw = str(d.get("password", ""))
    if not throttle(f"login:{ip()}:{email}", 10, 600):
        audit("security", "login_blocked", target=email[:120], detail="rate limit")
        raise ApiError("Too many attempts. Wait a few minutes.", 429)
    u = db().execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    ok = check_password_hash(u["password_hash"] if u else _DUMMY, pw)
    if not u or not ok:
        audit("security", "login_failed", target=email[:120], detail="unknown email" if not u else "wrong password",
              actor_type="anonymous")
        raise ApiError("Wrong email or password", 401)
    if not u["active"]:
        audit("security", "login_disabled_account", target=email[:120], actor_type=u["role"], actor=u["email"])
        raise ApiError("This account is disabled", 403)
    db().execute("UPDATE users SET last_login_at=? WHERE id=?", (now(), u["id"]))
    db().commit()
    audit("auth", "login", target=email, actor_type=u["role"], actor=u["email"])
    return _start_session(u["id"])


@app.post("/api/logout")
def logout():
    session.clear()
    session["csrf"] = secrets.token_urlsafe(24)
    return jsonify(ok=True, csrf=session["csrf"])


# --------------------------------------------------------------------- games
BASE_SELECT = """
SELECT g.*, u.name AS dev_name,
 (SELECT CAST(ROUND(AVG(stars),1) AS REAL) FROM ratings r WHERE r.game_id=g.id) AS avg_rating,
 (SELECT COUNT(*) FROM ratings r WHERE r.game_id=g.id) AS rating_count,
 (SELECT COUNT(*) FROM library l WHERE l.game_id=g.id) AS downloads,
 (SELECT COUNT(*) FROM game_views v WHERE v.game_id=g.id) AS views,
 (SELECT COUNT(*) FROM download_events de WHERE de.game_id=g.id) AS dl_count
FROM games g JOIN users u ON u.id=g.dev_id """

ORDERS = {
    "popular": "downloads DESC, g.id DESC",
    "views": "views DESC, downloads DESC, g.id DESC",
    "newest": "g.id DESC",
    "rating": "COALESCE((SELECT AVG(stars) FROM ratings r WHERE r.game_id=g.id),0) DESC, rating_count DESC, g.id DESC",
}


def cover_url(name):
    return name if name.startswith("https://") else f"/media/cover/{name}"


def images_for(ids):
    ids = [i for i in ids if i]
    if not ids:
        return {}
    qs = ",".join("?" * len(ids))
    rows = db().execute(
        f"SELECT game_id,id,filename FROM game_images WHERE game_id IN ({qs}) ORDER BY position,id", ids).fetchall()
    out = {}
    for r in rows:
        out.setdefault(r["game_id"], []).append({"id": r["id"], "url": cover_url(r["filename"])})
    return out


def get_images(gid):
    return images_for([gid]).get(gid, [])


def item_url(r):
    slug = r["slug"] or make_slug(r["title"], r["id"])
    return f"/app/{r['id']}/{slug}" if r["kind"] == "app" else f"/game/{r['id']}/{slug}"


def youtube_id(url):
    m = YOUTUBE_RE.match(url or "")
    return m.group(1) if m else None


def game_json(r, flags=None, private=False, images=None, versions=None):
    uid_flags = flags or {}
    d = {
        "id": r["id"], "title": r["title"], "description": r["description"],
        "kind": r["kind"], "version": r["version"], "url": item_url(r),
        "platform": r["platform"], "genre": r["genre"], "requirements": r["requirements"],
        "cover": cover_url(r["cover"]), "dev_name": r["dev_name"],
        "avg_rating": r["avg_rating"], "rating_count": r["rating_count"],
        "downloads": r["downloads"], "views": r["views"], "download_count": r["dl_count"], "demo_url": r["demo_url"],
        "video_id": youtube_id(r["video_url"]), "video_url": r["video_url"],
        "has_build": bool(r["build"]), "slug": r["slug"] or make_slug(r["title"], r["id"]),
        "build_size": r["build_size"], "updated_at": r["updated_at"] or r["reviewed_at"] or r["created_at"],
        "play_mode": r["play_mode"] if r["play_file"] else "none", "has_play": bool(r["play_file"]),
        "favorite": r["id"] in uid_flags.get("fav", ()),
        "owned": r["id"] in uid_flags.get("lib", ()),
        "my_rating": uid_flags.get("rate", {}).get(r["id"]),
        "screenshots": images or [],
    }
    if versions is not None:
        d["versions"] = versions
    if private:
        d.update(status=r["status"], reject_reason=r["reject_reason"],
                 created_at=r["created_at"], reviewed_at=r["reviewed_at"], dev_id=r["dev_id"],
                 visibility=r["visibility"], scan_status=r["scan_status"], scan_note=r["scan_note"])
    return d


def versions_for(gid):
    rows = db().execute("SELECT id,version,notes,build_size,created_at,(build IS NOT NULL) AS has_build FROM game_versions "
                        "WHERE game_id=? ORDER BY id DESC LIMIT 50", (gid,)).fetchall()
    return [{"id": x["id"], "version": x["version"], "notes": x["notes"], "build_size": x["build_size"],
             "created_at": x["created_at"], "has_build": bool(x["has_build"])} for x in rows]


def user_flags():
    u = current_user()
    if not u:
        return {}
    c = db()
    return {
        "fav": {x[0] for x in c.execute("SELECT game_id FROM favorites WHERE user_id=?", (u["id"],))},
        "lib": {x[0] for x in c.execute("SELECT game_id FROM library WHERE user_id=?", (u["id"],))},
        "rate": {x[0]: x[1] for x in c.execute("SELECT game_id,stars FROM ratings WHERE user_id=?", (u["id"],))},
    }


@app.get("/api/games")
def list_games():
    kind = request.args.get("kind", "game")
    kind = kind if kind in KINDS else "game"
    where, args = ["g.status='approved'", "g.visibility='public'", "g.kind=?"], [kind]
    q = request.args.get("q", "").strip()[:60]
    if q:
        esc_q = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(g.title LIKE ? ESCAPE '\\' OR g.description LIKE ? ESCAPE '\\')")
        args += [esc_q, esc_q]
    for key, col, allowed in (("platform", "g.platform", PLATFORMS),
                              ("genre", "g.genre", APP_CATEGORIES if kind == "app" else GENRES)):
        vals = [v for v in request.args.get(key, "").split(",") if v in allowed]
        if vals:
            where.append(f"{col} IN ({','.join('?' * len(vals))})")
            args += vals
    if request.args.get("play") == "free":
        where.append("g.play_mode='free' AND g.play_file IS NOT NULL")
    order = ORDERS.get(request.args.get("sort"), ORDERS["popular"])
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1
    per_page = 48
    rows = db().execute(f"{BASE_SELECT} WHERE {' AND '.join(where)} ORDER BY {order} LIMIT ? OFFSET ?",
                        args + [per_page + 1, (page - 1) * per_page]).fetchall()
    has_more = len(rows) > per_page
    rows = rows[:per_page]
    fl = user_flags()
    return jsonify(games=[game_json(r, fl) for r in rows], page=page, has_more=has_more)


def fetch_game(gid):
    return db().execute(BASE_SELECT + "WHERE g.id=?", (gid,)).fetchone()


def record_view(gid):
    """Counts at most one view per game per visitor per day. Visitors are identified by user id, or by a keyed hash
    of the IP address (the raw IP is never stored)."""
    u = current_user()
    viewer = ("u%d" % u["id"]) if u else ("ip" + hmac.new(app.secret_key.encode(),
                                                          f"view|{request.remote_addr or '?'}".encode(),
                                                          hashlib.sha256).hexdigest()[:16])
    c = db()
    c.execute("INSERT OR IGNORE INTO game_views(game_id,viewer,day) VALUES(?,?,?)", (gid, viewer, now()[:10]))
    c.commit()


@app.get("/api/games/<int:gid>")
def game_detail(gid):
    r = fetch_game(gid)
    u = current_user()
    if not r or (not is_public(r) and not viewer_privileged(r)):
        raise ApiError("Game not found", 404)
    if is_public(r):
        record_view(gid)
    return jsonify(game=game_json(r, user_flags(), images=get_images(gid), versions=versions_for(gid)))


def store_cover(f):
    data = f.read(MAX_COVER + 1)
    if not data or len(data) > MAX_COVER:
        raise ApiError("Image must be up to 3 MB")
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        ext = ".png"
    elif data.startswith(b"\xff\xd8\xff"):
        ext = ".jpg"
    elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        ext = ".webp"
    else:
        raise ApiError("Images must be a real PNG, JPG or WEBP file")
    name = uuid.uuid4().hex + ext
    storage.put_cover(name, data)
    return name


def scan_upload(path, ext, kind, label):
    """Run the upload scanner. Rejects infected files (and suspicious ones when SCAN_BLOCK_SUSPICIOUS=1)."""
    res = scanner.scan_file(path, ext, kind)
    st = res["status"]
    if st != "clean":
        audit("security", "upload_scan_" + st, target=label, detail=res["note"])
    if st == "infected" or (st == "suspicious" and os.environ.get("SCAN_BLOCK_SUSPICIOUS") == "1"):
        Path(path).unlink(missing_ok=True)
        raise ApiError("Upload rejected by the security scan: " + (res["note"] or st), 400)
    return res


def store_build(f, kind="game"):
    ext = Path(f.filename or "").suffix.lower()
    if kind == "app" and ext != ".apk":
        raise ApiError("An app must be uploaded as an .apk file")
    magic = BUILD_TYPES.get(ext)
    if not magic:
        raise ApiError("Game file must be .zip, .apk, .7z or .rar")
    head = f.stream.read(8)
    f.stream.seek(0)
    if not head.startswith(magic):
        raise ApiError("The file content does not match its extension")
    name = uuid.uuid4().hex + ext
    tmp = TMP / name
    f.save(tmp)                                   # staged locally, validated, scanned, then handed to storage
    size = tmp.stat().st_size
    if size > MAX_BUILD or (ext in (".zip", ".apk") and not zipfile.is_zipfile(tmp)):
        tmp.unlink(missing_ok=True)
        raise ApiError("Game file is too large or corrupted")
    scan = scan_upload(tmp, ext, kind, f.filename or name)
    try:
        storage.put_build(name, tmp)
    except Exception:
        app.logger.exception("Storage upload failed")
        tmp.unlink(missing_ok=True)
        raise ApiError("File storage is temporarily unavailable. Please try again.", 503)
    return name, size, scan


def _repack_play_zip(src, dst):
    """Validate an uploaded HTML5 game ZIP and rewrite it clean (index.html at the root)."""
    with zipfile.ZipFile(src) as z:
        entries = []
        for i in z.infolist():
            n = i.filename.replace("\\", "/")
            if i.is_dir() or n.startswith("__MACOSX/") or n.rsplit("/", 1)[-1] in (".DS_Store", "Thumbs.db"):
                continue
            parts = n.split("/")
            if n.startswith("/") or ".." in parts or "" in parts or ":" in parts[0]:
                raise ApiError("The ZIP contains unsafe file paths")
            if i.flag_bits & 0x1:
                raise ApiError("Password-protected ZIP files are not supported")
            if (i.external_attr >> 16) & 0o170000 == 0o120000:
                raise ApiError("The ZIP contains symbolic links")
            entries.append((i, n))
        if not entries or len(entries) > MAX_PLAY_FILES:
            raise ApiError(f"The ZIP must contain between 1 and {MAX_PLAY_FILES} files")
        if sum(i.file_size for i, _ in entries) > MAX_PLAY_UNZIPPED:
            raise ApiError("The unpacked game is too large")
        names = {n for _, n in entries}
        prefix = ""
        if "index.html" not in names:
            tops = {n.split("/")[0] for n in names}
            top = next(iter(tops)) if len(tops) == 1 else None
            if top and top + "/index.html" in names:
                prefix = top + "/"
            else:
                raise ApiError("The ZIP must contain index.html at its top level")
        bad = sorted({Path(n).suffix.lower() or "(no extension)" for _, n in entries
                      if Path(n).suffix.lower() not in PLAY_EXTS})
        if bad:
            raise ApiError("File types not allowed in a browser game: " + ", ".join(bad[:8]))
        total = 0
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as out:
            for i, n in entries:
                with z.open(i) as s, out.open(n[len(prefix):], "w") as d:
                    while True:
                        chunk = s.read(1 << 20)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_PLAY_UNZIPPED:     # the header sizes can lie (zip bombs)
                            raise ApiError("The unpacked game is too large")
                        d.write(chunk)


def store_play(f):
    ext = Path(f.filename or "").suffix.lower()
    if ext not in (".zip", ".html", ".htm"):
        raise ApiError("Browser version must be a .zip (with index.html) or a single .html file")
    name = uuid.uuid4().hex + ".zip"
    raw, out = TMP / (name + ".raw"), TMP / name
    f.save(raw)
    try:
        if raw.stat().st_size > MAX_PLAY:
            raise ApiError(f"Browser version must be up to {MAX_PLAY // 1048576} MB")
        if ext == ".zip":
            if not zipfile.is_zipfile(raw):
                raise ApiError("The browser version is not a valid ZIP file")
            _repack_play_zip(raw, out)
        else:
            if b"\x00" in raw.read_bytes()[:4096]:
                raise ApiError("That does not look like an HTML file")
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                z.write(raw, "index.html")
        size = out.stat().st_size
        scan = scan_upload(out, ".zip", "game", f.filename or name)
        try:
            storage.put_play(name, out)
        except Exception:
            app.logger.exception("Storage upload failed")
            raise ApiError("File storage is temporarily unavailable. Please try again.", 503)
    except zipfile.BadZipFile:
        raise ApiError("The browser version ZIP is corrupted")
    finally:
        raw.unlink(missing_ok=True)
        out.unlink(missing_ok=True)
    return name, size, scan


def merge_scans(*scans):
    scans = [x for x in scans if x]
    if not scans:
        return None, None
    status = "clean"
    for x in scans:
        status = scanner.worst(status, x["status"])
    return status, "; ".join(x["note"] for x in scans if x["note"])[:500] or None


def read_play_mode(form, has_file, has_build):
    mode = form.get("play_mode", "none")
    if mode not in PLAY_MODES:
        raise ApiError("Invalid browser-play option")
    if mode != "none" and not has_file:
        raise ApiError("Upload the HTML5 game: a .zip with index.html, or a single .html file")
    if mode == "trial" and not has_build:
        raise ApiError("A 10-minute trial needs a downloadable game file too (the trial ends with a download button)")
    return mode


def read_submission_fields(f, kind="game"):
    title = f.get("title", "").strip()
    desc = f.get("description", "").strip()
    platform, genre = f.get("platform", ""), f.get("genre", "")
    demo = f.get("demo_url", "").strip()
    requirements = f.get("requirements", "").strip()[:600]
    version = f.get("version", "").strip()
    video = f.get("video_url", "").strip()
    if not 2 <= len(title) <= 80:
        raise ApiError("Title must be 2-80 characters")
    if not 20 <= len(desc) <= 3000:
        raise ApiError("Description must be 20-3000 characters")
    if kind == "app":
        platform, demo = "Android", ""
        if genre not in APP_CATEGORIES:
            raise ApiError("Invalid app category")
        if not version:
            raise ApiError("Enter the app version (for example 1.0.0)")
    elif platform not in PLATFORMS or genre not in GENRES:
        raise ApiError("Invalid platform or genre")
    if version and not VERSION_RE.match(version):
        raise ApiError("Version may contain letters, digits and . _ + - only (max 24 characters)")
    if demo and not re.match(r"^https?://[^\s]{3,280}$", demo):
        raise ApiError("Demo URL must start with http:// or https://")
    if video and not YOUTUBE_RE.match(video):
        raise ApiError("The video must be a YouTube link (https://www.youtube.com/watch?v=... or https://youtu.be/...)")
    return title, desc, platform, genre, (demo or None), (requirements or None), (version or None), (video or None)


def add_version_row(gid, version, notes, build, size, uid):
    db().execute("INSERT INTO game_versions(game_id,version,notes,build,build_size,created_at,created_by) VALUES(?,?,?,?,?,?,?)",
                 (gid, version, notes, build, size, now(), uid))


@app.post("/api/games")
@login_required("developer", "admin")
def create_game():
    u = current_user()
    if get_setting("allow_submissions") != "1":
        raise ApiError("New submissions are temporarily closed.", 403)
    kind = request.form.get("kind", "game")
    if kind not in KINDS:
        raise ApiError("Invalid type")
    title, desc, platform, genre, demo, requirements, version, video = read_submission_fields(request.form, kind)
    cover_f, build_f = request.files.get("cover"), request.files.get("build")
    play_f = request.files.get("play")
    shots = [s for s in request.files.getlist("screenshots") if s and s.filename][:MAX_SCREENSHOTS]
    if not cover_f or not cover_f.filename:
        raise ApiError("An icon image is required" if kind == "app" else "A cover image is required")
    has_build = bool(build_f and build_f.filename)
    if kind == "app":
        if not has_build:
            raise ApiError("Upload the app's APK file")
        play_mode, play_f = "none", None
    else:
        play_mode = read_play_mode(request.form, bool(play_f and play_f.filename), has_build)
        if play_mode == "none":
            play_f = None
        if not has_build and not demo and not play_f:
            raise ApiError("Upload a game file, an HTML5 browser version, or provide a demo URL")
    pending = db().execute("SELECT COUNT(*) FROM games WHERE dev_id=? AND status='pending'", (u["id"],)).fetchone()[0]
    if pending >= MAX_PENDING_PER_DEV:
        raise ApiError("You have too many submissions waiting for review")
    cover = build = play = None
    size = 0
    shot_names = []
    scan_b = scan_p = None
    try:
        cover = store_cover(cover_f)
        if has_build:
            build, size, scan_b = store_build(build_f, kind)
        if play_f:
            play, _, scan_p = store_play(play_f)
        for s in shots:
            shot_names.append(store_cover(s))
    except ApiError:
        if cover:
            storage.delete_cover(cover)
        if build:
            storage.delete_build(build)
        if play:
            storage.delete_play(play)
        for n in shot_names:
            storage.delete_cover(n)
        raise
    scan_status, scan_note = merge_scans(scan_b, scan_p)
    if version is None and kind == "game" and build:
        version = "1.0"
    gid = db().insert_id(
        "INSERT INTO games(dev_id,title,description,platform,genre,cover,build,build_size,demo_url,requirements,"
        "play_file,play_mode,created_at,kind,version,video_url,scan_status,scan_note,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (u["id"], title, desc, platform, genre, cover, build, size, demo, requirements, play, play_mode, now(),
         kind, version, video, scan_status, scan_note, now()))
    db().execute("UPDATE games SET slug=? WHERE id=?", (make_slug(title, gid), gid))
    for i, n in enumerate(shot_names):
        db().execute("INSERT INTO game_images(game_id,filename,position) VALUES(?,?,?)", (gid, n, i))
    if version and build:
        add_version_row(gid, version, (request.form.get("release_notes", "").strip()[:2000] or "Initial release"), build, size, u["id"])
    db().commit()
    audit("content", "submit_" + kind, target=gid, detail=title)
    return jsonify(id=gid, status="pending", scan_status=scan_status), 201


@app.put("/api/my/games/<int:gid>")
@login_required("developer", "admin")
def edit_game(gid):
    u = current_user()
    r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    if not r or (r["dev_id"] != u["id"] and u["role"] != "admin"):
        raise ApiError("Game not found", 404)
    kind = r["kind"]
    title, desc, platform, genre, demo, requirements, _version, video = read_submission_fields(request.form, kind)
    cover_f, build_f = request.files.get("cover"), request.files.get("build")
    play_f = request.files.get("play") if kind == "game" else None
    has_new_play = bool(play_f and play_f.filename)
    if kind == "app":
        play_mode = "none"
    else:
        play_mode = read_play_mode(request.form, has_new_play or bool(r["play_file"]),
                                   bool(build_f and build_f.filename) or bool(r["build"]))
    if play_mode == "none":
        has_new_play = False
    final_play = r["play_file"] if play_mode != "none" else None
    if kind == "game" and not (build_f and build_f.filename) and not r["build"] and not demo and not (has_new_play or final_play):
        raise ApiError("Upload a game file, an HTML5 browser version, or provide a demo URL")
    shots = [s for s in request.files.getlist("screenshots") if s and s.filename][:MAX_SCREENSHOTS]
    existing_shots = db().execute("SELECT COUNT(*) FROM game_images WHERE game_id=?", (gid,)).fetchone()[0]
    if existing_shots + len(shots) > MAX_SCREENSHOTS:
        raise ApiError(f"Up to {MAX_SCREENSHOTS} screenshots per game")
    remove_ids = [int(x) for x in request.form.get("remove_screenshots", "").split(",") if x.strip().isdigit()]
    new_cover = new_build = new_play = None
    new_size = r["build_size"]
    shot_names = []
    scan_b = scan_p = None
    try:
        if cover_f and cover_f.filename:
            new_cover = store_cover(cover_f)
        if build_f and build_f.filename:
            new_build, new_size, scan_b = store_build(build_f, kind)
        if has_new_play:
            new_play, _, scan_p = store_play(play_f)
            final_play = new_play
        for s in shots:
            shot_names.append(store_cover(s))
    except ApiError:
        if new_cover:
            storage.delete_cover(new_cover)
        if new_build:
            storage.delete_build(new_build)
        if new_play:
            storage.delete_play(new_play)
        for n in shot_names:
            storage.delete_cover(n)
        raise
    scan_status, scan_note = merge_scans(scan_b, scan_p)
    if scan_status is None:
        scan_status, scan_note = r["scan_status"], r["scan_note"]
    was_published = r["status"] == "approved"
    new_status = "pending" if r["status"] in ("approved", "rejected") else r["status"]
    db().execute(
        "UPDATE games SET title=?,description=?,platform=?,genre=?,demo_url=?,requirements=?,status=?,"
        "play_mode=?,play_file=?,video_url=?,scan_status=?,scan_note=?,updated_at=?,"
        "reject_reason=NULL,reviewed_at=NULL,cover=COALESCE(?,cover),build=COALESCE(?,build),"
        "build_size=CASE WHEN ? IS NOT NULL THEN ? ELSE build_size END WHERE id=?",
        (title, desc, platform, genre, demo, requirements, new_status, play_mode, final_play, video,
         scan_status, scan_note, now(),
         new_cover, new_build, new_build, new_size, gid))
    if new_build and r["build"]:                  # keep the version history pointing at the live file
        db().execute("UPDATE game_versions SET build=?, build_size=? WHERE game_id=? AND build=?",
                     (new_build, new_size, gid, r["build"]))
    if r["play_file"] and r["play_file"] != final_play:
        storage.delete_play(r["play_file"])
    if new_cover and not r["cover"].startswith("https://"):
        storage.delete_cover(r["cover"])
    if new_build and r["build"]:
        storage.delete_build(r["build"])
    if remove_ids:
        rows = db().execute(f"SELECT id,filename FROM game_images WHERE game_id=? AND id IN "
                            f"({','.join('?' * len(remove_ids))})", [gid] + remove_ids).fetchall()
        db().execute(f"DELETE FROM game_images WHERE game_id=? AND id IN ({','.join('?' * len(remove_ids))})",
                    [gid] + remove_ids)
        for rr in rows:
            storage.delete_cover(rr["filename"])
    if shot_names:
        pos0 = db().execute("SELECT COALESCE(MAX(position),-1)+1 FROM game_images WHERE game_id=?", (gid,)).fetchone()[0]
        for i, n in enumerate(shot_names):
            db().execute("INSERT INTO game_images(game_id,filename,position) VALUES(?,?,?)", (gid, n, pos0 + i))
    db().commit()
    audit("content", "edit_" + kind, target=gid, detail=title + (" (re-queued for review)" if was_published else ""))
    return jsonify(ok=True, status=new_status, requeued=was_published and new_status == "pending")


@app.post("/api/my/games/<int:gid>/versions")
@login_required("developer", "admin")
def add_version(gid):
    """Publish a new version (with release notes and, optionally, a new build). A new build is re-reviewed."""
    u = current_user()
    r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    if not r or (r["dev_id"] != u["id"] and u["role"] != "admin"):
        raise ApiError("Game not found", 404)
    version = request.form.get("version", "").strip()
    notes = request.form.get("notes", "").strip()[:2000]
    build_f = request.files.get("build")
    has_build = bool(build_f and build_f.filename)
    if not VERSION_RE.match(version):
        raise ApiError("Version may contain letters, digits and . _ + - only (max 24 characters)")
    if len(notes) < 3:
        raise ApiError("Write what changed in this version")
    if r["kind"] == "app" and not has_build:
        raise ApiError("Upload the new APK for this version")
    if db().execute("SELECT 1 FROM game_versions WHERE game_id=? AND version=?", (gid, version)).fetchone():
        raise ApiError("This version number already exists", 409)
    if db().execute("SELECT COUNT(*) FROM game_versions WHERE game_id=?", (gid,)).fetchone()[0] >= MAX_VERSIONS_PER_GAME:
        raise ApiError("Too many versions for this item")
    new_build, new_size, scan = None, r["build_size"], None
    if has_build:
        new_build, new_size, scan = store_build(build_f, r["kind"])
    if r["build"] and not db().execute("SELECT 1 FROM game_versions WHERE game_id=?", (gid,)).fetchone():
        add_version_row(gid, r["version"] or "1.0", "Initial release", r["build"], r["build_size"], r["dev_id"])
    add_version_row(gid, version, notes, new_build, new_size if new_build else 0, u["id"])
    requeue = bool(new_build) and r["status"] in ("approved", "rejected")
    scan_status, scan_note = merge_scans(scan)
    db().execute(
        "UPDATE games SET version=?, updated_at=?, build=COALESCE(?,build), "
        "build_size=CASE WHEN ? IS NOT NULL THEN ? ELSE build_size END, "
        "scan_status=COALESCE(?,scan_status), scan_note=CASE WHEN ? IS NOT NULL THEN ? ELSE scan_note END, "
        "status=?, reject_reason=CASE WHEN ?=1 THEN NULL ELSE reject_reason END, "
        "reviewed_at=CASE WHEN ?=1 THEN NULL ELSE reviewed_at END WHERE id=?",
        (version, now(), new_build, new_build, new_size, scan_status, scan_status, scan_note,
         "pending" if requeue else r["status"], 1 if requeue else 0, 1 if requeue else 0, gid))
    db().commit()
    audit("content", "new_version", target=gid, detail=f"{r['title']} -> {version}")
    return jsonify(ok=True, status="pending" if requeue else r["status"], requeued=requeue and r["status"] == "approved")


@app.delete("/api/my/games/<int:gid>/versions/<int:vid>")
@login_required("developer", "admin")
def delete_version(gid, vid):
    u = current_user()
    r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    if not r or (r["dev_id"] != u["id"] and u["role"] != "admin"):
        raise ApiError("Game not found", 404)
    remove_version(r, vid)
    audit("content", "delete_version", target=gid, detail=f"version id {vid}")
    return jsonify(ok=True)


def remove_version(r, vid):
    """Delete a history entry (never the live build). Shared by developer and owner endpoints."""
    v = db().execute("SELECT * FROM game_versions WHERE id=? AND game_id=?", (vid, r["id"])).fetchone()
    if not v:
        raise ApiError("Version not found", 404)
    if v["build"] and v["build"] == r["build"]:
        raise ApiError("This is the live version. Publish a newer one first.", 409)
    db().execute("DELETE FROM game_versions WHERE id=?", (vid,))
    db().commit()
    if v["build"]:
        storage.delete_build(v["build"])


@app.delete("/api/my/games/<int:gid>/screenshots/<int:img_id>")
@login_required("developer", "admin")
def delete_screenshot(gid, img_id):
    u = current_user()
    gm = db().execute("SELECT dev_id FROM games WHERE id=?", (gid,)).fetchone()
    if not gm or (gm["dev_id"] != u["id"] and u["role"] != "admin"):
        raise ApiError("Game not found", 404)
    row = db().execute("SELECT * FROM game_images WHERE id=? AND game_id=?", (img_id, gid)).fetchone()
    if not row:
        raise ApiError("Screenshot not found", 404)
    db().execute("DELETE FROM game_images WHERE id=?", (img_id,))
    db().commit()
    storage.delete_cover(row["filename"])
    return jsonify(ok=True)


@app.get("/api/my/games")
@login_required("developer", "admin")
def my_games():
    rows = db().execute(BASE_SELECT + "WHERE g.dev_id=? ORDER BY g.id DESC", (current_user()["id"],)).fetchall()
    imgs = images_for([r["id"] for r in rows])
    return jsonify(games=[game_json(r, private=True, images=imgs.get(r["id"], []), versions=versions_for(r["id"])) for r in rows])


def remove_game_files(r):
    if r["build"]:
        storage.delete_build(r["build"])
    if r["play_file"]:
        storage.delete_play(r["play_file"])
    if not r["cover"].startswith("https://"):
        storage.delete_cover(r["cover"])


def purge_game(r):
    """Delete a game/app row and every file it owns (cover, screenshots, builds of all versions, HTML5 package)."""
    gid = r["id"]
    shots = db().execute("SELECT filename FROM game_images WHERE game_id=?", (gid,)).fetchall()
    vbuilds = [x["build"] for x in db().execute("SELECT build FROM game_versions WHERE game_id=? AND build IS NOT NULL", (gid,))]
    db().execute("DELETE FROM games WHERE id=?", (gid,))
    db().commit()
    remove_game_files(r)
    for b in vbuilds:
        if b != r["build"]:
            storage.delete_build(b)
    for s in shots:
        storage.delete_cover(s["filename"])


@app.delete("/api/my/games/<int:gid>")
@login_required("developer", "admin")
def delete_my_game(gid):
    r = db().execute("SELECT * FROM games WHERE id=? AND dev_id=?", (gid, current_user()["id"])).fetchone()
    if not r:
        raise ApiError("Game not found", 404)
    purge_game(r)
    audit("content", "delete_" + r["kind"], target=gid, detail=r["title"])
    return jsonify(ok=True)


def approved_game(gid):
    r = db().execute("SELECT * FROM games WHERE id=? AND status='approved' AND visibility='public'", (gid,)).fetchone()
    if not r:
        raise ApiError("Game not found", 404)
    return r


@app.post("/api/games/<int:gid>/favorite")
@login_required()
def toggle_favorite(gid):
    approved_game(gid)
    uid, c = current_user()["id"], db()
    if c.execute("DELETE FROM favorites WHERE user_id=? AND game_id=?", (uid, gid)).rowcount:
        fav = False
    else:
        c.execute("INSERT INTO favorites VALUES(?,?)", (uid, gid))
        fav = True
    c.commit()
    return jsonify(favorite=fav)


@app.post("/api/games/<int:gid>/get")
@login_required()
def get_game(gid):
    r = approved_game(gid)
    u = current_user()
    import systems_v4 as _S4
    c = db()
    first = not c.execute("SELECT 1 FROM library WHERE user_id=? AND game_id=?", (u["id"], gid)).fetchone()
    c.execute("INSERT OR IGNORE INTO library VALUES(?,?,?)", (u["id"], gid, now()))
    if first:
        _S4.ensure_progress(c, u["id"])
        _S4.add_xp(c, u["id"], 5, "library:add:%d" % gid)
        _S4.unlock_achievement(c, u["id"], "first_download")
        n = c.execute("SELECT COUNT(*) FROM library WHERE user_id=?", (u["id"],)).fetchone()[0]
        if n >= 5:
            _S4.unlock_achievement(c, u["id"], "collector_5")
    c.commit()
    return jsonify(ok=True, owned=True)


@app.get("/api/library")
@login_required()
def library():
    rows = db().execute(BASE_SELECT + "JOIN library lb ON lb.game_id=g.id WHERE lb.user_id=? AND g.status='approved' AND g.visibility='public' "
                        "ORDER BY lb.created_at DESC", (current_user()["id"],)).fetchall()
    fl = user_flags()
    return jsonify(games=[game_json(r, fl) for r in rows])


@app.get("/api/favorites")
@login_required()
def favorites():
    rows = db().execute(BASE_SELECT + "JOIN favorites fv ON fv.game_id=g.id WHERE fv.user_id=? AND g.status='approved' AND g.visibility='public' "
                        "ORDER BY g.id DESC", (current_user()["id"],)).fetchall()
    fl = user_flags()
    return jsonify(games=[game_json(r, fl) for r in rows])


@app.post("/api/games/<int:gid>/rate")
@login_required()
def rate(gid):
    """Legacy alias of the v4 review endpoint. No download/library required (reviews are open to all
    players); negative reviews are kept and never hidden. Stars allow 0.5 steps; >=2.5 = positive."""
    import systems_v4 as _S
    r = approved_game(gid)
    u = current_user()
    d = body()
    v = _S.valid_stars(d.get("stars"))
    if v is None:
        raise ApiError("Rating must be 0.5-5 in 0.5 steps")
    if r["dev_id"] == u["id"]:
        raise ApiError("You cannot rate your own game", 403)
    text = str(d.get("review_text", d.get("text", "")))[:2000]
    sent = _S.sentiment_of(v)
    ts = now()
    c = db()
    is_new = not c.execute("SELECT 1 FROM reviews WHERE user_id=? AND game_id=?", (u["id"], gid)).fetchone()
    c.execute("INSERT INTO reviews(user_id,game_id,stars,review_text,sentiment,created_at,updated_at) VALUES(?,?,?,?,?,?,?) "
              "ON CONFLICT(user_id,game_id) DO UPDATE SET stars=excluded.stars,review_text=excluded.review_text,"
              "sentiment=excluded.sentiment,updated_at=excluded.updated_at",
              (u["id"], gid, v, text, sent, ts, ts))
    legacy = max(1, min(5, int(v) if v == int(v) else int(round(v))))
    try:
        c.execute("INSERT INTO ratings(user_id,game_id,stars,review_text,updated_at) VALUES(?,?,?,?,?) "
                  "ON CONFLICT(user_id,game_id) DO UPDATE SET stars=excluded.stars,review_text=excluded.review_text,updated_at=excluded.updated_at",
                  (u["id"], gid, legacy, text, ts))
    except Exception:
        c.execute("INSERT INTO ratings(user_id,game_id,stars) VALUES(?,?,?) "
                  "ON CONFLICT(user_id,game_id) DO UPDATE SET stars=excluded.stars", (u["id"], gid, legacy))
    _S.ensure_progress(c, u["id"])
    if is_new:
        _S.add_xp(c, u["id"], 10, "review:game:%d" % gid)
        _S.unlock_achievement(c, u["id"], "reviewer")
    c.commit()
    return jsonify(ok=True, stars=v, sentiment=sent)


@app.get("/download/<int:gid>")
def download(gid):
    """Protected download: needs a signed-in account that owns the item (or its developer/admin), is rate
    limited per account, logged, never cached, and (on R2/S3) redirects to a signed link valid for 60 seconds."""
    u = current_user()
    if not u:
        return "Sign in to download", 401
    r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    if not r or not r["build"]:
        return "No file available for this game", 404
    privileged = u["role"] == "admin" or u["id"] == r["dev_id"] or bool(session.get("owner"))
    allowed = privileged or (
        is_public(r) and db().execute(
            "SELECT 1 FROM library WHERE user_id=? AND game_id=?", (u["id"], gid)).fetchone())
    if not allowed:
        return "Add this game to your library first", 403
    if not privileged and not throttle(f"dl:{u['id']}", DOWNLOAD_LIMIT_PER_HOUR, 3600):
        audit("security", "download_rate_limited", target=gid, detail=r["title"])
        return "Too many downloads. Try again later.", 429
    ts = now()
    db().execute("INSERT INTO download_events(game_id,user_id,ts,day) VALUES(?,?,?,?)", (gid, u["id"], ts, ts[:10]))
    db().commit()
    ext = Path(r["build"]).suffix
    slug = re.sub(r"[^A-Za-z0-9]+", "-", r["title"]).strip("-") or "game"
    if r["version"]:
        slug += "-v" + re.sub(r"[^A-Za-z0-9._-]+", "-", r["version"])
    resp = storage.build_response(r["build"], slug + ext)
    resp.headers["Cache-Control"] = "no-store"
    resp.headers["X-Robots-Tag"] = "noindex"
    return resp


@app.get("/media/cover/<name>")
def media_cover(name):
    resp = storage.cover_response(name)
    resp.headers["Cache-Control"] = "public, max-age=86400"
    return resp


# ------------------------------------------------------- browser play (HTML5)
PLAY_MIME = {".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
             ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8",
             ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8", ".wasm": "application/wasm",
             ".svg": "image/svg+xml", ".webp": "image/webp", ".avif": "image/avif", ".woff2": "font/woff2",
             ".woff": "font/woff", ".ttf": "font/ttf", ".otf": "font/otf", ".glb": "model/gltf-binary",
             ".gltf": "model/gltf+json", ".opus": "audio/ogg", ".m4a": "audio/mp4", ".txt": "text/plain; charset=utf-8"}
# A sandboxed page without allow-same-origin has no localStorage (the access throws). Many games
# use it for scores, so give them an in-memory replacement instead of letting them crash.
STORAGE_SHIM = (b"<script>(function(){function m(){var d={};return{getItem:function(k){return Object.prototype."
                b"hasOwnProperty.call(d,k)?d[k]:null},setItem:function(k,v){d[k]=String(v)},removeItem:function(k){"
                b"delete d[k]},clear:function(){d={}},key:function(i){return Object.keys(d)[i]||null},get length(){"
                b"return Object.keys(d).length}}}['localStorage','sessionStorage'].forEach(function(n){try{void window[n]}"
                b"catch(e){try{Object.defineProperty(window,n,{value:m(),configurable:true})}catch(_){}}})})();</script>")
# Trial games: even if someone hides the parent page's timer, the game document itself blanks out when time is up
# (and the signed file link expires at the same moment, so nothing new can be fetched).
TRIAL_WATCHDOG = b'''<script>setTimeout(function(){try{window.stop()}catch(e){}document.open();document.write('<body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#120a1c;color:#fff;font-family:sans-serif;text-align:center"><div><h2>Trial ended / \\u0627\\u0646\\u062a\\u0647\\u062a \\u0627\\u0644\\u062a\\u062c\\u0631\\u0628\\u0629</h2></div></body>');document.close()},__MS__)</script>'''
_INJECT_AT = re.compile(rb"<head[^>]*>|<html[^>]*>|<!doctype[^>]*>", re.I)


def play_csp():
    cdn = "https://cdnjs.cloudflare.com https://cdn.jsdelivr.net"
    return ("sandbox allow-scripts allow-pointer-lock allow-fullscreen" + (" allow-same-origin" if PLAY_ORIGIN else "") + "; "
            f"default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: {cdn}; "
            f"style-src 'self' 'unsafe-inline' https://fonts.googleapis.com {cdn}; "
            f"font-src 'self' data: https://fonts.gstatic.com {cdn}; img-src 'self' data: blob:; "
            f"media-src 'self' data: blob:; connect-src 'self' data: blob: {cdn}; worker-src 'self' blob:; "
            "base-uri 'self'; form-action 'none'; " + ("frame-ancestors *" if PLAY_ORIGIN else "frame-ancestors 'self'"))


def anon_key():
    ua = request.headers.get("User-Agent", "")
    return "a" + hmac.new(app.secret_key.encode(), f"{ip()}|{ua}".encode(), hashlib.sha256).hexdigest()[:16]


def log_play(gid, mode):
    """Count a play start; the same visitor re-opening the game within 30 minutes is not counted twice."""
    try:
        v = anon_key()
        since = (datetime.now(timezone.utc) - timedelta(minutes=30)).isoformat(timespec="seconds")
        c = db()
        if c.execute("SELECT 1 FROM play_events WHERE game_id=? AND visitor=? AND ts>=?", (gid, v, since)).fetchone():
            return
        ts = now()
        c.execute("INSERT INTO play_events(game_id,visitor,mode,ts,day) VALUES(?,?,?,?,?)", (gid, v, mode, ts, ts[:10]))
        c.commit()
    except Exception:
        app.logger.exception("play logging failed")
        try:
            db().rollback()
        except Exception:
            pass


@app.post("/api/games/<int:gid>/play")
def play_session(gid):
    """Start (or resume) a play session. Returns a signed, expiring URL for the game's files."""
    r = fetch_game(gid)
    u = current_user()
    privileged = bool(r and viewer_privileged(r))
    if not r or not r["play_file"] or r["play_mode"] not in ("free", "trial") or (not is_public(r) and not privileged):
        raise ApiError("This game has no browser version", 404)
    mode, left, ttl, total = r["play_mode"], None, 6 * 3600, trial_seconds()
    if not privileged:
        log_play(gid, mode)
    if mode == "trial" and not privileged:
        # The trial clock starts at the first play and is stored on the SERVER, so a refresh or a new
        # tab can't reset it. It is tied to the visitor and, when signed in, to the account as well.
        keys = [anon_key()] + ([f"u{u['id']}"] if u else [])
        c = db()
        for k in keys:
            c.execute("INSERT OR IGNORE INTO play_trials(visitor,game_id,started_at) VALUES(?,?,?)", (k, gid, now()))
        c.commit()
        rows = c.execute(f"SELECT started_at FROM play_trials WHERE game_id=? AND visitor IN ({','.join('?' * len(keys))})",
                         [gid] + keys).fetchall()
        started = min(datetime.fromisoformat(x[0]) for x in rows)
        remaining = total - (datetime.now(timezone.utc) - started).total_seconds()
        if remaining < 1:
            return jsonify(expired=True, seconds_left=0, mode=mode)
        left, ttl = int(remaining), remaining + 20
    token = play_signer.dumps({"g": gid, "x": int(time.time() + ttl), "p": 1 if privileged else 0,
                               "t": 1 if (mode == "trial" and not privileged) else 0})
    return jsonify(url=f"{PLAY_ORIGIN}/files/{token}/", seconds_left=left, mode=mode, sandbox=PLAY_SANDBOX)


@app.get("/files/<token>/")
def play_index(token):
    return play_files(token, "index.html")


@app.get("/files/<token>/<path:name>")
def play_files(token, name):
    try:
        d = play_signer.loads(token)
    except BadSignature:
        return "Invalid link", 403
    if d.get("x", 0) < time.time():
        return "This play session has ended", 403
    r = db().execute("SELECT play_file,play_mode,status,visibility FROM games WHERE id=?", (d.get("g"),)).fetchone()
    if not r or not r["play_file"] or r["play_mode"] == "none" or (not is_public(r) and not d.get("p")):
        return "Not found", 404
    try:
        z = zipfile.ZipFile(storage.play_local_path(r["play_file"]))
    except Exception:
        app.logger.exception("Cannot open play file")
        return "Game files are unavailable", 503
    try:
        info = z.getinfo(name.replace("\\", "/"))
    except KeyError:
        z.close()
        return "Not found", 404
    ext = Path(info.filename).suffix.lower()
    ctype = PLAY_MIME.get(ext) or mimetypes.guess_type(info.filename)[0] or "application/octet-stream"
    hdr = {"Content-Security-Policy": play_csp(), "Referrer-Policy": "no-referrer",
           "Access-Control-Allow-Origin": "*",           # the sandboxed page has a null origin
           "Cache-Control": "private, no-cache"}
    if not PLAY_ORIGIN:
        hdr["X-Frame-Options"] = "SAMEORIGIN"
    if ext in (".html", ".htm"):
        data = z.read(info)
        z.close()
        inject = b"" if PLAY_ORIGIN else STORAGE_SHIM
        if d.get("t"):                          # trial: the page ends itself when the server-side clock runs out
            ms = max(0, int((d.get("x", 0) - 20 - time.time()) * 1000))
            inject += TRIAL_WATCHDOG.replace(b"__MS__", str(ms).encode())
        if inject:
            m = _INJECT_AT.search(data[:8192])
            data = data[:m.end()] + inject + data[m.end():] if m else inject + data
        return Response(data, content_type=ctype, headers=hdr)

    def stream():
        try:
            with z.open(info) as s:
                while True:
                    chunk = s.read(256 * 1024)
                    if not chunk:
                        break
                    yield chunk
        finally:
            z.close()
    hdr["Content-Length"] = str(info.file_size)
    return Response(stream(), content_type=ctype, headers=hdr)


# --------------------------------------------------------------------- admin
@app.get("/api/admin/stats")
@login_required("admin")
def admin_stats():
    c = db()
    one = lambda s: c.execute(s).fetchone()[0]
    return jsonify(
        pending=one("SELECT COUNT(*) FROM games WHERE status='pending'"),
        approved=one("SELECT COUNT(*) FROM games WHERE status='approved'"),
        rejected=one("SELECT COUNT(*) FROM games WHERE status='rejected'"),
        players=one("SELECT COUNT(*) FROM users WHERE role='player'"),
        developers=one("SELECT COUNT(*) FROM users WHERE role='developer'"),
        downloads=one("SELECT COUNT(*) FROM library"))


@app.get("/api/admin/games")
@login_required("admin")
def admin_games():
    st = request.args.get("status")
    where, args = "", []
    if st in ("pending", "approved", "rejected"):
        where, args = "WHERE g.status=?", [st]
    rows = db().execute(f"{BASE_SELECT} {where} ORDER BY g.id DESC LIMIT 300", args).fetchall()
    imgs = images_for([r["id"] for r in rows])
    return jsonify(games=[game_json(r, private=True, images=imgs.get(r["id"], [])) for r in rows])


@app.post("/api/admin/games/<int:gid>/review")
@login_required("admin")
def admin_review(gid):
    d = body()
    action, reason = d.get("action"), str(d.get("reason", "")).strip()[:500]
    if not db().execute("SELECT 1 FROM games WHERE id=?", (gid,)).fetchone():
        raise ApiError("Game not found", 404)
    if action == "approve":
        new, reason = "approved", None
    elif action == "reject":
        if len(reason) < 3:
            raise ApiError("Give the developer a reason for the rejection")
        new = "rejected"
    elif action == "unpublish":
        new, reason = "pending", None
    else:
        raise ApiError("Unknown action")
    db().execute("UPDATE games SET status=?, reject_reason=?, reviewed_at=? WHERE id=?", (new, reason, now(), gid))
    db().commit()
    audit("admin", "review_" + action, target=gid, detail=reason or None)
    return jsonify(ok=True, status=new)


@app.delete("/api/admin/games/<int:gid>")
@login_required("admin")
def admin_delete_game(gid):
    r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
    if not r:
        raise ApiError("Game not found", 404)
    purge_game(r)
    audit("admin", "delete_" + r["kind"], target=gid, detail=r["title"])
    return jsonify(ok=True)


@app.get("/api/admin/users")
@login_required("admin")
def admin_users():
    rows = db().execute(
        "SELECT id,email,name,role,active,created_at,"
        "(SELECT COUNT(*) FROM games WHERE dev_id=users.id) AS games FROM users ORDER BY id DESC LIMIT 500").fetchall()
    return jsonify(users=[dict(r) for r in rows])


@app.post("/api/admin/users/<int:uid>/active")
@login_required("admin")
def admin_user_active(uid):
    if uid == current_user()["id"]:
        raise ApiError("You cannot disable your own account")
    active = 1 if body().get("active") else 0
    if not db().execute("UPDATE users SET active=? WHERE id=? AND role!='admin'", (active, uid)).rowcount:
        raise ApiError("User not found", 404)
    db().commit()
    audit("admin", "user_enable" if active else "user_disable", target=uid)
    return jsonify(ok=True, active=bool(active))



# ------------------------------------------------- visits + owner dashboard
BOT_RE = re.compile(r"bot|crawl|spider|slurp|preview|monitor|uptime|curl|wget|python-requests|headless|lighthouse|facebookexternalhit",
                    re.I)
GAME_PATH_RE = re.compile(r"^/(?:game|app)/(\d+)/")


def device_of(ua):
    ua = ua.lower()
    if "ipad" in ua or "tablet" in ua:
        return "tablet"
    if "mobi" in ua or "android" in ua or "iphone" in ua:
        return "mobile"
    return "desktop"


@app.after_request
def track_visit(resp):
    """Count page views (store home + game pages). No cookies, no raw IPs, bots skipped."""
    try:
        if request.method != "GET" or resp.status_code != 200 or session.get("owner"):
            return resp
        m = GAME_PATH_RE.match(request.path)
        if request.path != "/" and not m:
            return resp
        ua = request.headers.get("User-Agent", "")
        if not ua or BOT_RE.search(ua):
            return resp
        visitor = hmac.new(app.secret_key.encode(), f"{ip()}|{ua}".encode(), hashlib.sha256).hexdigest()[:16]
        ts = now()
        db().execute("INSERT INTO visits(day,ts,path,game_id,visitor,device) VALUES(?,?,?,?,?,?)",
                     (ts[:10], ts, request.path[:200], int(m.group(1)) if m else None, visitor, device_of(ua)))
        db().commit()
    except Exception:
        app.logger.exception("visit tracking failed")
        try:
            db().rollback()
        except Exception:
            pass
    return resp


def ua_hash():
    return hashlib.sha256(request.headers.get("User-Agent", "").encode()).hexdigest()[:16]


def owner_required(fn):
    @wraps(fn)
    def wrap(*a, **kw):
        if not OWNER_ENABLED:
            raise ApiError("Not found", 404)
        t = time.time()
        valid = (session.get("owner") and session.get("owner_until", 0) >= t
                 and t - session.get("owner_last", 0) <= OWNER_IDLE_SECONDS      # idle timeout
                 and hmac.compare_digest(str(session.get("owner_ua", "")), ua_hash()))   # cookie theft to another browser
        if not valid:
            if session.get("owner"):
                audit("security", "owner_session_expired", actor_type="owner", actor="owner")
            for k in ("owner", "owner_until", "owner_last", "owner_ua"):
                session.pop(k, None)
            raise ApiError("Owner sign-in required", 401)
        session["owner_last"] = int(t)
        return fn(*a, **kw)
    return wrap


@app.post("/api/owner/login")
def owner_login():
    """Owner sign-in: email + password (+ 6-digit authenticator code when OWNER_TOTP_SECRET is set).
    Failures are counted in the database (shared by all workers): 5 failures per IP per 15 minutes locks that IP."""
    if not OWNER_ENABLED:
        raise ApiError("Not found", 404)
    since = (datetime.now(timezone.utc) - timedelta(minutes=15)).isoformat(timespec="seconds")
    fails = db().execute("SELECT COUNT(*) FROM audit_log WHERE action='owner_login_failed' AND ip=? AND ts>=?",
                         (ip_hash(), since)).fetchone()[0]
    if fails >= 5 or not throttle("owner:" + ip(), 30, 900):
        audit("security", "owner_login_blocked", detail="too many failed attempts", actor_type="anonymous")
        raise ApiError("Too many attempts. Wait 15 minutes.", 429)
    d = body()
    email, pw = str(d.get("email", "")).strip().lower(), str(d.get("password", ""))
    ok_email = hmac.compare_digest(email.encode(), OWNER_EMAIL.encode())
    ok_pw = check_password_hash(OWNER_PW_HASH, pw)          # always evaluated (no timing hint)
    creds_ok = ok_email and ok_pw
    step = None
    code_ok = True
    if OWNER_TOTP_SECRET:
        step = totp.verify(OWNER_TOTP_SECRET, d.get("code", ""))
        row = db().execute("SELECT value FROM settings WHERE key='owner_totp_last'").fetchone()
        code_ok = step is not None and step > int(row["value"] if row else 0)      # a code works once
    if not (creds_ok and code_ok):
        audit("security", "owner_login_failed", target=email[:120],
              detail="bad credentials" if not creds_ok else "bad or reused 2FA code", actor_type="anonymous")
        raise ApiError("Wrong email, password or code", 401)
    session.clear()
    session["owner"] = True
    session["owner_until"] = int(time.time()) + 12 * 3600    # owner sessions last at most 12 hours
    session["owner_last"] = int(time.time())
    session["owner_ua"] = ua_hash()
    session["csrf"] = secrets.token_urlsafe(24)
    if step is not None:
        set_setting("owner_totp_last", step)
    audit("security", "owner_login_ok", detail="2FA" if OWNER_TOTP_SECRET else "password only")
    return jsonify(ok=True, csrf=session["csrf"])


@app.post("/api/owner/logout")
def owner_logout():
    if session.get("owner"):
        audit("security", "owner_logout")
    session.clear()
    session["csrf"] = secrets.token_urlsafe(24)
    return jsonify(ok=True, csrf=session["csrf"])


if OWNER_ENABLED:
    @app.get(OWNER_PATH)
    def owner_page():
        resp = send_from_directory(app.static_folder, "owner.html")
        resp.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive"
        resp.headers["Cache-Control"] = "no-store"
        return resp


# ----------------------------------------------------------- SEO: game page
def esc(s):
    return str(escape(s if s is not None else ""))


def abs_url(base, path_or_url):
    return path_or_url if path_or_url.startswith("http") else base + path_or_url


def fmt_size(b):
    b = int(b or 0)
    return f"{b / 1048576:.1f} MB" if b > 1048576 else (f"{max(1, round(b / 1024))} KB" if b else "")


def render_item_page(gm, base):
    """Server-rendered, SEO-friendly page for one game or one app (own URL: /game/<id>/<slug> or /app/<id>/<slug>)."""
    is_app = gm["kind"] == "app"
    url = f"{base}{gm['url']}"
    noun = "app" if is_app else "game"
    title = f"{gm['title']} — Free {gm['genre']} {noun} for {gm['platform']} | {SITE_NAME}"
    desc = re.sub(r"\s+", " ", gm["description"] or "")[:160]
    img = abs_url(base, gm["cover"])
    rating_txt = f"★ {gm['avg_rating']} ({gm['rating_count']} ratings)" if gm["rating_count"] else "No ratings yet"
    shots = "".join(f'<img src="{esc(abs_url(base, s["url"]))}" alt="{esc(gm["title"])} screenshot" loading="lazy">'
                    for s in gm.get("screenshots", []))
    shots_html = f'<div class="shots">{shots}</div>' if shots else ""
    video_html = ""
    if gm.get("video_id"):
        video_html = ('<div class="video"><iframe src="https://www.youtube-nocookie.com/embed/' + esc(gm["video_id"]) +
                      f'" title="{esc(gm["title"])} video" loading="lazy" allowfullscreen referrerpolicy="strict-origin-when-cross-origin" '
                      'sandbox="allow-scripts allow-same-origin allow-presentation" '
                      'allow="encrypted-media; picture-in-picture; fullscreen"></iframe></div>')
    req_html = (f'<h3 class="sub">System requirements</h3><p class="desc" style="max-height:none">{esc(gm["requirements"])}</p>'
                if gm.get("requirements") else "")
    vers = gm.get("versions") or []
    log_html = ""
    if vers:
        items = "".join(
            f'<li><div class="vh"><b>v{esc(v["version"])}</b>'
            f'<small>{esc((v["created_at"] or "")[:10])}{(" · " + esc(fmt_size(v["build_size"]))) if v["build_size"] else ""}</small></div>'
            f'<p>{esc(v["notes"] or "")}</p></li>' for v in vers)
        log_html = f'<h3 class="sub">Update history</h3><ul class="changelog">{items}</ul>'
    facts = []
    if gm.get("version"):
        facts.append(("Version", "v" + gm["version"]))
    if gm.get("build_size") and gm.get("has_build"):
        facts.append(("APK size" if is_app else "File size", fmt_size(gm["build_size"])))
    facts.append(("Category" if is_app else "Genre", gm["genre"]))
    facts.append(("Platform", gm["platform"]))
    if gm.get("updated_at"):
        facts.append(("Last updated", gm["updated_at"][:10]))
    facts.append(("Downloads", str(gm["download_count"])))
    facts_html = '<div class="facts">' + "".join(
        f'<div><span>{esc(k)}</span><b>{esc(v)}</b></div>' for k, v in facts) + "</div>"
    jsonld = {
        "@context": "https://schema.org", "@type": "MobileApplication" if is_app else "VideoGame", "name": gm["title"],
        "description": gm["description"], "image": img, "applicationCategory": gm["genre"],
        "operatingSystem": gm["platform"], "offers": {"@type": "Offer", "price": "0", "priceCurrency": "USD"},
    }
    if gm.get("version"):
        jsonld["softwareVersion"] = gm["version"]
    if gm["rating_count"]:
        jsonld["aggregateRating"] = {"@type": "AggregateRating", "ratingValue": gm["avg_rating"],
                                      "ratingCount": gm["rating_count"]}
    pub = {k: v for k, v in gm.items() if k not in ("versions",)}
    data_json = json.dumps(pub).replace("</", "<\\/")
    ld_json = json.dumps(jsonld).replace("</", "<\\/")
    favicon = ("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E"
               "%3Crect width='32' height='32' rx='7' fill='%23a13df2'/%3E%3Ctext x='16' y='22' font-size='17' "
               "text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EG%3C/text%3E%3C/svg%3E")
    back = ('<a href="/#/apps" style="color:#c57cff">← Back to all apps</a>' if is_app
            else '<a href="/" style="color:#c57cff">← Back to all games</a>')
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<script src="/static/js/i18n.js"></script>
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}">
<meta name="robots" content="index,follow">
<link rel="canonical" href="{esc(url)}">
<meta property="og:type" content="website"><meta property="og:site_name" content="{SITE_NAME}">
<meta property="og:title" content="{esc(gm['title'])}"><meta property="og:description" content="{esc(desc)}">
<meta property="og:image" content="{esc(img)}"><meta property="og:url" content="{esc(url)}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="{favicon}">
<link rel="stylesheet" href="/static/css/style.css">
<link rel="stylesheet" href="/static/css/theme.css">
<link rel="stylesheet" href="/static/css/home.css">
<script id="gm-data" type="application/json">{data_json}</script>
<script type="application/ld+json">{ld_json}</script>
</head>
<body>
<header class="top lx-detail-top"><a class="brand" href="/" style="text-decoration:none;color:inherit"><span class="mark lx-crown">👑</span><span class="lx-wordmark"><b>PRO</b> <i>LOZIEX</i></span></a>
<div style="flex:1"></div>
<div class="top-actions"><a href="/#/library" title="My Library" style="text-decoration:none">🛒</a><button id="btnAcc" title="Account">♙</button></div></header>
<main class="wrap" style="max-width:900px">
<div id="playerBox" hidden></div>
<div class="detail lx-detail{' app-detail' if is_app else ''}">
{('<div>' + shots_html + video_html + '</div>') if is_app else ('<div><img src="' + esc(img) + '" alt="' + esc(gm['title']) + '">' + shots_html + video_html + '</div>')}
<div>{('<div class="app-head"><img class="app-icon" src="' + esc(img) + '" alt="' + esc(gm['title']) + '"><div>') if is_app else ''}<h1 style="margin:0 0 6px;font-size:22px">{esc(gm['title'])}</h1>
<div class="row"><span class="tag">{esc(gm['platform'])}</span><span class="tag">{esc(gm['genre'])}</span>
<span class="free-badge lx-free-badge">👑 100% Free</span><span class="rating">{esc(rating_txt)}</span><span class="rating">by {esc(gm['dev_name'])}</span></div>{'</div></div>' if is_app else ''}
{facts_html}
<div id="gameActions" class="row"></div>
<p class="desc" style="max-height:none;white-space:pre-wrap">{esc(gm['description'])}</p>
{req_html}{log_html}
</div></div>
<p style="margin-top:28px">{back}</p>
</main>
<footer>👑 {SITE_NAME} · LEVEL UP YOUR WORLD · Independent games, made by independent creators · Always free, no ads</footer>
<script src="/static/js/common.js"></script>
<script src="/static/js/game.js"></script>
</body></html>"""


UNAVAILABLE_HTML = """<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex"><script src="/static/js/i18n.js"></script><title>PRO LOZIEX</title><link rel="stylesheet" href="/static/css/style.css"></head>
<body><header class="top"><a class="brand" href="/" style="text-decoration:none;color:inherit"><span class="mark">👑</span><span>PRO LOZIEX</span></a></header>
<main class="wrap" style="max-width:600px;text-align:center;padding-top:60px"><h2>This item is temporarily unavailable</h2>
<p style="color:#a99bb9">It has been paused by the store team. Please check back later.</p><p><a href="/" style="color:#c57cff">← Back to the store</a></p></main></body></html>"""


def serve_item_page(gid, slug, want_kind):
    r = fetch_game(gid)
    if not r or r["status"] != "approved":
        return "Not found", 404
    if not is_public(r) and not viewer_privileged(r):
        if r["visibility"] == "paused":
            return Response(UNAVAILABLE_HTML, 503, {"Content-Type": "text/html; charset=utf-8", "Retry-After": "86400"})
        return "Not found", 404
    canon = r["slug"] or make_slug(r["title"], r["id"])
    if r["kind"] != want_kind or (slug is not None and slug != canon):
        return redirect(item_url(r), code=301)
    gm = game_json(r, user_flags(), images=get_images(gid), versions=versions_for(gid))
    return render_item_page(gm, request.url_root.rstrip("/"))


@app.get("/game/<int:gid>/<slug>")
def game_page(gid, slug):
    return serve_item_page(gid, slug, "game")


@app.get("/game/<int:gid>")
def game_page_noslug(gid):
    return _noslug(gid)


@app.get("/app/<int:gid>/<slug>")
def app_page(gid, slug):
    return serve_item_page(gid, slug, "app")


@app.get("/app/<int:gid>")
def app_page_noslug(gid):
    return _noslug(gid)


def _noslug(gid):
    r = fetch_game(gid)
    if not r or not is_public(r):
        return "Not found", 404
    return redirect(item_url(r), code=301)


# --------------------------------------------------------------------- pages
@app.get("/")
def index():
    html = (app.static_folder and (Path(app.static_folder) / "index.html").read_text(encoding="utf-8"))
    html = html.replace("__BASE_URL__", request.url_root.rstrip("/"))
    return html, 200, {"Content-Type": "text/html; charset=utf-8"}


@app.get(ADMIN_PATH)
def admin_page():
    resp = send_from_directory(app.static_folder, "admin.html")
    resp.headers["X-Robots-Tag"] = "noindex, nofollow"
    return resp


@app.get("/robots.txt")
def robots():
    base = request.url_root.rstrip("/")
    return (f"User-agent: *\nDisallow: {ADMIN_PATH}\nDisallow: /api/\nDisallow: /files/\nDisallow: /download/\n"
            f"Sitemap: {base}/sitemap.xml\n"), 200, {"Content-Type": "text/plain"}


@app.get("/sitemap.xml")
def sitemap():
    base = request.url_root.rstrip("/")
    rows = db().execute("SELECT id,slug,title,reviewed_at,kind FROM games WHERE status='approved' AND visibility='public'").fetchall()
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
           f"<url><loc>{esc(base)}/</loc><changefreq>daily</changefreq><priority>1.0</priority></url>"]
    for r in rows:
        slug = r["slug"] or make_slug(r["title"], r["id"])
        loc = f"{base}/{'app' if r['kind'] == 'app' else 'game'}/{r['id']}/{slug}"
        out.append(f"<url><loc>{esc(loc)}</loc><changefreq>weekly</changefreq><priority>0.8</priority></url>")
    out.append("</urlset>")
    return "\n".join(out), 200, {"Content-Type": "application/xml; charset=utf-8"}


init_db()
migrate()

import systems_v4 as _sys4                       # noqa: E402  (v4 progression/economy helpers)
try:
    _c = connect()
    _sys4.seed(_c)
    _c.commit()
    _c.close()
except Exception:
    app.logger.exception("v4 seed failed")

import owner as owner_mod                      # noqa: E402  (needs the helpers above; registers /api/owner/*)
owner_mod.register(sys.modules[__name__])

import systems_routes as _routes                # noqa: E402  (v4 APIs: reviews/support/contacts/XP/points/shops)
_routes.register(app, db=db, current_user=current_user, login_required=login_required,
                 body=body, ApiError=ApiError, approved_game=approved_game,
                 get_setting=get_setting, audit=audit, user_json=user_json)

import events_v4 as _events                     # noqa: E402  (weekly events + store discounts)
_events.register(app, db=db, current_user=current_user, login_required=login_required,
                 body=body, ApiError=ApiError, audit=audit)

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST", "127.0.0.1"), port=int(os.environ.get("PORT", 5000)))
