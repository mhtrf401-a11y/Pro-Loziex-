"""Minimal RFC 6238 TOTP (Google Authenticator / Authy compatible), standard library only.

The secret is NEVER stored in the code: set OWNER_TOTP_SECRET (base32) in the environment.
Generate one with:  python totp.py
"""
import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote


def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _key(secret):
    s = secret.strip().replace(" ", "").upper()
    return base64.b32decode(s + "=" * (-len(s) % 8))


def code_at(secret, step, digits=6):
    mac = hmac.new(_key(secret), struct.pack(">Q", step), hashlib.sha1).digest()
    off = mac[-1] & 0x0F
    n = (struct.unpack(">I", mac[off:off + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return str(n).zfill(digits)


def verify(secret, code, window=1, now=None):
    """Return the matching time-step (int) or None. `window` allows +-30 s of clock drift."""
    code = "".join(ch for ch in str(code) if ch.isdigit())
    if len(code) != 6:
        return None
    cur = int((time.time() if now is None else now) // 30)
    found = None
    for d in range(-window, window + 1):          # constant-work loop, no early exit
        if hmac.compare_digest(code_at(secret, cur + d), code):
            found = cur + d
    return found


def uri(secret, account, issuer="GameMarket"):
    return f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret}&issuer={quote(issuer)}&digits=6&period=30"


if __name__ == "__main__":
    s = new_secret()
    print("Set this as OWNER_TOTP_SECRET (keep it private, never commit it):")
    print(s)
    print("\nOr add this URI to your authenticator app (QR generators work offline too):")
    print(uri(s, "owner"))
