/* GameMarket v7 front-end: rank progress + perks, ranks page, developer/admin request inbox (priority order). */
(() => {
  const { h, api, toast } = GM;
  const $ = (s) => document.querySelector(s);
  const T = (s) => (window.GMI18N ? GMI18N.t(s) : s);
  const NEXT = { none: "bronze", bronze: "silver", silver: "gold" };
  const NAME = { none: "No rank", bronze: "Bronze", silver: "Silver", gold: "Gold" };
  const ORDER = ["none", "bronze", "silver", "gold"];
  const PRIORITY_KEY = { normal: "Normal priority", high: "High priority", highest: "Highest priority" };
  let infoCache = null;

  async function ranksInfo() {
    if (!infoCache) infoCache = await api("/api/ranks/info");
    return infoCache;
  }

  /* perks a player with `rank` has, including every lower rank's perks (perks accumulate upward) */
  function perksUpTo(rank, perks) {
    const upto = ORDER.slice(1, ORDER.indexOf(rank) + 1);
    return perks.filter((p) => upto.includes(p.rank) && p.perk_key !== "reward_bonus");
  }

  function perkNodes(list) {
    if (!list.length) return [h("p", { class: "muted" }, T("No rank yet. Reach 50 lifetime points to unlock Bronze."))];
    return list.map((p) => h("div", { class: "request" },
      h("div", { class: "grow" }, h("b", {}, NAME[p.rank] + " · " + p.perk_key.replace(/_/g, " ")),
        h("small", {}, p.description))));
  }

  /* shown inside the profile page: progress bar to next rank + perks */
  async function rankPanel(box) {
    try {
      const [{ progress }, info] = await Promise.all([api("/api/my/progress"), ranksInfo()]);
      const cur = progress.rank, next = NEXT[cur];
      const total = progress.points_total;
      const from = cur === "none" ? 0 : info.thresholds[cur];
      const to = next ? info.thresholds[next] : null;
      const pct = next ? Math.max(0, Math.min(100, ((total - from) / (to - from)) * 100)) : 100;
      box.append(h("div", { class: "box rank-frame rank-" + cur },
        h("h3", {}, T("Rank progress")),
        h("div", { class: "progress" }, h("i", { style: "width:" + Math.round(pct) + "%" })),
        h("p", { class: "muted" }, next
          ? `${total} / ${to} · ${to - total} ${T("points to")} ${NAME[next]}`
          : T("Highest rank reached")),
        h("h3", { class: "sub" }, T("Rank perks")),
        h("div", {}, ...perkNodes(perksUpTo(cur, info.perks)))));
    } catch (e) { /* signed out or offline: profile page already shows its own message */ }
  }

  /* ranks page */
  async function renderRanks() {
    const box = $("#ranksPage");
    if (!box) return;
    box.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
    try {
      const info = await ranksInfo();
      let mine = null;
      try { mine = (await api("/api/my/progress")).progress.rank; } catch (e) { mine = null; }
      const cards = ["bronze", "silver", "gold"].map((r) => h("article", { class: "box rank-frame rank-" + r },
        h("h3", {}, NAME[r] + (mine === r ? "  ✓ " + T("your rank") : "")),
        h("p", { class: "muted" }, `${T("Starts at")} ${info.thresholds[r]} ${T("lifetime points")}`),
        h("p", { class: "muted" }, `${T("One-time bonus")}: +${info.bonuses[r]} ${T("points")}`),
        h("h4", { class: "sub" }, T("Perks")),
        ...perkNodes(info.perks.filter((p) => p.rank === r && p.perk_key !== "reward_bonus"))));
      box.replaceChildren(h("h2", {}, T("Ranks")),
        h("p", {}, T("Ranks are earned from lifetime points. Spending points never lowers your rank.")),
        ...cards);
    } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  /* developer + admin request inbox, ordered by priority (rank + waiting time) */
  async function renderInbox() {
    const box = $("#inboxPage");
    if (!box) return;
    box.replaceChildren(h("h2", {}, T("Developer requests")),
      h("p", {}, T("Ordered by priority: rank first, and waiting time raises any request so nothing is ignored.")),
      h("div", { class: "admin-list", id: "inboxList" }, h("div", { class: "empty" }, T("Loading…"))));
    try {
      const { contacts } = await api("/api/dev/contacts");
      const list = $("#inboxList");
      list.replaceChildren();
      if (!contacts.length) list.append(h("div", { class: "empty" }, T("No requests yet.")));
      contacts.forEach((c) => {
        const p = c.priority || { label: "normal", waited_hours: 0 };
        const actions = c.status === "pending" ? h("div", { class: "row" },
          h("button", { class: "btn", onclick: () => respond(c.id, "accept") }, T("Accept")),
          h("button", { class: "btn ghost", onclick: () => respond(c.id, "reject") }, T("Reject"))) : null;
        list.append(h("div", { class: "box" },
          h("div", { class: "row" }, h("b", {}, c.player_name), h("span", { class: "rank-badge rank-" + (c.rank || "none") }, NAME[c.rank || "none"]),
            h("span", { class: "tag" }, c.game_title), h("span", { class: "tag" }, T(PRIORITY_KEY[p.label] || p.label)),
            h("span", { class: "tag" }, c.status)),
          h("small", { class: "muted" }, `${T("waiting")}: ${p.waited_hours} ${T("hours")}`),
          actions));
      });
    } catch (e) { box.querySelector("#inboxList")?.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  async function respond(id, action) {
    try {
      await api(`/api/dev/contacts/${id}/respond`, { method: "POST", body: { action } });
      toast(action === "accept" ? T("Accepted") : T("Rejected"));
      renderInbox();
    } catch (e) { toast(e.message, true); }
  }

  window.GMv7 = { rankPanel, renderRanks, renderInbox };

  const PAGES = { "#/ranks": "ranksPage", "#/inbox": "inboxPage" };
  window.addEventListener("hashchange", () => {
    const r = location.hash;
    const active = PAGES[r];
    if (!active) return;
    const hero = document.getElementById("hero"), store = document.getElementById("storePage");
    if (hero) hero.hidden = true;
    if (store) store.hidden = true;
    for (const id of [...Object.values(PAGES), "eventsPage", "storesPage", "profilePage", "supportPage"]) {
      const el = document.getElementById(id);
      if (el) el.classList.toggle("active", id === active);
    }
    window.scrollTo(0, 0);
    if (r === "#/ranks") renderRanks();
    else renderInbox();
  });
})();
