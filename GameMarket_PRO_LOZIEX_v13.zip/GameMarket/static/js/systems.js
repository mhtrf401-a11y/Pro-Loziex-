/* GameMarket v4 front-end: reviews (0.5 steps), stores, profile, support, dev contact. Uses existing GM helpers + styles. */
(() => {
  const { h, api, toast, openModal } = GM;
  const $ = (s) => document.querySelector(s);
  const RANK_AR = { none: "بدون رتبة", bronze: "برونزي Bronze", silver: "فضي Silver", gold: "ذهبي Gold" };
  const T = (s) => (window.GMI18N ? GMI18N.t(s) : s);
  const priceTags = (it) => {
    if (!it.discount) return [h("span", { class: "tag" }, it.price + " pts")];
    return [h("span", { class: "tag strike" }, it.original_price + " pts"),
      h("span", { class: "tag hot" }, `${it.price} pts · -${it.discount.pct}% · ${T("until")} ${new Date(it.discount.ends_at).toLocaleString()}`)];
  };

  async function renderStores() {
    const tabs = $("#storeTabs"), box = $("#storeCards");
    if (!tabs || !box) return;
    tabs.replaceChildren();
    box.replaceChildren(h("div", { class: "empty" }, "Loading…"));
    const defs = [["normal", "Normal"], ["pro", "Pro (Silver+)"], ["promax", "Pro Max (Gold)"]];
    let cur = "normal";
    const draw = async () => {
      try {
        const r = await api("/api/shop?store=" + cur);
        box.replaceChildren();
        if (!r.items.length) box.append(h("div", { class: "empty" }, "No items in this store yet."));
        r.items.forEach((it) => {
          let css = {};
          try { css = JSON.parse(it.css || "{}"); } catch {}
          const card = h("article", { class: "card" },
            h("div", { class: "cover", style: "display:grid;place-items:center;min-height:120px;" },
              h("div", { style: "padding:18px;text-align:center;" + Object.entries(css).map(([k, v]) => k + ":" + v).join(";") },
                h("div", { style: "font-size:34px" }, it.kind === "badge" ? (css.badge || "🎖") : "🎨"),
                h("div", { class: "name" }, it.name_en))),
            h("div", { class: "info" }, h("div", { class: "name" }, it.name_en + " · " + it.name_ar),
              h("div", { class: "meta" }, h("span", { class: "tag" }, it.kind), ...priceTags(it)),
              h("div", { class: "bottom" },
                it.owned ? h("button", { class: "btn ghost", onclick: async () => { try { await api("/api/shop/equip/" + it.id, { method: "POST" }); toast("Equipped!"); } catch (e) { toast(e.message, true); } } }, "Equip")
                         : h("button", { class: "btn", onclick: async () => { try { await api("/api/shop/" + it.id + "/buy", { method: "POST" }); toast("Purchased!"); draw(); } catch (e) { toast(e.message, true); } } }, "Buy"))));
          box.append(card);
        });
      } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
    };
    defs.forEach(([v, l]) => tabs.append(h("button", { class: "chip" + (v === cur ? " on" : ""), onclick: (ev) => {
      cur = v; tabs.querySelectorAll(".chip").forEach((c) => c.classList.remove("on")); ev.target.classList.add("on"); draw();
    } }, l)));
    draw();
  }

  async function renderProfile() {
    const box = $("#profileBox");
    if (!box) return;
    try {
      const { user, progress } = await api("/api/my/progress");
      const pct = Math.round((progress.xp_into_level / progress.xp_for_level) * 100);
      box.replaceChildren(h("div", { class: "box rank-frame rank-" + progress.rank },
        h("h3", {}, user.name + " ", h("span", { class: "tag" }, "Lv " + progress.level),
          h("span", { class: "rank-badge rank-" + progress.rank }, RANK_AR[progress.rank] || progress.rank)),
        h("p", { class: "muted" }, `XP ${progress.xp} · ${progress.xp_into_level}/${progress.xp_for_level} to next level`),
        h("div", { class: "progress" }, h("i", { style: "width:" + pct + "%" })),
        h("p", { class: "muted" }, `Rank: ${progress.rank} · Lifetime points: ${progress.points_total} · Spendable balance: ${progress.points_balance}`),
        h("h3", { class: "sub" }, "Achievements"),
        h("div", {}, ...(progress.achievements.length ? progress.achievements.map((a) => h("span", { class: "tag" }, "🏆 " + a.name)) : [h("span", { class: "muted" }, "No achievements yet.")])) ,
        h("h3", { class: "sub" }, "My items"),
        h("div", {}, ...(progress.items.length ? progress.items.map((it) => h("span", { class: "tag" }, `${it.name_en}${it.equipped ? " ✓" : ""}`)) : [h("span", { class: "muted" }, "No items yet — visit the Stores page.")]))));
    } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
    if (window.GMv7) GMv7.rankPanel(box);
  }

  async function renderSupport() {
    const box = $("#supportBox");
    if (!box) return;
    box.replaceChildren(h("div", { class: "empty" }, "Loading…"));
    try {
      const { tickets } = await api("/api/support/tickets");
      const subj = h("input", { placeholder: "Subject", maxlength: 120, style: "width:100%" });
      const msg = h("textarea", { class: "small", placeholder: "Describe the issue (account, download, report, suggestion)…", style: "width:100%" });
      const send = h("button", { class: "btn", onclick: async () => {
        try { await api("/api/support/tickets", { method: "POST", body: { subject: subj.value, message: msg.value } }); toast("Ticket sent to GameMarket support."); renderSupport(); }
        catch (e) { toast(e.message, true); }
      } }, "Send to GameMarket support");
      const list = h("div", { class: "admin-list", style: "margin-top:12px" });
      tickets.forEach((t) => list.append(h("div", { class: "request" },
        h("div", { class: "grow" }, h("b", {}, t.subject), h("small", {}, t.status + " · " + t.updated_at)),
        h("button", { class: "link-btn", onclick: () => openTicket(t.id) }, "Open"))));
      const chats = h("div", { class: "admin-list", style: "margin-top:12px" });
      try {
        const { contacts } = await api("/api/my/contacts");
        contacts.forEach((c) => chats.append(h("div", { class: "request" },
          h("div", { class: "grow" }, h("b", {}, c.game_title || ("Game " + c.game_id)), h("small", {}, c.status)),
          h("button", { class: "link-btn", onclick: () => openChat(c.id) }, "Chat"))));
      } catch {}
      box.replaceChildren(h("div", { class: "box" }, h("h3", {}, "New support ticket"), subj, msg, send),
        h("h3", { class: "sub" }, "My tickets"), list,
        h("h3", { class: "sub" }, "Developer chats"), chats,
        h("p", { class: "muted" }, "To contact a developer, open any game and use “Contact developer”. The developer must accept before chatting."));
    } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  async function openTicket(id) {
    try {
      const { ticket, replies } = await api("/api/support/tickets/" + id);
      const list = h("div", { class: "stack" },
        h("p", {}, ticket.message),
        ...replies.map((r) => h("p", {}, h("b", {}, (r.author_role || "") + ": "), r.message)));
      const inp = h("input", { placeholder: "Write a reply…", style: "width:100%" });
      const close = openModal(h("div", { class: "stack" }, h("h3", {}, ticket.subject), list, inp,
        h("button", { class: "btn", onclick: async () => {
          try { await api(`/api/support/tickets/${id}/reply`, { method: "POST", body: { message: inp.value } }); close(); toast("Sent."); }
          catch (e) { toast(e.message, true); }
        } }, "Reply")));
    } catch (e) { toast(e.message, true); }
  }

  async function openChat(id) {
    try {
      const { status, messages } = await api("/api/contacts/" + id + "/messages");
      const list = h("div", { class: "stack" }, ...(messages.length ? messages.map((m) => h("p", {}, h("b", {}, (m.sender_name || "") + ": "), m.message)) : [h("p", { class: "muted" }, status === "pending" ? "Waiting for the developer to accept…" : "No messages yet.")]));
      const inp = h("input", { placeholder: "Write a message…", style: "width:100%" });
      const close = openModal(h("div", { class: "stack" }, h("h3", {}, "Chat"), list, inp,
        h("button", { class: "btn", onclick: async () => {
          try { await api(`/api/contacts/${id}/messages`, { method: "POST", body: { message: inp.value } }); close(); openChat(id); }
          catch (e) { toast(e.message, true); }
        } }, "Send")));
    } catch (e) { toast(e.message, true); }
  }

  window.GMv4 = { openChat, openTicket, renderStores, renderProfile, renderSupport,
    contactDev: async (gid) => {
      try { const r = await api(`/api/games/${gid}/contact`, { method: "POST" }); toast("Request sent (" + r.status + ")."); }
      catch (e) { toast(e.message, true); }
    },
    submitReview: async (gid, stars, text) => {
      try { const r = await api(`/api/games/${gid}/review`, { method: "POST", body: { stars, review_text: text } }); toast(`Saved (${r.sentiment})`); return r; }
      catch (e) { toast(e.message, true); }
    } };

  const MAP = { "#/stores": "storesPage", "#/profile": "profilePage", "#/support": "supportPage" };
  /* ----- game page: reviews + contact developer ----- */
  async function enhanceGamePage() {
    const actions = document.getElementById("gameActions");
    const dataEl = document.getElementById("gm-data");
    if (!actions || !dataEl) return;
    let gid = null;
    try { gid = JSON.parse(dataEl.textContent).id; } catch { return; }
    const wrap = document.createElement("div");
    wrap.className = "box";
    actions.after(wrap);
    const paint = async () => {
      let revs = [];
      try { revs = (await api(`/api/games/${gid}/reviews`)).reviews; } catch {}
      const pos = revs.filter((r) => r.sentiment === "positive").length;
      wrap.replaceChildren();
      const { h: hh } = GM;
      wrap.append(hh("h3", {}, `Reviews (${revs.length}) · ${pos} positive`));
      const sel = hh("select", {}, [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5].map((v) => hh("option", { value: v }, v + " ★")));
      sel.value = "5";
      const txt = hh("textarea", { class: "small", placeholder: "Write a review (optional, editable later)…", style: "width:100%" });
      wrap.append(hh("div", { class: "stack" }, hh("div", { class: "row" }, hh("span", { class: "rating" }, "Your rating:"), sel),
        txt,
        hh("div", { class: "row" },
          hh("button", { class: "btn", onclick: async () => {
            try { await api(`/api/games/${gid}/review`, { method: "POST", body: { stars: parseFloat(sel.value), review_text: txt.value } }); toast("Review saved."); paint(); }
            catch (e) { toast(e.message, true); }
          } }, "Save review"),
          hh("button", { class: "btn ghost", onclick: async () => {
            try { const r = await api(`/api/games/${gid}/contact`, { method: "POST" }); toast("Contact request: " + r.status); }
            catch (e) { toast(e.message, true); }
          } }, "Contact developer"))));
      const list = hh("div", { class: "admin-list", style: "margin-top:10px" });
      revs.slice(0, 30).forEach((r) => list.append(hh("div", { class: "request" },
        hh("div", { class: "grow" }, hh("b", {}, `${r.user_name} · ${r.stars} ★ `),
          hh("span", { class: "tag" }, r.sentiment === "positive" ? "إيجابية" : "سلبية"),
          r.review_text ? hh("div", { class: "desc" }, r.review_text) : null))));
      wrap.append(list);
    };
    paint();
  }
  enhanceGamePage();

  /* ----- v5: weekly events ----- */
  const EVENT_RE = /^#\/events(?:\/(\d+))?$/;
  const coverSrc = (c) => (!c ? "" : c.startsWith("https://") ? c : "/media/cover/" + c);
  const when = (iso) => (iso ? new Date(iso).toLocaleString() : "");

  async function renderEvents() {
    const box = $("#eventsPage");
    if (!box) return;
    const grid = h("div", { class: "ev-grid" }, h("div", { class: "empty" }, T("Loading…")));
    box.replaceChildren(h("h2", {}, T("Weekly events")),
      h("p", {}, T("Complete stages in a featured game and earn GameMarket Points. Rewards are granted after a review.")),
      grid);
    try {
      const { events } = await api("/api/events");
      grid.replaceChildren();
      if (!events.length) grid.append(h("div", { class: "empty" }, T("No events yet.")));
      events.forEach((e) => grid.append(h("article", { class: "ev-card", onclick: () => (location.hash = "#/events/" + e.id) },
        h("img", { src: coverSrc(e.game_cover), alt: e.game_title, loading: "lazy" }),
        h("div", { class: "ev-body" },
          h("div", { class: "name" }, e.title),
          h("div", { class: "meta" }, h("span", { class: "tag" }, e.game_title),
            h("span", { class: "tag state-" + e.state }, T(e.state))),
          h("small", { class: "muted" }, when(e.starts_at) + " → " + when(e.ends_at)),
          h("small", { class: "muted" }, e.stage_count + " " + T("stages"))))));
    } catch (e) { grid.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  function stageCard(s, ev, reload) {
    const m = s.mine;
    let note = null, action = null;
    if (ev.state === "upcoming") note = T("Not open yet");
    else if (ev.state === "ended") note = T("Event ended");
    else if (m.pending) note = T("Under review");
    else if (m.approved && !s.repeatable) note = T("Completed");
    else if (!m.can_claim) note = T("Not available for your account");
    else {
      const ta = h("textarea", { class: "small", maxlength: 1000, style: "width:100%",
        placeholder: T("Describe how you completed this stage (what you did, a screenshot link, the time…)") });
      action = h("div", { class: "stack" }, ta,
        h("button", { class: "btn", onclick: async () => {
          try {
            await api(`/api/events/stages/${s.id}/claim`, { method: "POST", body: { evidence: ta.value } });
            toast(T("Submitted for review")); reload();
          } catch (e) { toast(e.message, true); }
        } }, T("Submit proof")));
    }
    return h("section", { class: "ev-stage" },
      h("div", { class: "row" }, h("b", {}, `#${s.stage_no} ${s.title}`),
        h("span", { class: "tag" }, `+${s.reward_points} pts`),
        h("span", { class: "tag" }, s.repeatable ? T("Repeatable") : T("Once"))),
      s.description ? h("p", { class: "muted" }, s.description) : null,
      h("small", { class: "muted" }, `${T("Completed")}: ${m.approved} · ${T("Earned")}: ${m.points} pts`),
      note ? h("div", { class: "tag" }, note) : null,
      action);
  }

  async function renderEvent(id) {
    const box = $("#eventsPage");
    if (!box) return;
    box.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
    try {
      const { event: ev } = await api("/api/events/" + id);
      const parts = [
        h("a", { href: "#/events", class: "link-btn" }, "← " + T("All events")),
        h("div", { class: "ev-head" },
          h("img", { src: coverSrc(ev.game_cover), alt: ev.game_title }),
          h("div", {},
            h("h2", {}, ev.title),
            h("div", { class: "meta" }, h("span", { class: "tag" }, ev.game_title),
              h("span", { class: "tag state-" + ev.state }, T(ev.state)),
              h("span", { class: "tag" }, T("My points") + ": " + ev.my_points)),
            h("small", { class: "muted" }, when(ev.starts_at) + " → " + when(ev.ends_at)))),
      ];
      if (ev.description) parts.push(h("p", { class: "ev-desc" }, ev.description));
      ev.stages.forEach((s) => parts.push(stageCard(s, ev, () => renderEvent(id))));
      box.replaceChildren(...parts);
    } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  const _route = () => {
    const r = location.hash;
    const m = r.match(EVENT_RE);
    const active = m ? "eventsPage" : MAP[r];
    if (!active) return;
    const hero = document.getElementById("hero"), store = document.getElementById("storePage");
    if (hero) hero.hidden = true;
    if (store) store.hidden = true;
    for (const id of [...Object.values(MAP), "eventsPage"]) {
      const el = document.getElementById(id);
      if (el) el.classList.toggle("active", id === active);
    }
    window.scrollTo(0, 0);
    if (m) { if (m[1]) renderEvent(+m[1]); else renderEvents(); }
    else if (r === "#/stores") renderStores();
    else if (r === "#/profile") renderProfile();
    else if (r === "#/support") renderSupport();
  };
  window.addEventListener("hashchange", _route);
  _route();
})();
