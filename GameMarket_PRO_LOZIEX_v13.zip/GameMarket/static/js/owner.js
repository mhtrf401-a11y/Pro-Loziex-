(() => {
  const { h, api, loadMe, toast, date, size } = GM;
  const T = (s) => GMI18N.t(s);
  const app = document.getElementById("app");
  const logoutBtn = document.getElementById("logout");
  const nf = (n) => Number(n || 0).toLocaleString();
  const NS = "http://www.w3.org/2000/svg";
  let tab = "overview";
  let daysRange = 30;

  logoutBtn.addEventListener("click", async () => {
    try { await api("/api/owner/logout", { method: "POST" }); } catch {}
    start();
  });

  /* ---------- small UI kit ---------- */
  const stat = (label, value, sub) => h("div", { class: "stat" }, h("b", {}, typeof value === "string" ? value : nf(value)), h("span", {}, T(label)), sub ? h("small", {}, sub) : null);
  const card = (title, ...kids) => h("div", { class: "box ocard" }, h("h3", { class: "sub" }, T(title)), ...kids);
  const warnText = {
    data_may_be_lost: "Data can be erased on every redeploy: set DATABASE_URL and S3_* on Render.",
    cookie_not_secure: "COOKIE_SECURE=1 is not set.", no_secret_key: "SECRET_KEY is not set on Render.",
    no_owner_2fa: "Owner 2FA is off: set OWNER_TOTP_SECRET (run python totp.py).",
    owner_password_short: "OWNER_PASSWORD is shorter than 12 characters.",
    no_play_origin: "PLAY_ORIGIN is not set: HTML5 games share a sandboxed origin (localStorage is in-memory).",
    builtin_scan_only: "Only the built-in upload checks run. Set CLAMAV_HOST for real antivirus scanning.",
    storage_almost_full: "Storage is above 85% of its quota.", backup_stale: "The last backup is old.",
    no_backup_yet: "No backup has been made yet.",
  };
  function warnings(list) {
    if (!list || !list.length) return null;
    return h("div", { class: "notice warn" }, h("b", {}, T("Warnings") + ": "), h("ul", {}, ...list.map((w) => h("li", {}, warnText[w] || w))));
  }
  function table(head, rows, empty) {
    if (!rows.length) return h("div", { class: "empty" }, empty);
    return h("div", { class: "tblwrap" }, h("table", { class: "tbl" },
      h("thead", {}, h("tr", {}, ...head.map((t) => h("th", {}, T(t))))),
      h("tbody", {}, ...rows.map((r) => h("tr", {}, ...r.map((c) => h("td", {}, c)))))));
  }
  function btn(label, fn, cls = "link-btn") { return h("button", { class: cls, type: "button", onclick: fn }, T(label)); }

  /* ---------- interactive SVG line/area chart with tooltip ---------- */
  function svgEl(tag, attrs = {}, ...kids) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    kids.forEach((k) => e.appendChild(k));
    return e;
  }
  function lineChart(series, keys) {
    const W = 760, H = 220, P = 28;
    const colors = ["#c57cff", "#ffc24e", "#7be0b5", "#ff8fa6"];
    const max = Math.max(1, ...series.flatMap((d) => keys.map((k) => d[k.key] || 0)));
    const x = (i) => P + (i * (W - 2 * P)) / Math.max(1, series.length - 1);
    const y = (v) => H - P - (v / max) * (H - 2 * P);
    const svg = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, class: "chart", role: "img", preserveAspectRatio: "none" });
    for (let g = 0; g <= 4; g++) {
      const yy = P + (g * (H - 2 * P)) / 4;
      svg.appendChild(svgEl("line", { x1: P, x2: W - P, y1: yy, y2: yy, stroke: "#2d2040", "stroke-width": 1 }));
    }
    keys.forEach((k, ki) => {
      const pts = series.map((d, i) => `${x(i)},${y(d[k.key] || 0)}`).join(" ");
      svg.appendChild(svgEl("polyline", { points: pts, fill: "none", stroke: colors[ki % colors.length], "stroke-width": 2.2, "stroke-linejoin": "round" }));
    });
    const tip = h("div", { class: "tip", hidden: true });
    const hit = svgEl("rect", { x: 0, y: 0, width: W, height: H, fill: "transparent" });
    hit.addEventListener("mousemove", (e) => {
      const r = svg.getBoundingClientRect();
      const i = Math.round(((e.clientX - r.left) / r.width * W - P) / ((W - 2 * P) / Math.max(1, series.length - 1)));
      const d = series[Math.max(0, Math.min(series.length - 1, i))];
      tip.hidden = false;
      tip.replaceChildren(h("b", {}, d.day), ...keys.map((k) => h("div", {}, `${T(k.label)}: ${nf(d[k.key])}`)));
      tip.style.left = Math.min(r.width - 150, Math.max(0, (e.clientX - r.left) - 40)) + "px";
    });
    hit.addEventListener("mouseleave", () => (tip.hidden = true));
    svg.appendChild(hit);
    const legend = h("div", { class: "legend" }, ...keys.map((k, ki) => h("span", {}, h("i", { style: `background:${colors[ki % colors.length]}` }), T(k.label))));
    return h("div", { class: "chartbox" }, legend, h("div", { class: "chartwrap" }, svg, tip),
      h("div", { class: "axis" }, h("span", {}, series[0] && series[0].day), h("span", {}, "max " + nf(max)), h("span", {}, series.at(-1) && series.at(-1).day)));
  }
  function barList(items, label, valueKey) {
    const max = Math.max(1, ...items.map((i) => i[valueKey] || 0));
    if (!items.length) return h("div", { class: "empty" }, T("Nothing here yet."));
    return h("div", { class: "hbars" }, ...items.map((i) => h("div", { class: "hbar", title: `${i[label]}: ${nf(i[valueKey])}` },
      h("span", { class: "hname" }, i[label]), h("span", { class: "htrack" }, h("i", { style: `width:${Math.round((i[valueKey] / max) * 100)}%` })), h("b", {}, nf(i[valueKey])))));
  }
  function donut(parts) {
    const total = parts.reduce((a, p) => a + p.value, 0) || 1;
    const colors = ["#c57cff", "#ffc24e", "#7be0b5", "#ff8fa6"];
    let acc = 0;
    const R = 46, C = 2 * Math.PI * R;
    const svg = svgEl("svg", { viewBox: "0 0 120 120", class: "donut", role: "img" });
    parts.forEach((p, i) => {
      const len = (p.value / total) * C;
      svg.appendChild(svgEl("circle", { cx: 60, cy: 60, r: R, fill: "none", stroke: colors[i % 4], "stroke-width": 16,
        "stroke-dasharray": `${len} ${C}`, "stroke-dashoffset": -acc, transform: "rotate(-90 60 60)" }));
      acc += len;
    });
    return h("div", { class: "donutbox" }, svg, h("div", { class: "legend col" }, ...parts.map((p, i) =>
      h("span", {}, h("i", { style: `background:${colors[i % 4]}` }), `${T(p.label)} · ${nf(p.value)} (${Math.round((p.value / total) * 100)}%)`))));
  }

  /* ---------- auth ---------- */
  function loginView(msg) {
    logoutBtn.hidden = true;
    const err = h("div", { class: "err", role: "alert" }, msg || "");
    const email = h("input", { type: "email", required: true, autocomplete: "username" });
    const pw = h("input", { type: "password", required: true, autocomplete: "current-password" });
    const code = h("input", { inputmode: "numeric", autocomplete: "one-time-code", maxlength: 6, placeholder: "123456" });
    const btn = h("button", { class: "btn" }, T("Sign in"));
    app.replaceChildren(h("div", { class: "box", style: "max-width:380px;margin:30px auto" },
      h("form", { class: "stack", onsubmit: async (e) => {
        e.preventDefault(); btn.disabled = true; err.textContent = "";
        try { await api("/api/owner/login", { method: "POST", body: { email: email.value, password: pw.value, code: code.value } }); start(); }
        catch (x) { err.textContent = x.message; btn.disabled = false; }
      } }, h("div", { class: "field" }, h("label", {}, T("Email")), email),
        h("div", { class: "field" }, h("label", {}, T("Password")), pw),
        h("div", { class: "field" }, h("label", {}, "2FA code (if enabled)"), code),
        err, btn)));
  }

  /* ---------- tabs ---------- */
  const TABS = [["overview", "Overview"], ["traffic", "Traffic"], ["content", "Content"], ["users", "Users"],
    ["activity", "Activity"], ["security", "Security"], ["system", "System"], ["settings", "Settings"], ["backups", "Backups"]];

  function shell() {
    const nav = h("nav", { class: "otabs" }, ...TABS.map(([k, l]) => h("button", { type: "button", class: "otab" + (tab === k ? " on" : ""),
      onclick: () => { tab = k; shell(); } }, T(l))));
    const actions = h("div", { class: "oactions" },
      h("select", { onchange: (e) => { daysRange = +e.target.value; shell(); } },
        ...[7, 30, 90, 365].map((n) => h("option", { value: n, selected: n === daysRange }, `${n} d`))),
      h("a", { class: "btn ghost", href: `/api/owner/export.xlsx?days=${daysRange}`, style: "text-decoration:none" }, T("Export Excel")),
      h("button", { class: "btn ghost", type: "button", onclick: () => window.print() }, T("Export PDF")));
    const body = h("div", { id: "obody" }, h("div", { class: "empty" }, T("Loading…")));
    app.replaceChildren(h("div", { class: "ohead" }, nav, actions), body);
    load(body);
  }

  async function load(body) {
    try {
      const view = { overview, traffic, content, users, activity, security, system, settings, backups }[tab];
      const node = await view();
      body.replaceChildren(node);
      GMI18N.apply(body);
    } catch (e) {
      if (e.status === 401) return loginView();
      body.replaceChildren(h("div", { class: "empty" }, e.message));
    }
  }

  /* ---------- overview ---------- */
  async function overview() {
    const s = await api("/api/owner/stats");
    const v = s.visits;
    return h("div", {},
      s.system.data_may_be_lost ? h("div", { class: "notice warn" }, warnText.data_may_be_lost) : null,
      s.maintenance ? h("div", { class: "notice warn" }, "⚠ " + T("Maintenance mode") + " is ON") : null,
      h("div", { class: "stats" }, stat("Views today", v.today.views, nf(v.today.visitors) + " visitors"),
        stat("Views, 7 days", v.week.views, nf(v.week.visitors) + " visitors"),
        stat("Views, 30 days", v.month.views, nf(v.month.visitors) + " visitors"),
        stat("Views, all time", v.total.views, nf(v.total.visitors) + " visitors")),
      card("Page views", lineChart(s.series, [{ key: "views", label: "Page views" }, { key: "visitors", label: "Visitors" }])),
      h("div", { class: "grid2" },
        card("Users", h("div", { class: "stats" }, stat("Players", s.users.players), stat("Developers", s.users.developers),
          stat("Banned", s.users.banned), stat("New users, 24h", s.users.new_24h))),
        card("Content", h("div", { class: "stats" }, stat("Published", s.games.approved), stat("Pending", s.games.pending),
          stat("Rejected", s.games.rejected), stat("Flagged", s.content.flagged))),
      ),
      h("div", { class: "grid2" },
        card("Real downloads", h("div", { class: "stats" }, stat("Downloads", s.engagement.real_downloads), stat("Plays", s.engagement.plays),
          stat("Trials", s.engagement.trials), stat("Library adds", s.engagement.downloads))),
        card("Security, 24h", h("div", { class: "stats" }, stat("Failed logins", s.security.failed_24h), stat("Blocked", s.security.blocked_24h),
          stat("Security events", s.security.events_24h))),
      ),
      card("Most downloaded", table(["Game", "Real downloads", "Rating"],
        s.top_downloads.map((g) => [g.title, nf(g.real_downloads), g.avg_rating ? "★ " + g.avg_rating : "—"]), "No downloads yet.")),
      card("Developers", table(["Name", "Email", "Games", "Published", "Downloads", "Joined", "Status"],
        s.developers.map((d) => [d.name, d.email, nf(d.games), nf(d.published), nf(d.downloads), date(d.created_at), T(d.active ? "Active" : "Disabled")]),
        "No developers yet.")));
  }

  /* ---------- traffic ---------- */
  async function traffic() {
    const t = await api(`/api/owner/traffic?days=${daysRange}`);
    const dv = Object.entries(t.devices).map(([k, n]) => ({ label: k, value: n }));
    return h("div", {},
      card(`Traffic — last ${t.days} days`, lineChart(t.series, [{ key: "views", label: "Page views" }, { key: "visitors", label: "Visitors" },
        { key: "plays", label: "Plays" }, { key: "downloads", label: "Downloads" }])),
      h("div", { class: "grid2" },
        card("Devices", dv.length ? donut(dv) : h("div", { class: "empty" }, T("Nothing here yet."))),
        card("Sign-ups", lineChart(t.series, [{ key: "signups", label: "Sign-ups" }]))),
      h("div", { class: "grid2" },
        card("Most viewed", barList(t.top.views, "title", "n")),
        card("Most played", barList(t.top.plays, "title", "n"))),
      h("div", { class: "grid2" },
        card("Most downloaded", barList(t.top.downloads, "title", "n")),
        card("Trials started", barList(t.top.trials, "title", "n"))));
  }

  /* ---------- content (games & apps) ---------- */
  let contentQ = { kind: "", status: "", q: "", flagged: "", visibility: "", sort: "newest", page: 1 };
  async function content() {
    const qs = new URLSearchParams(Object.entries(contentQ).filter(([, v]) => v !== "" && v !== null && v !== undefined));
    const r = await api("/api/owner/content?" + qs);
    const sel = (key, opts) => h("select", { onchange: (e) => { contentQ[key] = e.target.value; contentQ.page = 1; shell(); } },
      ...opts.map(([v, l]) => h("option", { value: v, selected: contentQ[key] === v }, T(l))));
    const filters = h("div", { class: "filters" },
      sel("kind", [["", "All types"], ["game", "Games"], ["app", "Apps"]]),
      sel("status", [["", "Any status"], ["approved", "Published"], ["pending", "Pending"], ["rejected", "Rejected"]]),
      sel("visibility", [["", "Any visibility"], ["public", "Public"], ["hidden", "Hidden"], ["paused", "Paused"]]),
      sel("sort", [["newest", "Newest"], ["views", "Most viewed"], ["downloads", "Most downloaded"], ["plays", "Most played"], ["title", "Title"]]),
      h("select", { onchange: (e) => { contentQ.flagged = e.target.value; contentQ.page = 1; shell(); } },
        h("option", { value: "" }, T("All scans")), h("option", { value: "1", selected: contentQ.flagged === "1" }, T("Flagged only"))),
      h("input", { type: "search", placeholder: "Search title or developer", value: contentQ.q, onchange: (e) => { contentQ.q = e.target.value.trim(); contentQ.page = 1; shell(); } }));
    const rows = r.items.map((g) => h("tr", {},
      h("td", {}, h("div", { class: "cell" }, h("img", { src: g.cover, alt: "" }), h("div", {}, h("b", {}, g.title), h("small", {}, `${g.kind} · ${g.dev_name}${g.version ? " · v" + g.version : ""}`)))),
      h("td", {}, h("span", { class: "badge st-" + g.status }, T({ approved: "Published", pending: "Pending", rejected: "Rejected" }[g.status]))),
      h("td", {}, T(g.visibility === "public" ? "Public" : g.visibility === "hidden" ? "Hidden" : "Paused")),
      h("td", {}, h("span", { class: g.scan_status && g.scan_status !== "clean" ? "scanbad" : "" }, T(cap(g.scan_status || "unscanned")))),
      h("td", {}, nf(g.views_30d) + " / " + nf(g.views_total)),
      h("td", {}, nf(g.plays) + " / " + nf(g.trials)),
      h("td", {}, nf(g.downloads)),
      h("td", { class: "acts" }, ...itemActions(g))));
    const pages = Math.max(1, Math.ceil(r.total / r.per_page));
    return h("div", {}, filters,
      card(`${nf(r.total)} items`, r.items.length ? h("div", { class: "tblwrap" }, h("table", { class: "tbl" },
        h("thead", {}, h("tr", {}, ...["Title", "Status", "Visibility", "Scan", "Views 30d / total", "Plays / trials", "Downloads", "Actions"].map((x) => h("th", {}, T(x))))),
        h("tbody", {}, ...rows))) : h("div", { class: "empty" }, T("Nothing here yet.")),
        h("div", { class: "pager" },
          btn("‹ Prev", () => { contentQ.page = Math.max(1, r.page - 1); shell(); }, "btn ghost"),
          h("span", {}, `${r.page} / ${pages}`),
          btn("Next ›", () => { contentQ.page = Math.min(pages, r.page + 1); shell(); }, "btn ghost"))));
  }
  const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : "");

  function itemActions(g) {
    const out = [];
    const reload = () => shell();
    const run = (fn, ok) => async () => { try { await fn(); toast(ok); reload(); } catch (e) { toast(e.message, true); } };
    out.push(h("a", { class: "link-btn", href: g.url, target: "_blank", rel: "noopener" }, "Open"));
    if (g.visibility === "public") out.push(btn("Hide", run(() => api(`/api/owner/games/${g.id}/visibility`, { method: "POST", body: { visibility: "hidden" } }), "Hidden")));
    if (g.visibility !== "public") out.push(btn("Show", run(() => api(`/api/owner/games/${g.id}/visibility`, { method: "POST", body: { visibility: "public" } }), "Visible")));
    if (g.visibility !== "paused") out.push(btn("Pause", run(() => api(`/api/owner/games/${g.id}/visibility`, { method: "POST", body: { visibility: "paused" } }), "Paused")));
    if (g.status !== "approved") out.push(btn("Approve", run(() => api(`/api/owner/games/${g.id}/review`, { method: "POST", body: { action: "approve" } }), "Published")));
    if (g.status === "approved") out.push(btn("Unpublish", run(() => api(`/api/owner/games/${g.id}/review`, { method: "POST", body: { action: "unpublish" } }), "Pending")));
    out.push(btn("Versions", () => versionsDialog(g)));
    out.push(btn("Delete", async () => {
      if (!confirm(`Delete "${g.title}" and all its files permanently?`)) return;
      try { await api(`/api/owner/games/${g.id}`, { method: "DELETE", body: { confirm: true } }); toast("Deleted"); reload(); } catch (e) { toast(e.message, true); }
    }, "link-btn danger"));
    return out;
  }

  async function versionsDialog(g) {
    const box = h("div", { class: "vdlg" }, h("h3", {}, `${T("Version history")}: ${g.title}`), h("div", {}, "…"));
    const close = GM.openModal(box, { wide: true });
    try {
      const r = await api(`/api/owner/games/${g.id}/versions`);
      box.replaceChildren(h("h3", {}, `${T("Version history")}: ${g.title}`),
        r.versions.length ? table(["Version", "Notes", "Size", "Date", "Actions"], r.versions.map((v) => [
          "v" + v.version + (v.is_current ? " ✓" : ""), v.notes || "", v.build_size ? size(v.build_size) : "—", date(v.created_at),
          h("span", {}, v.has_build && !v.is_current ? btn("Make live", async () => {
            try { await api(`/api/owner/versions/${v.id}/make-current`, { method: "POST" }); toast("Rolled back"); close(); shell(); } catch (e) { toast(e.message, true); }
          }) : null, !v.is_current ? btn("Delete", async () => {
            try { await api(`/api/owner/versions/${v.id}`, { method: "DELETE" }); toast("Deleted"); close(); versionsDialog(g); } catch (e) { toast(e.message, true); }
          }, "link-btn danger") : null)]), "No versions.") : h("div", { class: "empty" }, "No versions."));
    } catch (e) { box.append(h("div", { class: "err" }, e.message)); }
  }

  /* ---------- users ---------- */
  let userQ = { role: "", status: "", q: "", page: 1 };
  async function users() {
    const qs = new URLSearchParams(Object.entries(userQ).filter(([, v]) => v !== ""));
    const r = await api("/api/owner/users?" + qs);
    const filters = h("div", { class: "filters" },
      h("select", { onchange: (e) => { userQ.role = e.target.value; userQ.page = 1; shell(); } },
        ...[["", "All roles"], ["player", "Players"], ["developer", "Developers"], ["admin", "Admins"]].map(([v, l]) => h("option", { value: v, selected: userQ.role === v }, T(l)))),
      h("select", { onchange: (e) => { userQ.status = e.target.value; userQ.page = 1; shell(); } },
        ...[["", "Any status"], ["active", "Active"], ["banned", "Banned"]].map(([v, l]) => h("option", { value: v, selected: userQ.status === v }, T(l)))),
      h("input", { type: "search", placeholder: "Email or name", value: userQ.q, onchange: (e) => { userQ.q = e.target.value.trim(); userQ.page = 1; shell(); } }));
    const rows = r.users.map((u) => h("tr", {},
      h("td", {}, h("b", {}, u.name), h("small", {}, ` ${u.email}`)),
      h("td", {}, T(cap(u.role))),
      h("td", {}, h("span", { class: "badge " + (u.active ? "st-approved" : "st-rejected") }, T(u.active ? "Active" : "Banned"))),
      h("td", {}, u.role === "developer" ? `${u.games} games` : u.role === "player" ? `${u.library} library` : ""),
      h("td", {}, date(u.created_at)), h("td", {}, u.last_login_at ? date(u.last_login_at) : "—"),
      h("td", { class: "acts" }, u.role === "admin" ? h("span", { class: "muted" }, "—") : u.active
        ? btn("Ban", () => banFlow(u, true), "link-btn danger") : btn("Unban", () => banFlow(u, false), "link-btn"))));
    const pages = Math.max(1, Math.ceil(r.total / r.per_page));
    return h("div", {}, filters,
      card(`${nf(r.total)} accounts`, rows.length ? h("div", { class: "tblwrap" }, h("table", { class: "tbl" },
        h("thead", {}, h("tr", {}, ...["User", "Role", "Status", "Activity", "Joined", "Last login", "Actions"].map((x) => h("th", {}, T(x))))),
        h("tbody", {}, ...rows))) : h("div", { class: "empty" }, T("Nothing here yet.")),
        h("div", { class: "pager" }, btn("‹ Prev", () => { userQ.page = Math.max(1, r.page - 1); shell(); }, "btn ghost"),
          h("span", {}, `${r.page} / ${pages}`), btn("Next ›", () => { userQ.page = Math.min(pages, r.page + 1); shell(); }, "btn ghost"))));
  }
  async function banFlow(u, ban) {
    const box = h("div", { class: "stack" }, h("h3", {}, `${T(ban ? "Ban" : "Unban")}: ${u.email}`));
    const reason = h("input", { placeholder: "Reason (kept in the audit log)", maxlength: 300 });
    const pause = h("input", { type: "checkbox", checked: true });
    const withItems = u.role === "developer";
    box.append(h("div", { class: "field" }, h("label", {}, "Reason"), reason));
    if (withItems) box.append(h("label", { class: "chk" }, pause, ban ? " Pause all of this developer's items" : " Restore paused items"));
    const err = h("div", { class: "err" });
    const ok = h("button", { class: ban ? "btn danger" : "btn", type: "button" }, T(ban ? "Ban" : "Unban"));
    box.append(err, h("div", { class: "row" }, h("button", { class: "btn ghost", type: "button", onclick: () => close() }, T("Cancel")), ok));
    const close = GM.openModal(box);
    ok.onclick = async () => {
      ok.disabled = true;
      try {
        const body = { banned: ban, reason: reason.value.trim() };
        if (withItems) { if (ban) body.pause_games = pause.checked; else body.restore_games = pause.checked; }
        const r = await api(`/api/owner/users/${u.id}/ban`, { method: "POST", body });
        close(); toast(`${ban ? "Banned" : "Unbanned"} · ${r.items_changed || 0} items changed`); shell();
      } catch (e) { err.textContent = e.message; ok.disabled = false; }
    };
  }

  /* ---------- activity ---------- */
  let actState = { group: "", q: "" };
  async function activity() {
    const qs = new URLSearchParams(Object.entries({ group: actState.group, q: actState.q }).filter(([, v]) => v));
    const r = await api("/api/owner/activity?" + qs);
    const filters = h("div", { class: "filters" },
      h("select", { onchange: (e) => { actState.group = e.target.value; shell(); } },
        ...[["", "All events"], ["changes", "Changes (admin/owner/content)"], ["auth", "Sign-ins & sign-ups"], ["security", "Security"], ["system", "System"]]
          .map(([v, l]) => h("option", { value: v, selected: actState.group === v }, T(l)))),
      h("input", { type: "search", placeholder: "Search action, target or detail", value: actState.q, onchange: (e) => { actState.q = e.target.value.trim(); shell(); } }));
    return h("div", {}, filters, card("Activity log (newest first, UTC)",
      table(["Time", "Category", "Actor", "Action", "Target", "Detail", "IP hash"],
        r.events.map((e) => [e.ts.replace("T", " ").slice(0, 19), e.category, `${e.actor_type}${e.actor ? ": " + e.actor : ""}`,
          e.action, e.target || "", e.detail || "", e.ip || ""]), "No events match."),
      r.next ? h("div", { class: "pager" }, h("small", { class: "muted" }, "Showing the latest 50 events. Narrow with filters to find older ones.")) : null));
  }

  /* ---------- security ---------- */
  async function security() {
    const s = await api("/api/owner/security");
    return h("div", {},
      h("div", { class: "stats" }, stat("Failed logins, 24h", s.failed_24h), stat("Blocked attempts, 24h", s.blocked_24h),
        stat("Rate-limited downloads, 24h", s.rate_limited_downloads_24h), stat("Upload scan events, 24h", s.scan_events_24h),
        stat("Banned accounts", s.banned_users)),
      h("div", { class: "grid2" },
        card("Top source addresses (hashed), 24h", barList(s.top_ips.map((x) => ({ ip: x.ip || "?", n: x.n })), "ip", "n")),
        card("Most targeted accounts, 24h", barList(s.top_targets.map((x) => ({ t: x.target, n: x.n })), "t", "n"))),
      card("Flagged uploads", table(["Title", "Developer", "Scan", "Note", "Status"],
        s.flagged.map((f) => [f.title, f.dev_name, T(cap(f.scan_status)), f.scan_note || "", T({ approved: "Published", pending: "Pending", rejected: "Rejected" }[f.status])]),
        "No flagged uploads.")),
      card("Recent security events", table(["Time", "Actor", "Action", "Target", "Detail"],
        s.recent.map((e) => [e.ts.replace("T", " ").slice(0, 19), e.actor_type, e.action, e.target || "", e.detail || ""]), "No events.")),
      card("Owner sign-ins & actions", table(["Time", "Action", "Detail", "IP hash"],
        s.owner_log.map((e) => [e.ts.replace("T", " ").slice(0, 19), e.action, e.detail || "", e.ip || ""]), "None yet.")));
  }

  /* ---------- system ---------- */
  async function system() {
    const s = await api("/api/owner/system");
    const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
    const bytes = (n) => (n == null ? "—" : n > 1073741824 ? (n / 1073741824).toFixed(2) + " GB" : n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : (n / 1024).toFixed(0) + " KB");
    const meter = (label, used, total, extra) => h("div", { class: "meter" }, h("div", { class: "mlabel" }, h("span", {}, T(label)), h("b", {}, extra || `${bytes(used)}${total ? " / " + bytes(total) : ""}`)),
      total ? h("div", { class: "track" }, h("i", { style: `width:${Math.min(100, pct(used, total))}%` })) : null);
    const st = s.storage;
    const parts = Object.entries(st.parts || {}).filter(([, v]) => v > 0);
    const rows = Object.entries(s.database.rows).map(([k, v]) => [k, nf(v)]);
    return h("div", {},
      warnings(s.warnings),
      h("div", { class: "grid2" },
        card("Database", h("div", { class: "stats" }, stat("Type", s.database.type), stat("Ping", s.database.ping_ms + " ms"), stat("Size", bytes(s.database.size))),
          table(["Table", "Rows"], rows, "—")),
        card("Storage", meter("Used", st.used, st.capacity, bytes(st.used) + (st.capacity ? ` of ${bytes(st.capacity)} (${pct(st.used, st.capacity)}%)` : "")),
          meter("Free", st.free, st.capacity, st.free != null ? bytes(st.free) : "not configured"),
          st.error ? h("div", { class: "err" }, st.error) : null,
          parts.length ? donut(parts.map(([k, v]) => ({ label: k, value: v }))) : null,
          h("small", { class: "muted" }, `Kind: ${st.kind} · quota source: ${st.capacity_note}`))),
      h("div", { class: "grid2" },
        card("Server disk", s.disk ? meter("Disk used", s.disk.total - s.disk.free, s.disk.total) : h("div", { class: "empty" }, "—")),
        card("Process", h("div", { class: "stats" }, stat("Uptime", Math.floor(s.server.uptime_seconds / 3600) + " h"),
          stat("Memory", bytes(s.server.rss)), stat("Threads", s.server.threads), stat("CPUs", s.server.cpus || 0)),
          h("small", { class: "muted" }, `Python ${s.server.python} · ${s.server.platform}${s.server.load ? " · load " + s.server.load.join(" / ") : ""}`))),
      card("Configuration", table(["Setting", "Value"], [
        ["Secure cookies", s.config.cookie_secure ? "on" : "off"], ["SECRET_KEY from environment", s.config.secret_key_from_env ? "yes" : "no"],
        ["Behind proxy (Render)", s.config.behind_proxy ? "yes" : "no"], ["Owner 2FA", s.config.owner_2fa ? "on" : "off"],
        ["Play isolation", s.config.play_isolation], ["Upload scanner", s.config.scan_engine], ["Block suspicious uploads", s.config.scan_blocks_suspicious ? "yes" : "no"],
      ], "—")));
  }

  /* ---------- settings ---------- */
  async function settings() {
    const r = await api("/api/owner/settings");
    const s = r.settings;
    const field = (label, el) => h("div", { class: "field" }, h("label", {}, T(label)), el);
    const chk = (k, label) => h("label", { class: "chk" }, h("input", { type: "checkbox", checked: s[k] === "1", "data-k": k }), " " + T(label));
    const txt = (k, label, max = 300) => field(label, h("input", { "data-k": k, value: s[k] || "", maxlength: max }));
    const form = h("div", { class: "stack" },
      chk("maintenance", "Maintenance mode"),
      txt("maintenance_message", "Maintenance message shown to visitors"),
      chk("allow_registration", "Allow new sign-ups"),
      chk("allow_submissions", "Allow new game/app submissions"),
      txt("announcement", "Announcement banner (empty = none)"),
      field("Trial length in seconds (empty = default " + r.default_trial_seconds + ")", h("input", { "data-k": "trial_seconds", value: s.trial_seconds || "", inputmode: "numeric" })));
    const msg = h("div", { class: "err" });
    const save = h("button", { class: "btn", type: "button", onclick: async () => {
      const body = {};
      form.querySelectorAll("[data-k]").forEach((el) => { body[el.dataset.k] = el.type === "checkbox" ? el.checked : el.value; });
      try { await api("/api/owner/settings", { method: "POST", body }); toast("Saved"); shell(); } catch (e) { msg.textContent = e.message; }
    } }, T("Save"));
    return h("div", {}, card("Store settings", form, msg, h("div", { class: "row" }, save)));
  }

  /* ---------- backups ---------- */
  async function backups() {
    const r = await api("/api/owner/backups");
    const now = h("button", { class: "btn", type: "button", onclick: async () => {
      try { await api("/api/owner/backups", { method: "POST" }); toast("Backup created"); shell(); } catch (e) { toast(e.message, true); }
    } }, T("Create backup now"));
    return h("div", {},
      card("Backups", h("p", { class: "muted" }, `Automatic every ${r.interval_hours || "—"} h · keeps ${r.keep} · last: ${r.last ? date(r.last) : "never"} · stored in ${r.storage === "s3" ? "your R2 bucket" : "local disk"}`),
        h("p", { class: "muted" }, "Backups contain the database (users' emails and password hashes, activity, settings). Keep downloaded copies private."),
        now),
      card("Available backups", table(["File", "Size", "Created", "Actions"], r.backups.map((b) => [b.name, size(b.size), date(new Date(b.modified * 1000).toISOString()),
        h("span", {}, h("a", { class: "link-btn", href: "/api/owner/backups/" + encodeURIComponent(b.name) }, T("Download")), btn("Delete", async () => {
          if (!confirm("Delete this backup?")) return;
          try { await api("/api/owner/backups/" + encodeURIComponent(b.name), { method: "DELETE" }); toast("Deleted"); shell(); } catch (e) { toast(e.message, true); }
        }, "link-btn danger"))]), "No backups yet.")));
  }

  /* ---------- start ---------- */
  async function start() {
    try { await loadMe(); } catch (e) { return toast(e.message, true); }
    try { await api("/api/owner/stats"); } catch (e) { return loginView(e.status === 401 ? "" : e.message); }
    logoutBtn.hidden = false;
    shell();
  }
  start();
})();
