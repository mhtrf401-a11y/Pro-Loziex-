(() => {
  const { h, api, loadMe, toast, openModal } = GM;
  const data = JSON.parse(document.getElementById("gm-data").textContent);
  let me = null;
  const ready = (async () => { try { me = (await loadMe()).user; } catch {} })();
  const actions = document.getElementById("gameActions");

  function openAuth() {
    const err = h("div", { class: "err", role: "alert" });
    const email = h("input", { type: "email", placeholder: "you@example.com", autocomplete: "email" });
    const pw = h("input", { type: "password", placeholder: "At least 8 characters", autocomplete: "current-password" });
    const submit = h("button", { class: "btn", type: "submit" }, "Sign in");
    const form = h("form", { class: "stack", novalidate: true, onsubmit: async (e) => {
      e.preventDefault(); submit.disabled = true; err.textContent = "";
      try {
        const r = await api("/api/login", { method: "POST", body: { email: email.value, password: pw.value } });
        me = r.user; close(); toast("Welcome back, " + me.name + "!"); render();
      } catch (x) { err.textContent = x.message; } finally { submit.disabled = false; }
    } }, h("h3", {}, "Sign in to GameMarket"),
      h("div", { class: "field" }, h("label", {}, "Email"), email),
      h("div", { class: "field" }, h("label", {}, "Password"), pw), err, submit,
      h("p", { style: "font-size:11px;color:#a99bb9" }, "New here? ",
        h("a", { href: "/#/", style: "color:#c57cff" }, "Create a free account from the store page.")));
    const close = openModal(form);
    email.focus();
  }

  async function claim() {
    if (!me) return openAuth();
    try { await api(`/api/games/${data.id}/get`, { method: "POST" }); data.owned = true; toast("Added to your library"); render(); return true; }
    catch (e) { toast(e.message, true); }
  }

  function render() {
    actions.replaceChildren();
    const canPlay = data.play_mode === "free" || data.play_mode === "trial";
    if (canPlay) actions.append(h("button", { class: "btn", onclick: startPlay }, data.play_mode === "trial" ? "▶ Try for 10 min" : "▶ Play now"));
    if (data.owned) {
      if (data.has_build) actions.append(h("a", { class: "btn" + (canPlay ? " ghost" : ""), href: "/download/" + data.id, style: "text-decoration:none" }, data.kind === "app" ? "Download APK" : "Download"));
      else actions.append(h("span", { class: "rating" }, "In your library"));
    } else {
      actions.append(h("button", { class: "btn" + (canPlay ? " ghost" : ""), onclick: claim }, data.has_build ? (data.kind === "app" ? "Get app (free)" : "Get for free") : "Add to library"));
    }
    if (data.demo_url) actions.append(h("a", { class: "btn ghost", href: data.demo_url, target: "_blank", rel: "noopener noreferrer nofollow", style: "text-decoration:none" }, "Play demo"));
    actions.append(h("button", { class: "btn ghost", onclick: async () => {
      if (!me) return openAuth();
      try {
        const r = await api(`/api/games/${data.id}/favorite`, { method: "POST" });
        data.favorite = r.favorite; toast(r.favorite ? "Added to favorites" : "Removed from favorites"); render();
      } catch (e) { toast(e.message, true); }
    } }, data.favorite ? "♥ Favorited" : "♡ Favorite"));
  }

  /* ---------- in-browser player (free play + 10-minute trial) ---------- */
  let stopPlayer = null;
  const fmt = (n) => Math.floor(n / 60) + ":" + String(n % 60).padStart(2, "0");

  async function startPlay() {
    await ready;
    let s;
    try { s = await api(`/api/games/${data.id}/play`, { method: "POST" }); }
    catch (e) { return toast(e.message, true); }
    stopPlayer?.();
    const box = document.getElementById("playerBox");
    box.hidden = false; box.replaceChildren();

    const frame = h("div", { class: "player-frame" });
    const timer = h("span", { class: "player-timer", hidden: true });
    let tick = null;
    const wrap = h("div", { class: "player" });
    const close = () => {
      clearInterval(tick);
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
      box.hidden = true; box.replaceChildren(); stopPlayer = null;
    };
    stopPlayer = close;
    const fsBtn = h("button", { type: "button", onclick: () => {
      if (wrap.requestFullscreen) {
        if (document.fullscreenElement) document.exitFullscreen();
        else wrap.requestFullscreen().catch(() => wrap.classList.toggle("max"));
      } else wrap.classList.toggle("max");
    } }, "⛶ Fullscreen");
    wrap.append(h("div", { class: "player-bar" }, h("span", { class: "grow" }, data.title), timer, fsBtn,
      h("button", { type: "button", onclick: close }, "✕ Close")), frame);
    box.append(wrap);

    const endPanel = (msg) => {
      clearInterval(tick); timer.hidden = true;
      if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
      const paint = () => {
        const dl = data.owned && data.has_build
          ? h("a", { class: "btn", href: "/download/" + data.id, style: "text-decoration:none" }, "Download the full game")
          : h("button", { class: "btn", onclick: async () => { if (await claim()) paint(); } },
              me ? "Get the full game (free)" : "Sign in to get the full game");
        frame.replaceChildren(h("div", { class: "player-end" }, h("h3", {}, "Your 10-minute trial has ended"),
          h("p", {}, msg), dl, h("button", { class: "btn ghost", onclick: close }, "Close")));
      };
      paint();
    };

    if (s.expired) return endPanel("You've already used the free trial of this game. Download it to keep playing — it's free.");

    frame.append(h("iframe", { src: s.url, sandbox: s.sandbox, allow: "fullscreen; autoplay; gamepad", allowfullscreen: true,
      referrerpolicy: "no-referrer", title: data.title }));
    if (s.seconds_left != null) {
      const t0 = performance.now(), total = s.seconds_left;
      const update = () => {
        const rem = Math.max(0, Math.ceil(total - (performance.now() - t0) / 1000));
        timer.hidden = false; timer.textContent = "⏱ " + fmt(rem) + " left";
        timer.classList.toggle("low", rem <= 60);
        if (rem <= 0) endPanel("Liked it? Download the full game and keep playing, for free.");
      };
      update(); tick = setInterval(update, 500);
    }
    wrap.scrollIntoView({ block: "start", behavior: "smooth" });
  }

  document.getElementById("btnAcc").addEventListener("click", () => (me ? toast(me.name + " · " + me.role) : openAuth()));

  render();
  ready.then(() => {
    render();
    if (location.hash === "#play" && (data.play_mode === "free" || data.play_mode === "trial")) startPlay();
  });
})();
