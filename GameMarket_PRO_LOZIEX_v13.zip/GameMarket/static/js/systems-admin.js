/* Admin panel for weekly events, claim reviews and temporary discounts. Every action is enforced by the server. */
(() => {
  const { h, api, loadMe, toast } = GM;
  const T = (s) => (window.GMI18N ? GMI18N.t(s) : s);
  const app = document.getElementById("app");
  const fmt = (iso) => (iso ? new Date(iso).toLocaleString() : "");
  const toIso = (v) => (v ? new Date(v).toISOString() : "");
  const btn = (label, fn, cls) => h("button", { class: cls || "btn", onclick: fn }, label);
  let tab = "events";

  async function boot() {
    let me = null;
    try { me = (await loadMe()).user; } catch (e) { me = null; }
    if (!me || me.role !== "admin") {
      app.replaceChildren(h("div", { class: "box" }, h("p", {}, T("Admin sign-in required.")),
        h("a", { class: "btn", href: "/admin" }, T("Go to admin sign-in"))));
      return;
    }
    render();
  }

  function render() {
    const tabs = h("div", { class: "row", style: "margin:14px 0" },
      ...[["events", "Events"], ["claims", "Claim reviews"], ["discounts", "Discounts"], ["support", "Support queue"]].map(([k, l]) =>
        h("button", { class: "chip" + (tab === k ? " on" : ""), onclick: () => { tab = k; render(); } }, T(l))));
    const body = h("div", {});
    app.replaceChildren(tabs, body);
    if (tab === "events") drawEvents(body);
    else if (tab === "claims") drawClaims(body);
    else if (tab === "support") drawSupport(body);
    else drawDiscounts(body);
  }

  function stageForm(eid) {
    const title = h("input", { placeholder: T("Stage title"), maxlength: 120 });
    const reward = h("input", { type: "number", min: 0, max: 10000, value: 5, style: "width:90px" });
    const rep = h("input", { type: "checkbox" });
    return h("div", { class: "row", style: "margin-top:8px" }, title, reward,
      h("label", {}, rep, " " + T("Repeatable")),
      btn(T("Add stage"), async () => {
        try {
          await api(`/api/admin/events/${eid}/stages`, { method: "POST",
            body: { title: title.value, reward_points: +reward.value, repeatable: rep.checked } });
          toast(T("Stage added")); render();
        } catch (e) { toast(e.message, true); }
      }, "btn ghost"));
  }

  async function drawEvents(box) {
    box.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
    let games = [], events = [];
    try {
      games = ((await api("/api/admin/games?status=approved")).games) || [];
      events = (await api("/api/admin/events")).events;
    } catch (e) { box.replaceChildren(h("div", { class: "err" }, e.message)); return; }

    const gSel = h("select", {}, ...games.map((g) => h("option", { value: g.id }, g.title)));
    const title = h("input", { placeholder: T("Event title"), maxlength: 120 });
    const desc = h("textarea", { class: "small", placeholder: T("Description"), style: "width:100%" });
    const minR = h("select", {}, ...[["none", "Open to everyone"], ["silver", "Silver and above"], ["gold", "Gold only"]]
      .map(([v, l]) => h("option", { value: v }, T(l))));
    const start = h("input", { type: "datetime-local" });
    const end = h("input", { type: "datetime-local" });
    const err = h("div", { class: "err" });
    const form = h("div", { class: "box" }, h("h3", {}, T("Create weekly event")),
      h("div", { class: "row" }, gSel, title, h("label", {}, T("Minimum rank") + " ", minR)), desc,
      h("div", { class: "row", style: "margin-top:8px" }, T("Starts") + " ", start, T("Ends") + " ", end),
      err,
      btn(T("Create event"), async () => {
        err.textContent = "";
        try {
          await api("/api/admin/events", { method: "POST", body: { game_id: +gSel.value, title: title.value,
            description: desc.value, starts_at: toIso(start.value), ends_at: toIso(end.value), min_rank: minR.value } });
          toast(T("Event created")); render();
        } catch (e) { err.textContent = e.message; }
      }));

    const list = h("div", { class: "admin-list" });
    if (!events.length) list.append(h("div", { class: "empty" }, T("No events yet.")));
    events.forEach((ev) => {
      const stages = ev.stages || [];
      list.append(h("div", { class: "box" },
        h("div", { class: "row" }, h("b", {}, ev.title), h("span", { class: "tag" }, ev.game_title),
          h("span", { class: "tag state-" + ev.state }, T(ev.state))),
        h("small", { class: "muted" }, fmt(ev.starts_at) + " → " + fmt(ev.ends_at)),
        h("div", { class: "row", style: "margin-top:6px" },
          ...stages.map((s) => h("span", { class: "tag" }, `#${s.stage_no} ${s.title} · ${s.reward_points} pts${s.repeatable ? " · ×" : ""}`))),
        h("div", { class: "row", style: "margin-top:8px" },
          btn(ev.active ? T("Stop event") : T("Activate"), async () => {
            try { await api(`/api/admin/events/${ev.id}`, { method: "PUT", body: { active: !ev.active } }); render(); }
            catch (e) { toast(e.message, true); }
          }, "btn ghost")),
        stageForm(ev.id)));
    });
    box.replaceChildren(form, list);
  }

  async function drawClaims(box) {
    const filt = h("select", {}, ...["pending", "approved", "rejected", "all"].map((s) => h("option", { value: s }, s)));
    const list = h("div", { class: "admin-list" });
    const review = async (id, action) => {
      try {
        const r = await api(`/api/admin/claims/${id}/review`, { method: "POST", body: { action } });
        toast(action === "approve" ? `${T("Approved")} (+${r.points})` : T("Rejected"));
        load();
      } catch (e) { toast(e.message, true); }
    };
    const load = async () => {
      list.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
      try {
        const { claims } = await api("/api/admin/claims?status=" + filt.value);
        list.replaceChildren();
        if (!claims.length) list.append(h("div", { class: "empty" }, T("Nothing here yet.")));
        claims.forEach((c) => list.append(h("div", { class: "box" },
          h("div", { class: "row" }, h("b", {}, c.user_name), h("span", { class: "tag" }, c.event_title + " · " + c.stage_title),
            h("span", { class: "tag" }, c.reward_points + " pts"), h("span", { class: "tag state-" + c.event_state }, T(c.event_state)),
            h("span", { class: "tag" }, c.status)),
          h("p", { class: "muted", style: "white-space:pre-line" }, c.evidence),
          c.status === "pending"
            ? h("div", { class: "row" }, btn(T("Approve"), () => review(c.id, "approve")), btn(T("Reject"), () => review(c.id, "reject"), "btn ghost"))
            : null)));
      } catch (e) { list.replaceChildren(h("div", { class: "err" }, e.message)); }
    };
    filt.addEventListener("change", load);
    box.replaceChildren(h("div", { class: "row" }, T("Show") + ": ", filt), list);
    load();
  }

  async function drawDiscounts(box) {
    box.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
    let items = [], discounts = [];
    try {
      items = (await api("/api/admin/shop-items")).items;
      discounts = (await api("/api/admin/discounts")).discounts;
    } catch (e) { box.replaceChildren(h("div", { class: "err" }, e.message)); return; }

    const iSel = h("select", {}, ...items.map((i) => h("option", { value: i.id }, `${i.name_en} (${i.store}) — ${i.price} pts`)));
    const pct = h("input", { type: "number", min: 1, max: 90, value: 20, style: "width:90px" });
    const st = h("input", { type: "datetime-local" });
    const en = h("input", { type: "datetime-local" });
    const err = h("div", { class: "err" });
    const form = h("div", { class: "box" }, h("h3", {}, T("New temporary discount")),
      h("div", { class: "row" }, iSel, pct, "%"),
      h("div", { class: "row", style: "margin-top:8px" }, T("Starts") + " ", st, T("Ends") + " ", en),
      err,
      btn(T("Create discount"), async () => {
        err.textContent = "";
        try {
          await api("/api/admin/discounts", { method: "POST", body: { item_id: +iSel.value, pct: +pct.value,
            starts_at: toIso(st.value), ends_at: toIso(en.value) } });
          toast(T("Discount created")); render();
        } catch (e) { err.textContent = e.message; }
      }));

    const list = h("div", { class: "admin-list" });
    if (!discounts.length) list.append(h("div", { class: "empty" }, T("No discounts yet.")));
    discounts.forEach((d) => list.append(h("div", { class: "box row" },
      h("div", { style: "flex:1" }, h("b", {}, d.name_en), h("div", { class: "muted" },
        `-${d.pct}% · ${fmt(d.starts_at)} → ${fmt(d.ends_at)}`)),
      h("span", { class: "tag state-" + (d.active ? d.state : "ended") }, d.active ? T(d.state) : T("stopped")),
      d.active ? btn(T("Stop"), async () => {
        try { await api(`/api/admin/discounts/${d.id}`, { method: "PUT", body: { active: false } }); render(); }
        catch (e) { toast(e.message, true); }
      }, "btn ghost") : null)));
    box.replaceChildren(form, list);
  }

  /* support queue: same priority order as the API (rank, then waiting time with aging) */
  async function drawSupport(box) {
    box.replaceChildren(h("div", { class: "empty" }, T("Loading…")));
    const list = h("div", { class: "admin-list" });
    try {
      const { tickets } = await api("/api/admin/support/tickets");
      box.replaceChildren(h("p", { class: "muted" }, T("Ordered by priority: rank first, and waiting time raises any request so nothing is ignored.")), list);
      if (!tickets.length) list.append(h("div", { class: "empty" }, T("Nothing here yet.")));
      tickets.forEach((t) => {
        const p = t.priority || { label: "normal", waited_hours: 0 };
        const msg = h("input", { placeholder: T("Reply") + "…", style: "width:100%" });
        list.append(h("div", { class: "box" },
          h("div", { class: "row" }, h("b", {}, t.subject), h("span", { class: "rank-badge rank-" + (t.rank || "none") }, t.rank || "none"),
            h("span", { class: "tag" }, t.user_name || "-"), h("span", { class: "tag" }, T(p.label)),
            h("span", { class: "tag" }, `${p.waited_hours} ${T("hours")}`), h("span", { class: "tag" }, t.status)),
          h("p", { class: "muted", style: "white-space:pre-line" }, t.message),
          h("div", { class: "row" }, msg, btn(T("Reply"), async () => {
            try {
              await api(`/api/support/tickets/${t.id}/reply`, { method: "POST", body: { message: msg.value } });
              toast(T("Sent.")); drawSupport(box);
            } catch (e) { toast(e.message, true); }
          }))));
      });
    } catch (e) { box.replaceChildren(h("div", { class: "err" }, e.message)); }
  }

  boot();
})();
