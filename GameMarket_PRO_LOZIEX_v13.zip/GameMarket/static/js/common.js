/* Shared helpers: API calls, DOM builder, toast, modal. No innerHTML anywhere (XSS-safe). */
window.GM = (() => {
  let csrf = "";
  const h = (tag, attrs = {}, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === "class") e.className = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else if (v !== false && v != null) e.setAttribute(k, v === true ? "" : v);
    }
    for (const c of kids.flat()) {
      if (c == null || c === false) continue;
      e.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return e;
  };
  const money = (c) => (c ? "$" + (c / 100).toFixed(2) : "Free");
  const size = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(b / 1024)) + " KB");
  const date = (s) => (s ? new Date(s).toLocaleDateString() : "");

  async function api(path, { method = "GET", body, form } = {}) {
    const opts = { method, credentials: "same-origin", headers: {} };
    if (method !== "GET") opts.headers["X-CSRF-Token"] = csrf;
    if (body) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
    if (form) opts.body = form;
    let r, data = {};
    try { r = await fetch(path, opts); } catch { throw new Error("Network error. Check your connection."); }
    try { data = await r.json(); } catch {}
    if (data.csrf) csrf = data.csrf;
    if (!r.ok) throw Object.assign(new Error(data.error || "Something went wrong"), { status: r.status });
    return data;
  }

  function upload(path, form, onProgress, method = "POST") {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open(method, path);
      x.setRequestHeader("X-CSRF-Token", csrf);
      x.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
      x.onerror = () => reject(new Error("Upload failed. Check your connection."));
      x.onload = () => {
        let d = {};
        try { d = JSON.parse(x.responseText); } catch {}
        x.status >= 200 && x.status < 300 ? resolve(d) : reject(new Error(d.error || "Upload failed"));
      };
      x.send(form);
    });
  }

  async function loadMe() {
    const d = await api("/api/me");
    csrf = d.csrf;
    return d;
  }

  let toastEl;
  function toast(msg, bad) {
    toastEl?.remove();
    toastEl = h("div", { class: "toast" + (bad ? " bad" : ""), role: "status" }, msg);
    document.body.append(toastEl);
    setTimeout(() => toastEl && toastEl.remove(), 3800);
  }

  function openModal(content, { wide = false } = {}) {
    const close = () => { ov.remove(); document.removeEventListener("keydown", esc); };
    const esc = (e) => e.key === "Escape" && close();
    const ov = h("div", { class: "overlay", onclick: (e) => e.target === ov && close() },
      h("div", { class: "modal" + (wide ? " wide" : ""), role: "dialog", "aria-modal": "true" },
        h("button", { class: "x", "aria-label": "Close", onclick: close }, "×"), content));
    document.addEventListener("keydown", esc);
    document.body.append(ov);
    return close;
  }

  function ask({ title, label, ok = "Confirm" }) {
    return new Promise((resolve) => {
      let done = false;
      const input = h("textarea", { rows: 3, maxlength: 500, style: "width:100%;padding:10px;background:#0e0a16;border:1px solid #40304e;border-radius:7px;color:#fff" });
      const finish = (v) => { if (!done) { done = true; close(); resolve(v); } };
      const close = openModal(h("div", { class: "stack" }, h("h3", {}, title), h("label", {}, label), input,
        h("div", { class: "request", style: "background:none;border:0;padding:0" },
          h("button", { class: "btn ghost", onclick: () => finish(null) }, "Cancel"),
          h("button", { class: "btn", onclick: () => finish(input.value.trim()) }, ok))));
      input.focus();
    });
  }

  async function previewPlay(g) {
    try {
      const s = await api(`/api/games/${g.id}/play`, { method: "POST" });
      if (s.expired) return toast("Trial already used by this visitor", true);
      openModal(h("div", {}, h("h3", {}, "Preview: " + g.title),
        h("iframe", { src: s.url, sandbox: s.sandbox, allow: "fullscreen; autoplay; gamepad", allowfullscreen: true,
          referrerpolicy: "no-referrer", title: g.title, style: "width:100%;height:62vh;border:0;background:#000;border-radius:8px" })), { wide: true });
    } catch (e) { toast(e.message, true); }
  }

  return { h, api, upload, loadMe, toast, openModal, ask, money, size, date, previewPlay };
})();
