(() => {
  const { h, api, upload, loadMe, toast, openModal, size } = GM;
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));
  let me = null;
  let GENRES = [], PLATFORMS = [], MAX_SHOTS = 5, APP_CATS = [];
  const filters = { q: "", sort: "popular", platform: new Set(), genre: new Set(), page: 1, kind: "game" };
  let menuEl = null;
  let lastGames = [];

  /* ---------- cards ---------- */
  function cardNode(g, mode = "store") {
    const fav = h("button", { class: "fav", title: "Favorite", "aria-label": "Favorite",
      onclick: async (e) => { e.stopPropagation(); await toggleFav(g, fav); } }, g.favorite ? "♥" : "♡");
    const href = `/game/${g.id}/${g.slug}`;
    const act = mode === "play"
      ? h("a", { class: "buy", href: href + "#play", style: "text-decoration:none", onclick: (e) => e.stopPropagation() }, "▶ Play")
      : mode === "library"
      ? h("a", { class: "buy", href: "/download/" + g.id, style: "text-decoration:none", onclick: (e) => e.stopPropagation() }, "Download")
      : h("a", { class: "buy", href: g.url || href, style: "text-decoration:none", onclick: (e) => { e.preventDefault(); e.stopPropagation(); openDetail(g.id); } }, g.kind === "app" ? "Get" : "View");
    return h("article", { class: "card", style: "cursor:pointer", onclick: () => (mode === "play" ? (location.href = href + "#play") : openDetail(g.id)) },
      h("div", { class: "cover" }, h("img", { src: g.cover, alt: g.title, loading: "lazy", decoding: "async", width: 320, height: 180 }),
        h("span", { class: "free-tag" }, "FREE"),
        g.play_mode === "free" ? h("span", { class: "play-tag" }, "▶ PLAY") : g.play_mode === "trial" ? h("span", { class: "play-tag" }, "▶ TRY 10 MIN") : null, fav),
      h("div", { class: "info" }, h("div", { class: "name" }, g.title),
        h("div", { class: "meta" }, h("span", { class: "tag" }, g.kind === "app" ? "App" : g.platform), h("span", { class: "tag" }, g.genre),
          h("span", { class: "rating" }, g.avg_rating ? "★ " + g.avg_rating : "★ New")),
        h("div", { class: "bottom" }, h("span", { class: "price" }, g.version ? "v" + g.version : "Free"), act)));
  }

  async function toggleFav(g, btn) {
    if (!me) return openAuth("login");
    try {
      const r = await api(`/api/games/${g.id}/favorite`, { method: "POST" });
      g.favorite = r.favorite;
      btn.textContent = r.favorite ? "♥" : "♡";
      if (location.hash === "#/favorites") renderFavorites();
    } catch (e) { toast(e.message, true); }
  }

  function fill(box, games, empty, mode) {
    box.replaceChildren();
    if (!games.length) box.append(h("div", { class: "empty" }, empty));
    else games.forEach((g) => box.append(cardNode(g, mode)));
  }

  /* ---------- categories (homepage quick nav) ---------- */
  function renderCatNav() {
    const box = $("#catNav");
    box.replaceChildren(h("span", {}, "Browse:"));
    (filters.kind === "app" ? APP_CATS : GENRES).forEach((g) => box.append(h("span", { style: "cursor:pointer", onclick: () => {
      filters.genre.clear(); filters.genre.add(g); filters.page = 1;
      document.querySelectorAll("#genreChips .chip").forEach((c) => c.classList.toggle("on", c.dataset.v === g));
      loadGames();
    } }, g)));
  }

  /* ---------- store ---------- */
  let loadSeq = 0;
  async function loadGames(append = false) {
    const seq = ++loadSeq;
    const p = new URLSearchParams({ sort: filters.sort, page: String(filters.page), kind: filters.kind });
    if (filters.q) p.set("q", filters.q);
    if (filters.platform.size) p.set("platform", [...filters.platform].join(","));
    if (filters.genre.size) p.set("genre", [...filters.genre].join(","));
    try {
      const { games, has_more } = await api("/api/games?" + p);
      if (seq !== loadSeq) return;
      lastGames = append ? lastGames.concat(games) : games;
      $("#resultCount").textContent = lastGames.length + (lastGames.length === 1 ? " game found" : " games found");
      fill($("#cards"), lastGames, "No games match your search yet.", "store");
      $("#loadMore").hidden = !has_more;
    } catch (e) { $("#resultCount").textContent = e.message; }
  }

  $("#loadMore").addEventListener("click", () => { filters.page++; loadGames(true); });

  function setSort(v) {
    filters.sort = v; filters.page = 1;
    document.querySelectorAll('input[name=sort]').forEach((r) => (r.checked = r.value === v));
    const sel = $("#sortSelect");
    sel.value = [...sel.options].some((o) => o.value === v) ? v : sel.value;
    loadGames();
  }
  document.querySelectorAll("input[name=sort]").forEach((r) => r.addEventListener("change", () => setSort(r.value)));
  $("#sortSelect").addEventListener("change", (e) => setSort(e.target.value));
  for (const [id, key] of [["#platChips", "platform"], ["#genreChips", "genre"]]) {
    $(id).addEventListener("click", (e) => {
      const b = e.target.closest(".chip");
      if (!b) return;
      const v = b.dataset.v;
      filters[key].has(v) ? filters[key].delete(v) : filters[key].add(v);
      b.classList.toggle("on", filters[key].has(v));
      filters.page = 1;
      loadGames();
    });
  }
  let t;
  const onSearch = (src, other) => src.addEventListener("input", () => {
    other.value = src.value; filters.q = src.value.trim(); filters.page = 1;
    clearTimeout(t); t = setTimeout(() => { if (!location.hash.startsWith("#/") || location.hash === "#/") loadGames(); else location.hash = "#/"; }, 250);
  });
  const topSearch = $("#topSearch");
  const heroSearch = $("#heroSearch");
  if (topSearch && heroSearch) {
    onSearch(topSearch, heroSearch);
    onSearch(heroSearch, topSearch);
  } else if (topSearch) {
    topSearch.addEventListener("input", () => {
      filters.q = topSearch.value.trim(); filters.page = 1;
      clearTimeout(t); t = setTimeout(() => { if (!location.hash.startsWith("#/") || location.hash === "#/") loadGames(); else location.hash = "#/"; }, 250);
    });
  }

  /* ---------- game detail ---------- */
  async function openDetail(id) {
    let g;
    try { g = (await api("/api/games/" + id)).game; } catch (e) { return toast(e.message, true); }
    const box = h("div", { class: "detail" });
    let close;
    const render = () => {
      const starBtns = [1, 2, 3, 4, 5].map((n) => h("button", { class: n <= (g.my_rating || 0) ? "on" : "", "aria-label": n + " stars",
        onclick: async () => {
          try { await api(`/api/games/${g.id}/rate`, { method: "POST", body: { stars: n } }); g.my_rating = n; toast("Thanks for rating!"); render(); loadGames(); }
          catch (e) { toast(e.message, true); }
        } }, "★"));
      const acts = [];
      if (g.owned) {
        if (g.has_build) acts.push(h("a", { class: "btn", href: "/download/" + g.id, style: "text-decoration:none" }, "Download"));
        else acts.push(h("span", { class: "rating" }, "In your library"));
      } else {
        acts.push(h("button", { class: "btn", onclick: async () => {
          if (!me) { close(); return openAuth("login"); }
          try { await api(`/api/games/${g.id}/get`, { method: "POST" }); g.owned = true; toast("Added to your library"); render(); }
          catch (e) { toast(e.message, true); }
        } }, "Get for free"));
      }
      if (g.play_mode === "free" || g.play_mode === "trial") {
        acts.unshift(h("a", { class: "btn", href: `/game/${g.id}/${g.slug}#play`, style: "text-decoration:none" },
          g.play_mode === "trial" ? "▶ Try for 10 min" : "▶ Play now"));
      }
      if (g.demo_url) acts.push(h("a", { class: "btn ghost", href: g.demo_url, target: "_blank", rel: "noopener noreferrer nofollow", style: "text-decoration:none" }, "Play demo"));
      const shots = (g.screenshots || []).length
        ? h("div", { class: "shots" }, ...g.screenshots.map((s) => h("img", { src: s.url, alt: g.title + " screenshot", loading: "lazy" }))) : null;
      box.replaceChildren(
        h("div", {}, h("img", { src: g.cover, alt: g.title }), shots),
        h("div", {}, h("h3", {}, g.title),
          h("div", { class: "row" }, h("span", { class: "tag" }, g.platform), h("span", { class: "tag" }, g.genre),
            h("span", { class: "free-badge" }, "100% Free"),
            h("span", { class: "rating" }, g.avg_rating ? `★ ${g.avg_rating} (${g.rating_count})` : "No ratings yet"),
            h("span", { class: "rating" }, "by " + g.dev_name)),
          h("div", { class: "desc" }, g.description),
          g.requirements ? h("div", {}, h("b", { style: "font-size:11px;color:#e7d9f2" }, "System requirements"),
            h("div", { class: "desc", style: "margin-top:4px" }, g.requirements)) : null,
          h("div", { class: "row" }, ...acts),
          g.owned && me ? h("div", { class: "row" }, h("span", { class: "rating" }, "Your rating:"), h("span", { class: "stars" }, starBtns)) : null,
          h("div", { class: "row" }, h("a", { href: "/game/" + g.id + "/" + g.slug, style: "font-size:10px;color:#8c7b98" }, "Permanent link to this game ↗"))));
    };
    render();
    close = openModal(box, { wide: true });
  }

  /* ---------- auth ---------- */
  function openAuth(mode = "login") {
    let m = mode, close;
    const err = h("div", { class: "err", role: "alert" });
    const name = h("input", { name: "name", placeholder: "Your name or studio", maxlength: 40, autocomplete: "name" });
    const email = h("input", { name: "email", type: "email", placeholder: "you@example.com", autocomplete: "email" });
    const pw = h("input", { name: "password", type: "password", placeholder: "At least 8 characters", autocomplete: "current-password" });
    const role = h("select", {}, h("option", { value: "player" }, "Player — browse & download games"), h("option", { value: "developer" }, "Developer — publish my games"));
    const nameF = h("div", { class: "field" }, h("label", {}, "Name"), name);
    const roleF = h("div", { class: "field" }, h("label", {}, "I am a"), role);
    const submit = h("button", { class: "btn", type: "submit" }, "Sign in");
    const tabs = h("div", { class: "tabs" });
    const sync = () => {
      nameF.hidden = roleF.hidden = m === "login";
      submit.textContent = m === "login" ? "Sign in" : "Create account";
      pw.autocomplete = m === "login" ? "current-password" : "new-password";
      tabs.replaceChildren(
        h("button", { class: "tab" + (m === "login" ? " on" : ""), type: "button", onclick: () => { m = "login"; sync(); } }, "Sign in"),
        h("button", { class: "tab" + (m === "register" ? " on" : ""), type: "button", onclick: () => { m = "register"; sync(); } }, "Create account"));
      err.textContent = "";
    };
    const form = h("form", { class: "stack", novalidate: true, onsubmit: async (e) => {
      e.preventDefault(); submit.disabled = true; err.textContent = "";
      try {
        const body = m === "login" ? { email: email.value, password: pw.value }
          : { name: name.value, email: email.value, password: pw.value, role: role.value };
        const r = await api(m === "login" ? "/api/login" : "/api/register", { method: "POST", body });
        me = r.user; close(); updateHeader(); toast("Welcome, " + me.name + "!"); route();
      } catch (x) { err.textContent = x.message; } finally { submit.disabled = false; }
    } }, h("h3", {}, "Welcome to GameMarket"), tabs, nameF,
      h("div", { class: "field" }, h("label", {}, "Email"), email), h("div", { class: "field" }, h("label", {}, "Password"), pw), roleF, err, submit);
    sync();
    close = openModal(form);
    (m === "login" ? email : name).focus();
  }

  function closeMenu() { menuEl?.remove(); menuEl = null; }
  function openMenu() {
    if (menuEl) return closeMenu();
    const item = (label, fn) => h("button", { onclick: () => { closeMenu(); fn(); } }, label);
    menuEl = h("div", { class: "menu" },
      h("div", { class: "who" }, h("b", {}, me.name), me.email + " · " + me.role),
      item("My library", () => (location.hash = "#/library")),
      item("Favorites", () => (location.hash = "#/favorites")),
      me.role !== "player" ? item("Developer dashboard", () => (location.hash = "#/developer")) : null,
      item("Sign out", async () => {
        try { await api("/api/logout", { method: "POST" }); } catch {}
        me = null; updateHeader(); location.hash = "#/"; route(); toast("Signed out");
      }));
    document.body.append(menuEl);
  }
  document.addEventListener("click", (e) => { if (menuEl && !e.target.closest(".menu") && !e.target.closest("#btnAcc")) closeMenu(); });

  function updateHeader() {
    const b = $("#btnAcc");
    b.querySelector(".dot")?.remove();
    if (me) b.append(h("i", { class: "dot" }));
    b.title = me ? me.name : "Sign in";
    const nameEl = $("#lxAccName"), rankEl = $("#lxAccRank");
    if (nameEl) nameEl.textContent = me ? me.name : "Guest";
    if (rankEl) rankEl.textContent = me && me.rank ? me.rank : "—";
  }
  $("#btnAcc").addEventListener("click", () => (me ? openMenu() : openAuth("login")));
  $("#btnLib").addEventListener("click", () => (me ? (location.hash = "#/library") : openAuth("login")));
  $("#btnFav").addEventListener("click", () => (me ? (location.hash = "#/favorites") : openAuth("login")));

  /* ---------- ملفي للألعاب: player library/favorites + developer's published games ---------- */
  async function renderLibrary() {
    $("#mgDevTabBtn").hidden = !(me && (me.role === "developer" || me.role === "admin"));
    if (!me) { fill($("#libCards"), [], "Sign in to see your library.", "library"); fill($("#favCards"), [], "Sign in to see your favorites.", "store"); return; }
    try { fill($("#libCards"), (await api("/api/library")).games, "مكتبتك فارغة. أضف لعبة مجانية من المتجر!", "library"); } catch (e) { toast(e.message, true); }
    try { fill($("#favCards"), (await api("/api/favorites")).games, "لا توجد ألعاب مفضلة بعد. اضغط ♡ على أي لعبة.", "store"); } catch (e) { toast(e.message, true); }
  }
  async function renderPlay() {
    try {
      const { games } = await api("/api/games?play=free&sort=popular");
      fill($("#playCards"), games, "No browser games yet. Developers can publish one from the Developer page!", "play");
    } catch (e) { toast(e.message, true); }
  }
  async function renderFavorites() {
    if (!me) return;
    try { fill($("#favCards"), (await api("/api/favorites")).games, "No favorites yet. Tap ♡ on any game.", "store"); } catch (e) { toast(e.message, true); }
  }

  $("#mgTabs")?.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-mg]");
    if (!b) return;
    $$("#mgTabs button").forEach((x) => x.classList.toggle("on", x === b));
    $("#mgPlayerPanel").classList.toggle("on", b.dataset.mg === "player");
    $("#mgDevPanel").classList.toggle("on", b.dataset.mg === "dev");
    if (b.dataset.mg === "dev") renderMyGamesDev();
  });
  $("#mgSub")?.addEventListener("click", (e) => {
    const b = e.target.closest("button[data-sub]");
    if (!b) return;
    $$("#mgSub button").forEach((x) => x.classList.toggle("on", x === b));
    $("#libCards").hidden = b.dataset.sub !== "lib";
    $("#favCards").hidden = b.dataset.sub !== "fav";
  });

  async function renderMyGamesDev() {
    const statsBox = $("#mgDevStats"), listBox = $("#mgDevList");
    if (!me || (me.role !== "developer" && me.role !== "admin")) return;
    try {
      const { games } = await api("/api/my/games");
      const published = games.filter((g) => g.status === "approved");
      const totalViews = games.reduce((s, g) => s + (g.views || 0), 0);
      const totalDownloads = games.reduce((s, g) => s + (g.downloads || 0), 0);
      const rated = games.filter((g) => g.rating_count);
      const avgRating = rated.length ? (rated.reduce((s, g) => s + g.avg_rating, 0) / rated.length).toFixed(1) : "—";
      statsBox.replaceChildren(
        h("div", { class: "lx-dev-stat" }, h("b", {}, String(published.length)), h("span", {}, "ألعاب منشورة")),
        h("div", { class: "lx-dev-stat" }, h("b", {}, String(totalViews)), h("span", {}, "إجمالي المشاهدات")),
        h("div", { class: "lx-dev-stat" }, h("b", {}, String(totalDownloads)), h("span", {}, "إجمالي التنزيلات")),
        h("div", { class: "lx-dev-stat" }, h("b", {}, avgRating), h("span", {}, "متوسط التقييم")));
      listBox.replaceChildren();
      if (!games.length) { listBox.append(h("div", { class: "empty" }, "لم تنشر أي لعبة بعد.")); return; }
      games.forEach((g) => listBox.append(h("div", { class: "lx-dev-game-row", style: "cursor:pointer", onclick: () => openDetail(g.id) },
        h("img", { src: g.cover, alt: "" }),
        h("div", { class: "nm" }, h("b", {}, g.title), h("span", {}, { pending: "قيد المراجعة", approved: "منشورة", rejected: "مرفوضة" }[g.status])),
        h("div", { class: "mets" },
          h("span", {}, "👁 ", h("b", {}, String(g.views || 0))),
          h("span", {}, "⬇ ", h("b", {}, String(g.downloads || 0))),
          h("span", {}, "★ ", h("b", {}, g.rating_count ? g.avg_rating : "—"))))));
    } catch (e) { toast(e.message, true); }
  }

  /* ---------- developer ---------- */
  function renderDeveloper() {
    const gate = $("#devGate"), area = $("#devArea");
    area.hidden = true; gate.hidden = false; gate.replaceChildren();
    if (!me) {
      gate.append(h("p", { style: "margin:0 0 12px;color:#cbbddb" }, "Sign in with a developer account to submit games."),
        h("button", { class: "btn", onclick: () => openAuth("register") }, "Create developer account"), " ",
        h("button", { class: "btn ghost", onclick: () => openAuth("login") }, "Sign in"));
    } else if (me.role === "player") {
      gate.append(h("p", { style: "margin:0;color:#cbbddb" }, "Your account is a player account. Create a new developer account (use a different email) to publish games."),
        h("button", { class: "btn", style: "margin-top:12px", onclick: async () => {
          try { await api("/api/logout", { method: "POST" }); } catch {}
          me = null; updateHeader(); openAuth("register");
        } }, "Sign out & register as developer"));
    } else {
      gate.hidden = true; area.hidden = false; loadMine();
    }
  }

  function gameFormFields(prefill) {
    const title = h("input", { name: "title", required: true, maxlength: 80, value: prefill?.title || "" });
    const platform = h("select", {}, ...PLATFORMS.map((p) => h("option", { selected: p === prefill?.platform }, p)));
    const genre = h("select", {}, ...GENRES.map((gn) => h("option", { selected: gn === prefill?.genre }, gn)));
    const demo = h("input", { name: "demo_url", type: "url", placeholder: "https://...", value: prefill?.demo_url || "" });
    const cover = h("input", { name: "cover", type: "file", accept: "image/png,image/jpeg,image/webp", required: !prefill });
    const build = h("input", { name: "build", type: "file", accept: ".zip,.apk,.7z,.rar" });
    const playMode = h("select", { name: "play_mode" },
      ...[["none", "No browser version (download only)"], ["free", "Free play — unlimited, no download needed"], ["trial", "10-minute trial, then download"]]
        .map(([v, l]) => h("option", { value: v, selected: v === (prefill?.play_mode || "none") }, l)));
    const play = h("input", { name: "play", type: "file", accept: ".zip,.html,.htm" });
    const shots = h("input", { name: "screenshots", type: "file", accept: "image/png,image/jpeg,image/webp", multiple: true });
    const requirements = h("textarea", { name: "requirements", class: "small", maxlength: 600 }, prefill?.requirements || "");
    const desc = h("textarea", { name: "description", required: true, maxlength: 3000 }, prefill?.description || "");
    return { title, platform, genre, demo, cover, build, playMode, play, shots, requirements, desc };
  }

  function openNewVersion(g) {
    const ver = h("input", { name: "version", maxlength: 24, placeholder: g.version ? "e.g. " + bump(g.version) : "1.0.0", required: true });
    const notes = h("textarea", { name: "notes", class: "small", maxlength: 2000, placeholder: "What changed in this version?", required: true });
    const file = h("input", { type: "file", accept: g.kind === "app" ? ".apk" : ".zip,.apk,.7z,.rar" });
    const err = h("div", { class: "err" });
    const submit = h("button", { class: "btn", type: "submit" }, "Publish version");
    const form = h("form", { class: "stack", novalidate: true, onsubmit: async (e) => {
      e.preventDefault(); submit.disabled = true; err.textContent = "";
      const fd = new FormData();
      fd.set("version", ver.value.trim()); fd.set("notes", notes.value.trim());
      if (file.files[0]) fd.set("build", file.files[0]);
      try {
        const r = await upload(`/api/my/games/${g.id}/versions`, fd, null);
        close(); toast(r.requeued ? "Version saved — sent back for review." : "Version published."); loadMine();
      } catch (x) { err.textContent = x.message; } finally { submit.disabled = false; }
    } }, h("h3", {}, "New version of “" + g.title + "”"),
      h("p", { class: "muted" }, `Current: ${g.version ? "v" + g.version : "—"}. A new file is reviewed again before it is visible.`),
      h("div", { class: "field" }, h("label", {}, "Version number"), ver),
      h("div", { class: "field" }, h("label", {}, "Release notes"), notes),
      h("div", { class: "field" }, h("label", {}, g.kind === "app" ? "New APK (required)" : "New game file (optional)"), file),
      err, submit);
    const close = openModal(form, { wide: true });
  }
  function bump(v) { const m = /^(\d+)\.(\d+)/.exec(v || ""); return m ? `${m[1]}.${+m[2] + 1}` : "1.1"; }

  function openEditGame(g) {
    const f = gameFormFields(g);
    const err = h("div", { class: "err" });
    const removeIds = new Set();
    const shotsBox = h("div", { class: "shots", style: "margin:6px 0" },
      ...(g.screenshots || []).map((s) => {
        const wrap = h("div", { style: "position:relative" },
          h("img", { src: s.url, alt: "screenshot" }),
          h("button", { type: "button", class: "x-shot", onclick: () => { removeIds.add(s.id); wrap.remove(); } }, "×"));
        return wrap;
      }));
    const submit = h("button", { class: "btn", type: "submit" }, "Save changes");
    const form = h("form", { class: "formgrid", novalidate: true, onsubmit: async (e) => {
      e.preventDefault(); submit.disabled = true; err.textContent = "";
      const fd = new FormData();
      fd.set("title", f.title.value); fd.set("description", f.desc.value);
      fd.set("platform", f.platform.value); fd.set("genre", f.genre.value);
      fd.set("demo_url", f.demo.value); fd.set("requirements", f.requirements.value);
      if (f.cover.files[0]) fd.set("cover", f.cover.files[0]);
      if (f.build.files[0]) fd.set("build", f.build.files[0]);
      fd.set("play_mode", f.playMode.value);
      if (f.play.files[0]) fd.set("play", f.play.files[0]);
      for (const file of f.shots.files) fd.append("screenshots", file);
      if (removeIds.size) fd.set("remove_screenshots", [...removeIds].join(","));
      try {
        const r = await upload("/api/my/games/" + g.id, fd, null, "PUT");
        close(); toast(r.requeued ? "Saved — sent back for admin re-review." : "Saved."); loadMine();
      } catch (x) { err.textContent = x.message; } finally { submit.disabled = false; }
    } },
      h("h3", { class: "full" }, "Edit “" + g.title + "”"),
      h("div", { class: "field" }, h("label", {}, "Game title"), f.title),
      h("div", { class: "field" }, h("label", {}, "Platform"), f.platform),
      h("div", { class: "field" }, h("label", {}, "Genre"), f.genre),
      h("div", { class: "field" }, h("label", {}, "Demo / web build URL"), f.demo),
      h("div", { class: "field" }, h("label", {}, "Replace cover (optional)"), f.cover),
      h("div", { class: "field" }, h("label", {}, "Replace game file (optional)"), f.build),
      h("div", { class: "field" }, h("label", {}, "Play in browser (HTML5)"), f.playMode),
      h("div", { class: "field" }, h("label", {}, g.has_play ? "Replace HTML5 game (.zip / .html)" : "HTML5 game (.zip with index.html / .html)"), f.play),
      h("div", { class: "field full" }, h("label", {}, "Screenshots"), shotsBox,
        h("small", {}, "Add more (optional, 5 max total)"), f.shots),
      h("div", { class: "field full" }, h("label", {}, "System requirements"), f.requirements),
      h("div", { class: "field full" }, h("label", {}, "Description"), f.desc),
      h("div", { class: "field full" }, h("small", {}, "Editing a published game sends it back for admin re-review before it's visible again."), err, submit));
    const close = openModal(form, { wide: true });
  }

  async function loadMine() {
    const box = $("#myGames");
    try {
      const { games } = await api("/api/my/games");
      box.replaceChildren();
      if (!games.length) box.append(h("div", { class: "empty" }, "You haven't submitted any games yet."));
      games.forEach((g) => box.append(h("div", { class: "request" },
        h("div", { class: "grow" }, h("b", {}, g.title),
          h("small", {}, `${g.kind === "app" ? "App" : g.platform} · ${g.genre} · Free${g.version ? " · v" + g.version : ""}${g.build_size ? " · " + size(g.build_size) : ""}${g.has_play ? " · Browser: " + g.play_mode : ""}${g.scan_status && g.scan_status !== "clean" ? " · Scan: " + g.scan_status : ""}`),
          g.status === "rejected" && g.reject_reason ? h("div", { class: "why" }, "Reason: " + g.reject_reason) : null),
        h("span", { class: "badge st-" + g.status }, { pending: "Pending review", approved: "Published", rejected: "Rejected" }[g.status]),
        h("div", { class: "acts" },
          g.has_play ? h("button", { class: "link-btn", onclick: () => GM.previewPlay(g) }, "Preview") : null,
          h("button", { class: "link-btn", onclick: () => openEditGame(g) }, "Edit"),
          h("button", { class: "link-btn", onclick: () => openNewVersion(g) }, "New version"),
          h("button", { class: "reject", onclick: async () => {
            if (!confirm(`Delete "${g.title}" permanently?`)) return;
            try { await api("/api/my/games/" + g.id, { method: "DELETE" }); toast("Deleted"); loadMine(); } catch (e) { toast(e.message, true); }
          } }, "Delete")))));
    } catch (e) { box.replaceChildren(h("div", { class: "empty" }, e.message)); }
  }

  function syncKind() {
    const isApp = $("#f_kind").value === "app";
    document.querySelectorAll(".game-only").forEach((el) => (el.hidden = isApp));
    document.querySelectorAll(".app-only").forEach((el) => (el.hidden = !isApp));
    const gsel = $("#f_genre");
    gsel.replaceChildren(...(isApp ? APP_CATS : GENRES).map((x) => h("option", {}, x)));
    $("#f_build").accept = isApp ? ".apk" : ".zip,.apk,.7z,.rar";
    $("#f_build").required = isApp;
  }
  $("#f_kind")?.addEventListener("change", syncKind);

  $("#devForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target, err = $("#devErr"), btn = $("#devSubmit"), prog = $("#devProg");
    err.textContent = "";
    const fd = new FormData(f);
    if (!fd.get("cover")?.name) return (err.textContent = "Choose a cover image.");
    const isApp = fd.get("kind") === "app";
    const mode = fd.get("play_mode"), hasPlay = !!fd.get("play")?.name, hasBuild = !!fd.get("build")?.name;
    if (isApp && !hasBuild) return (err.textContent = "Upload the app's APK file.");
    if (isApp && !fd.get("version")) return (err.textContent = "Enter the app version (for example 1.0.0).");
    if (!isApp && mode !== "none" && !hasPlay) return (err.textContent = "Choose your HTML5 game file (.zip with index.html, or a single .html).");
    if (mode === "trial" && !hasBuild) return (err.textContent = "A 10-minute trial needs a downloadable game file too.");
    if (!isApp && !hasBuild && !hasPlay && !fd.get("demo_url")) return (err.textContent = "Upload a game file, an HTML5 version, or enter a demo URL.");
    if (fd.get("description").trim().length < 20) return (err.textContent = "Description must be at least 20 characters.");
    const shotCount = f.querySelector("[name=screenshots]").files.length;
    if (shotCount > MAX_SHOTS) return (err.textContent = `Up to ${MAX_SHOTS} screenshots.`);
    btn.disabled = true; prog.hidden = false;
    try {
      await upload("/api/games", fd, (p) => (prog.firstChild.style.width = Math.round(p * 100) + "%"));
      f.reset(); toast("Submitted! An admin will review your game."); loadMine();
    } catch (x) { err.textContent = x.message; }
    finally { btn.disabled = false; prog.hidden = true; prog.firstChild.style.width = "0"; }
  });

  /* ---------- routing ---------- */
  function route() {
    const r = location.hash || "#/";
    const pages = { "#/developer": "developerPage", "#/library": "libraryPage", "#/favorites": "favoritesPage", "#/play": "playPage" };
    const active = pages[r];
    const wantKind = r === "#/apps" ? "app" : "game";
    if (filters.kind !== wantKind) { filters.kind = wantKind; filters.genre.clear(); filters.platform.clear();
      document.querySelectorAll("#genreChips .chip.on,#platChips .chip.on").forEach((c) => c.classList.remove("on")); renderCatNav(); }
    $("#hero").hidden = $("#storePage").hidden = !!active;
    document.querySelectorAll("[data-nav]").forEach((a) => a.classList.toggle("cur", a.dataset.nav === (wantKind === "app" ? "apps" : "games")));
    $("#platChips").closest(".filter-block").hidden = wantKind === "app";
    $("#storeTitle").textContent = wantKind === "app" ? "All Apps" : "All Games";
    for (const id of Object.values(pages)) $("#" + id).classList.toggle("active", id === active);
    window.scrollTo(0, 0);
    if (r === "#/developer") renderDeveloper();
    else if (r === "#/library") renderLibrary();
    else if (r === "#/favorites") renderFavorites();
    else if (r === "#/play") renderPlay();
    else { filters.page = 1; loadGames(); }
  }
  window.addEventListener("hashchange", route);

  (async () => {
    try {
      const d = await loadMe();
      me = d.user; GENRES = d.genres; PLATFORMS = d.platforms; MAX_SHOTS = d.max_screenshots || 5; APP_CATS = d.app_categories || [];
      if (d.announcement) { const b = h("div", { class: "announce" }, d.announcement); document.querySelector(".hero")?.before(b); }
      if (d.maintenance) toast("Maintenance mode is on — some actions may be unavailable.", true);
    } catch (e) { toast(e.message, true); }
    renderCatNav();
    updateHeader(); route();
  })();

  /* ---------- home: featured banner + rails (Featured, Most viewed, Newest, Most downloaded) ---------- */
  const HOME_RAILS = [["rating", "Featured", "⭐"], ["views", "Most viewed", "🔥"], ["newest", "New releases", "🆕"], ["popular", "Most downloaded", "⬇️"]];

  function seeAll(sort) {
    const sel = document.getElementById("sortSelect");
    if (sel) { sel.value = sort; sel.dispatchEvent(new Event("change")); }
    document.getElementById("storeTitle")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function heroNode(g) {
    const T = (x) => (window.GMI18N ? GMI18N.t(x) : x);
    const desc = (g.description || "").replace(/\s+/g, " ").trim();
    return h("section", { class: "gm-hero" },
      g.cover ? h("img", { src: g.cover, alt: "", loading: "eager", decoding: "async" }) : null,
      h("div", { class: "gm-hero-body" },
        h("div", { class: "gm-kicker" }, T("Featured")),
        h("h2", {}, g.title),
        h("div", { class: "gm-hero-meta" },
          h("span", { class: "tag" }, g.kind === "app" ? T("App") : g.platform),
          g.genre ? h("span", { class: "tag" }, g.genre) : null,
          h("span", { class: "tag" }, T("Free")),
          g.avg_rating ? h("span", { class: "tag" }, "★ " + g.avg_rating) : null),
        desc ? h("p", {}, desc.length > 160 ? desc.slice(0, 157) + "…" : desc) : null,
        h("div", { class: "gm-hero-actions" },
          h("button", { class: "gm-btn", type: "button", onclick: () => openDetail(g.id) }, T("View details")))));
  }

  async function renderHomeRows() {
    const box = document.getElementById("homeRows");
    if (!box) return;
    const T = (x) => (window.GMI18N ? GMI18N.t(x) : x);
    let lists;
    try {
      lists = await Promise.all(HOME_RAILS.map(([sort]) => api("/api/games?sort=" + sort).then((d) => d.games || []).catch(() => [])));
    } catch (e) { return; }
    box.replaceChildren();
    // Branded static hero (lx-hero) already provides the main visual; skip extra gm-hero to match reference design
    HOME_RAILS.forEach(([sort, label, icon], i) => {
      const games = lists[i].slice(0, 12);
      if (!games.length) return;
      box.append(h("section", { class: "home-row lx-row" },
        h("div", { class: "home-row-head lx-row-head" },
          h("h3", {}, h("span", { class: "lx-row-ic" }, icon), " ", T(label)),
          h("button", { class: "see-all lx-seeall", type: "button", onclick: () => seeAll(sort) }, "← " + T("See all"))),
        h("div", { class: "home-scroller" }, ...games.map((g) => cardNode(g)))));
    });
  }
  renderHomeRows();
})();
