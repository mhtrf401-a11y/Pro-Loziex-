/* Dark / light theme. Loaded in <head> so the saved theme is applied before the page paints (no flash). */
(() => {
  const KEY = "gm-theme";
  const saved = (() => { try { return localStorage.getItem(KEY); } catch (e) { return null; } })();
  const current = saved === "light" ? "light" : "dark";
  document.documentElement.dataset.theme = current;

  const label = (t) => (t === "light" ? "☾" : "☀");
  const title = (t) => (t === "light" ? "Dark mode" : "Light mode");
  const paint = () => {
    const b = document.getElementById("themeBtn");
    if (!b) return;
    const t = document.documentElement.dataset.theme;
    b.textContent = label(t);
    b.title = title(t);
    b.setAttribute("aria-label", title(t));
  };
  document.addEventListener("DOMContentLoaded", () => {
    paint();
    const b = document.getElementById("themeBtn");
    if (b) b.addEventListener("click", () => {
      const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
      document.documentElement.dataset.theme = next;
      try { localStorage.setItem(KEY, next); } catch (e) { /* private mode: keep it for this visit only */ }
      paint();
    });
  });
})();
