(() => {
  const { h, api, loadMe, toast, ask, size, date } = GM;
  const app = document.getElementById("app");
  const logoutBtn = document.getElementById("logout");
  let tab = "pending";

  logoutBtn.addEventListener("click", async () => {
    try { await api("/api/logout", { method: "POST" }); } catch {}
    start();
  });

  function loginView(msg) {
    const err = h("div", { class: "err", role: "alert" }, msg || "");
    const email = h("input", { type: "email", required: true, autocomplete: "username" });
    const pw = h("input", { type: "password", required: true, autocomplete: "current-password" });
    const btn = h("button", { class: "btn" }, "Sign in");
    app.replaceChildren(h("div", { class: "box", style: "max-width:380px;margin:0 auto" },
      h("form", { class: "stack", onsubmit: async (e) => {
        e.preventDefault(); btn.disabled = true; err.textContent = "";
        try {
          const r = await api("/api/login", { method: "POST", body: { email: email.value, password: pw.value } });
          if (r.user.role !== "admin") { await api("/api/logout", { method: "POST" }); throw new Error("This account is not an administrator."); }
          start();
        } catch (x) { err.textContent = x.message; btn.disabled = false; }
      } }, h("div", { class: "field" }, h("label", {}, "Admin email"), email), h("div", { class: "field" }, h("label", {}, "Password"), pw), err, btn)));
  }

  async function dashboard() {
    logoutBtn.hidden = false;
    const stats = h("div", { class: "stats" });
    const tabs = h("div", { class: "tabs" });
    const list = h("div", { class: "admin-list" });
    app.replaceChildren(stats, tabs, list);

    const loadStats = async () => {
      const s = await api("/api/admin/stats");
      stats.replaceChildren(...[["Pending", s.pending], ["Published", s.approved], ["Rejected", s.rejected],
        ["Players", s.players], ["Developers", s.developers], ["Library adds", s.downloads]]
        .map(([l, n]) => h("div", { class: "stat" }, h("b", {}, n), h("span", {}, l))));
    };
    const drawTabs = () => tabs.replaceChildren(...[["pending", "Pending"], ["approved", "Published"], ["rejected", "Rejected"], ["all", "All games"], ["users", "Users"]]
      .map(([k, l]) => h("button", { class: "tab" + (tab === k ? " on" : ""), onclick: () => { tab = k; refresh(); } }, l)));

    const act = async (fn, ok) => { try { await fn(); toast(ok); await refresh(); } catch (e) { toast(e.message, true); } };
    const review = (g, action, reason) => api(`/api/admin/games/${g.id}/review`, { method: "POST", body: { action, reason } });

    const gameRow = (g) => h("div", { class: "request" },
      h("img", { src: g.cover, alt: "", style: "width:70px;height:46px;object-fit:cover;border-radius:6px;flex:none" }),
      h("div", { class: "grow" }, h("b", {}, g.title),
        h("small", {}, `${g.dev_name} · ${g.platform} · ${g.genre} · Free${g.build_size ? " · " + size(g.build_size) : ""}${g.has_play ? " · Browser: " + g.play_mode : ""} · ${date(g.created_at)}`),
        h("small", { style: "white-space:pre-wrap" }, g.description.length > 220 ? g.description.slice(0, 220) + "…" : g.description),
        g.requirements ? h("small", {}, "Requirements: " + g.requirements) : null,
        g.demo_url ? h("small", {}, "Demo: ", h("a", { href: g.demo_url, target: "_blank", rel: "noopener noreferrer nofollow", style: "color:#c57cff" }, g.demo_url)) : null,
        (g.screenshots || []).length ? h("div", { style: "display:flex;gap:4px;margin-top:6px" },
          ...g.screenshots.map((s) => h("img", { src: s.url, alt: "", style: "width:46px;height:32px;object-fit:cover;border-radius:4px" }))) : null,
        g.reject_reason ? h("div", { class: "why" }, "Rejected: " + g.reject_reason) : null),
      h("span", { class: "badge st-" + g.status }, { pending: "Pending", approved: "Published", rejected: "Rejected" }[g.status]),
      h("div", { class: "acts" },
        g.has_play ? h("button", { class: "link-btn", onclick: () => GM.previewPlay(g) }, "Preview HTML game") : null,
        g.has_build ? h("a", { class: "link-btn", href: "/download/" + g.id }, "Download build") : null,
        g.status !== "approved" ? h("button", { class: "approve", onclick: () => act(() => review(g, "approve"), "Approved & published") }, "Approve") : null,
        g.status !== "rejected" ? h("button", { class: "reject", onclick: async () => {
          const reason = await ask({ title: "Reject “" + g.title + "”", label: "Reason shown to the developer", ok: "Reject" });
          if (reason) act(() => review(g, "reject", reason), "Rejected");
        } }, "Reject") : null,
        g.status === "approved" ? h("button", { class: "link-btn", onclick: () => act(() => review(g, "unpublish"), "Moved back to pending") }, "Unpublish") : null,
        h("button", { class: "reject", style: "background:#4a1a28", onclick: () => confirm(`Delete "${g.title}" and its files permanently?`) &&
          act(() => api("/api/admin/games/" + g.id, { method: "DELETE" }), "Deleted") }, "Delete")));

    const userRow = (u) => h("div", { class: "request" },
      h("div", { class: "grow" }, h("b", {}, u.name), h("small", {}, `${u.email} · ${u.role}${u.role === "developer" ? " · " + u.games + " games" : ""} · joined ${date(u.created_at)}`)),
      h("span", { class: "badge " + (u.active ? "st-approved" : "st-rejected") }, u.active ? "Active" : "Disabled"),
      u.role === "admin" ? null : h("div", { class: "acts" }, h("button", { class: u.active ? "reject" : "approve",
        onclick: () => act(() => api(`/api/admin/users/${u.id}/active`, { method: "POST", body: { active: !u.active } }), u.active ? "User disabled" : "User enabled") },
        u.active ? "Disable" : "Enable")));

    async function refresh() {
      drawTabs();
      try {
        await loadStats();
        list.replaceChildren();
        if (tab === "users") {
          const { users } = await api("/api/admin/users");
          users.forEach((u) => list.append(userRow(u)));
        } else {
          const { games } = await api("/api/admin/games" + (tab === "all" ? "" : "?status=" + tab));
          if (!games.length) list.append(h("div", { class: "empty" }, "Nothing here."));
          games.forEach((g) => list.append(gameRow(g)));
        }
      } catch (e) { if (e.status === 401 || e.status === 403) start(); else toast(e.message, true); }
    }
    refresh();
  }

  async function start() {
    logoutBtn.hidden = true;
    const d = await loadMe();
    if (d.user && d.user.role === "admin") dashboard();
    else loginView(d.user ? "This account is not an administrator." : "");
  }
  start().catch((e) => toast(e.message, true));
})();
