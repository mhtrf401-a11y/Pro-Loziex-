/* Bilingual UI: English (LTR) and Arabic (RTL). The choice is kept in localStorage and read in a try/catch,
   because storage can be blocked. Strings missing from a dictionary fall back to English. */
window.GMI18N = (() => {
  const DICT = {
    en: {},
    ar: {
      "Featured": "مميزة",
      "New releases": "إصدارات جديدة",
      "Most viewed": "الأكثر مشاهدة",
      "See all": "عرض الكل",
      "View details": "عرض التفاصيل",
      "App": "تطبيق",
      "Free": "مجاني",
      "Featured": "مميزة",
      "Newest": "الأحدث",
      "Most downloaded": "الأكثر تنزيلًا",
      "Dark mode": "الوضع الداكن",
      "Light mode": "الوضع الفاتح",
      "Sent.": "تم الإرسال.",
      "Ranks": "الرتب",
      "Rank progress": "تقدم الرتبة",
      "points to": "نقطة للوصول إلى",
      "Highest rank reached": "وصلت لأعلى رتبة",
      "Rank perks": "مزايا الرتبة",
      "No rank yet. Reach 50 lifetime points to unlock Bronze.": "لا توجد رتبة بعد. اجمع 50 نقطة إجمالية لفتح Bronze.",
      "Ranks are earned from lifetime points. Spending points never lowers your rank.": "تُكتسب الرتب من إجمالي النقاط. إنفاق النقاط لا يخفّض رتبتك أبدًا.",
      "your rank": "رتبتك",
      "Starts at": "تبدأ عند",
      "lifetime points": "نقطة إجمالية",
      "One-time bonus": "مكافأة لمرة واحدة",
      "points": "نقطة",
      "Perks": "المزايا",
      "Developer requests": "طلبات المطورين",
      "Ordered by priority: rank first, and waiting time raises any request so nothing is ignored.": "مرتبة حسب الأولوية: الرتبة أولًا، ومدة الانتظار ترفع أي طلب حتى لا يُهمَل شيء.",
      "No requests yet.": "لا توجد طلبات بعد.",
      "Accept": "قبول",
      "Reject": "رفض",
      "Accepted": "تم القبول",
      "Rejected": "تم الرفض",
      "waiting": "مدة الانتظار",
      "hours": "ساعة",
      "Normal priority": "أولوية عادية",
      "High priority": "أولوية عالية",
      "Highest priority": "أعلى أولوية",
      "Support queue": "طابور الدعم",
      "Reply": "رد",
      "Minimum rank": "أقل رتبة",
      "Open to everyone": "مفتوحة للجميع",
      "Silver and above": "Silver فما فوق",
      "Gold only": "Gold فقط",
      "Your rank": "رتبتك",
      "Weekly events": "الفعاليات الأسبوعية",
      "Complete stages in a featured game and earn GameMarket Points. Rewards are granted after a review.": "أكمل مراحل في لعبة مميزة واحصل على نقاط GameMarket. تُمنح المكافآت بعد المراجعة.",
      "Loading…": "جارٍ التحميل…",
      "No events yet.": "لا توجد فعاليات بعد.",
      "No discounts yet.": "لا توجد خصومات بعد.",
      "Nothing here yet.": "لا يوجد شيء هنا بعد.",
      "stages": "مراحل",
      "upcoming": "قادمة",
      "active": "جارية",
      "ended": "منتهية",
      "All events": "كل الفعاليات",
      "My points": "نقاطي من الفعالية",
      "Not open yet": "لم تبدأ بعد",
      "Event ended": "انتهت الفعالية",
      "Under review": "قيد المراجعة",
      "Completed": "مكتملة",
      "Not available for your account": "غير متاحة لحسابك",
      "Submit proof": "إرسال الإثبات",
      "Submitted for review": "أُرسل للمراجعة",
      "Describe how you completed this stage (what you did, a screenshot link, the time…)": "صف كيف أكملت هذه المرحلة (ما فعلته، رابط لقطة شاشة، الوقت…)",
      "Repeatable": "قابلة للتكرار",
      "Once": "مرة واحدة",
      "Earned": "المكتسب",
      "Temporary discount": "خصم مؤقت",
      "until": "حتى",
      "Admin sign-in required.": "تسجيل دخول الأدمن مطلوب.",
      "Go to admin sign-in": "الانتقال لتسجيل دخول الأدمن",
      "Events": "الفعاليات",
      "Claim reviews": "مراجعة الإثباتات",
      "Discounts": "الخصومات",
      "Event title": "عنوان الفعالية",
      "Description": "الوصف",
      "Stage title": "عنوان المرحلة",
      "Create weekly event": "إنشاء فعالية أسبوعية",
      "Create event": "إنشاء الفعالية",
      "Event created": "تم إنشاء الفعالية",
      "Starts": "البداية",
      "Ends": "النهاية",
      "Add stage": "إضافة مرحلة",
      "Stage added": "تمت إضافة المرحلة",
      "Stop event": "إيقاف الفعالية",
      "Activate": "تفعيل",
      "Show": "عرض",
      "Approve": "موافقة",
      "Reject": "رفض",
      "Approved": "تمت الموافقة",
      "Rejected": "مرفوض",
      "New temporary discount": "خصم مؤقت جديد",
      "Create discount": "إنشاء الخصم",
      "Discount created": "تم إنشاء الخصم",
      "Stop": "إيقاف",
      "stopped": "موقوف",
      "Sign in": "تسجيل الدخول", "Sign out": "تسجيل الخروج", "Create account": "إنشاء حساب",
      "Email": "البريد الإلكتروني", "Password": "كلمة المرور", "Name": "الاسم",
      "Search for games...": "ابحث عن الألعاب...", "Favorites": "المفضلة", "My Library": "مكتبتي",
      "Play Now": "العب الآن", "For Developers": "للمطورين", "All Games": "كل الألعاب", "All Apps": "كل التطبيقات",
      "Games": "الألعاب", "Apps": "التطبيقات", "Download": "تحميل", "Download APK": "تحميل APK",
      "Get for free": "احصل عليها مجانًا", "Free": "مجاني", "100% Free": "مجاني 100%",
      "Update history": "سجل التحديثات", "Screenshots": "صور", "System requirements": "متطلبات التشغيل",
      "Version": "الإصدار", "APK size": "حجم APK", "File size": "حجم الملف", "Category": "التصنيف",
      "Genre": "النوع", "Platform": "المنصة", "Last updated": "آخر تحديث", "Downloads": "التنزيلات",
      "Back to all games": "رجوع لكل الألعاب", "Back to all apps": "رجوع لكل التطبيقات",
      "Overview": "نظرة عامة", "Traffic": "الزيارات", "Content": "المحتوى", "Users": "المستخدمون",
      "Activity": "سجل النشاط", "Security": "الأمان", "System": "النظام", "Settings": "الإعدادات",
      "Backups": "النسخ الاحتياطي", "Export Excel": "تصدير Excel", "Export PDF": "تصدير PDF",
      "Views today": "مشاهدات اليوم", "Views, 7 days": "مشاهدات 7 أيام", "Views, 30 days": "مشاهدات 30 يومًا",
      "Views, all time": "مشاهدات إجمالية", "Players": "اللاعبون", "Developers": "المطورون",
      "Published": "منشورة", "Pending": "قيد المراجعة", "Rejected": "مرفوضة", "Banned": "محظور",
      "Active": "نشط", "Disabled": "موقوف", "Save": "حفظ", "Cancel": "إلغاء", "Delete": "حذف",
      "Ban": "حظر", "Unban": "إلغاء الحظر", "Hide": "إخفاء", "Show": "إظهار", "Pause": "إيقاف مؤقت",
      "Resume": "استئناف", "Maintenance mode": "وضع الصيانة", "Create backup now": "إنشاء نسخة الآن",
      "Loading…": "جارٍ التحميل…", "Nothing here yet.": "لا يوجد شيء بعد.",
      "Trial": "تجربة", "Play now": "العب الآن", "Try for 10 min": "جرّب 10 دقائق",
      "Your 10-minute trial has ended": "انتهت تجربة الـ10 دقائق",
      "Add to library": "أضف للمكتبة", "Favorite": "مفضلة", "Favorited": "في المفضلة",
      "Developer dashboard": "لوحة المطور", "My library": "مكتبتي",
      "Submit for review": "إرسال للمراجعة", "Save changes": "حفظ التغييرات",
      "Cover": "الغلاف", "Icon": "الأيقونة", "Description": "الوصف", "Title": "العنوان",
      "Version history": "سجل الإصدارات", "New version": "إصدار جديد", "Release notes": "ملاحظات الإصدار",
      "Real downloads": "تنزيلات فعلية", "Plays": "مرات اللعب", "Trials": "التجارب",
      "Visibility": "الظهور", "Public": "عام", "Hidden": "مخفي", "Paused": "موقوف مؤقتًا",
      "Scan": "الفحص", "Clean": "نظيف", "Suspicious": "مشبوه", "Infected": "مصاب", "Unscanned": "غير مفحوص",
      "Sign-ups": "التسجيلات", "Page views": "مشاهدات الصفحات", "Visitors": "الزوار",
      "Database": "قاعدة البيانات", "File storage": "تخزين الملفات", "Warnings": "تنبيهات",
      "Language": "اللغة"
    }
  };
  let lang = "en";
  try { lang = localStorage.getItem("gm_lang") === "ar" ? "ar" : "en"; } catch (e) { lang = "en"; }

  function t(s) { return (lang === "ar" && DICT.ar[s]) || s; }
  function apply(root = document) {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.body && document.body.classList.toggle("rtl", lang === "ar");
    root.querySelectorAll("[data-i]").forEach((el) => { el.textContent = t(el.dataset.i); });
    root.querySelectorAll("[data-ip]").forEach((el) => { el.setAttribute("placeholder", t(el.dataset.ip)); });
  }
  function set(l) {
    lang = l === "ar" ? "ar" : "en";
    try { localStorage.setItem("gm_lang", lang); } catch (e) { /* storage blocked: keep it for this page only */ }
    apply();
    window.dispatchEvent(new CustomEvent("gm:lang", { detail: lang }));
  }
  function toggle() { set(lang === "ar" ? "en" : "ar"); }
  // Apply direction as early as possible to avoid a flash of the wrong layout.
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.documentElement.lang = lang;
  document.addEventListener("DOMContentLoaded", () => {
    apply();
    document.querySelectorAll("#langBtn, .lang-btn").forEach((b) => {
      b.textContent = lang === "ar" ? "English" : "عربي";
      b.addEventListener("click", () => { toggle(); b.textContent = lang === "ar" ? "English" : "عربي"; });
    });
  });
  return { t, set, toggle, apply, get lang() { return lang; } };
})();
