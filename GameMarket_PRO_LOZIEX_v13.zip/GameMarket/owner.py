"""Owner dashboard API: everything under /api/owner/*.

Registered by app.py (`owner.register(app_module)`), so it can reuse the app's helpers without a circular import.
All routes are @owner_required (secret path + env-configured credentials + optional TOTP), CSRF-protected for
writes, and every change is written to the audit log. The owner is NOT a row in the users table.
"""
import gzip
import io
import json
import os
import platform
import re
import shutil
import threading
import time
from datetime import datetime, timedelta, timezone

from flask import Response, jsonify, request, send_file

A = None            # the app module, set by register()
BACKUP_TABLES = ["users", "games", "game_images", "game_versions", "favorites", "library", "ratings", "play_trials",
                 "visits", "download_events", "play_events", "audit_log", "settings"]
BACKUP_NAME_RE = re.compile(r"^gamemarket-\d{8}-\d{6}\.json\.gz$")
BOOL_SETTINGS = ("maintenance", "allow_registration", "allow_submissions")
FLAGGED = ("suspicious", "unscanned", "infected")
GROUPS = {"security": ("security",), "auth": ("auth",), "system": ("system",),
          "changes": ("content", "admin", "owner")}


def _utc_day(n=0):
    return (datetime.now(timezone.utc).date() - timedelta(days=n)).isoformat()


def _one(sql, args=()):
    return A.db().execute(sql, args).fetchone()[0]


def _page(default=1):
    try:
        return max(1, int(request.args.get("page", default)))
    except ValueError:
        return default


def _clamp(name, default, lo, hi):
    try:
        return max(lo, min(hi, int(request.args.get(name, default))))
    except ValueError:
        return default


def _like(q):
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


# ------------------------------------------------------------------- metrics
def traffic_series(days):
    c = A.db()
    since = _utc_day(days - 1)

    def by_day(sql):
        return {r[0]: r[1:] for r in c.execute(sql, (since,))}
    views = by_day("SELECT day, COUNT(*), COUNT(DISTINCT visitor) FROM visits WHERE day>=? GROUP BY day")
    plays = by_day("SELECT day, COUNT(*) FROM play_events WHERE day>=? GROUP BY day")
    dls = by_day("SELECT day, COUNT(*) FROM download_events WHERE day>=? GROUP BY day")
    signups = by_day("SELECT substr(created_at,1,10) AS d, COUNT(*) FROM users WHERE role!='admin' AND substr(created_at,1,10)>=? GROUP BY substr(created_at,1,10)")
    out = []
    for n in range(days - 1, -1, -1):
        d = _utc_day(n)
        out.append({"day": d, "views": views.get(d, (0, 0))[0], "visitors": views.get(d, (0, 0))[1],
                    "plays": plays.get(d, (0,))[0], "downloads": dls.get(d, (0,))[0], "signups": signups.get(d, (0,))[0]})
    return out


def top_lists(since, limit=10):
    c = A.db()

    def top(table, extra=""):
        rows = c.execute(
            f"SELECT x.game_id, g.title, g.kind, COUNT(*) AS n FROM {table} x JOIN games g ON g.id=x.game_id "
            f"WHERE {extra}GROUP BY x.game_id, g.title, g.kind ORDER BY n DESC LIMIT {int(limit)}", (since,)).fetchall()
        return [{"id": r["game_id"], "title": r["title"], "kind": r["kind"], "n": r["n"]} for r in rows]
    return {"views": top("visits", "x.day>=? "), "plays": top("play_events", "x.day>=? "),
            "downloads": top("download_events", "x.day>=? "),
            "trials": top("play_trials", "substr(x.started_at,1,10)>=? AND substr(x.visitor,1,1)='a' ")}


def content_counts():
    c = A.db()
    out = {}
    for kind in ("game", "app"):
        out[kind + "s"] = {st: _one("SELECT COUNT(*) FROM games WHERE kind=? AND status=?", (kind, st))
                           for st in ("pending", "approved", "rejected")}
    out["hidden"] = _one("SELECT COUNT(*) FROM games WHERE visibility='hidden'")
    out["paused"] = _one("SELECT COUNT(*) FROM games WHERE visibility='paused'")
    out["flagged"] = _one("SELECT COUNT(*) FROM games WHERE scan_status IN ('suspicious','unscanned','infected')")
    return out


def data_may_be_lost():
    return (not A.database.IS_PG or A.storage.kind == "local") and bool(os.environ.get("RENDER")) and not os.environ.get("GM_PERSISTENT")


# ------------------------------------------------------------------ system
def _rss_bytes():
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) * 1024
    except OSError:
        pass
    return None


def system_info():
    c = A.db()
    t0 = time.perf_counter()
    c.execute("SELECT 1").fetchone()
    ping = round((time.perf_counter() - t0) * 1000, 1)
    counts = {t: _one(f"SELECT COUNT(*) FROM {t}") for t in ("users", "games", "visits", "audit_log", "download_events", "play_events")}
    db_size = None
    try:
        if A.database.IS_PG:
            db_size = _one("SELECT pg_database_size(current_database())")
        else:
            p = str(A.DB_PATH)
            db_size = sum(os.path.getsize(f) for f in (p, p + "-wal", p + "-shm") if os.path.exists(f))
    except Exception:
        A.app.logger.exception("db size failed")
    try:
        st = A.storage.usage()
    except Exception as e:
        A.app.logger.exception("storage usage failed")
        st = {"kind": A.storage.kind, "error": str(e)[:160]}
    try:
        du = shutil.disk_usage(A.DATA)
        disk = {"total": du.total, "free": du.free}
    except OSError:
        disk = None
    try:
        load = [round(x, 2) for x in os.getloadavg()]
    except (OSError, AttributeError):
        load = None
    st_conf = A.all_settings()
    interval = float(os.environ.get("BACKUP_INTERVAL_HOURS", "24") or 0)
    last = st_conf.get("last_backup_at") or None
    cfg = {"cookie_secure": bool(A.app.config["SESSION_COOKIE_SECURE"]), "secret_key_from_env": bool(os.environ.get("SECRET_KEY")),
           "behind_proxy": bool(os.environ.get("TRUST_PROXY") == "1" or os.environ.get("RENDER")),
           "owner_2fa": bool(A.OWNER_TOTP_SECRET), "owner_password_short": A.OWNER_PW_WEAK,
           "play_isolation": "separate-origin" if A.PLAY_ORIGIN else "sandbox-only",
           "scan_engine": A.scanner.engine_name(), "scan_blocks_suspicious": os.environ.get("SCAN_BLOCK_SUSPICIOUS") == "1"}
    warnings = []
    if data_may_be_lost():
        warnings.append("data_may_be_lost")
    if os.environ.get("RENDER") and not cfg["cookie_secure"]:
        warnings.append("cookie_not_secure")
    if os.environ.get("RENDER") and not cfg["secret_key_from_env"]:
        warnings.append("no_secret_key")
    if not cfg["owner_2fa"]:
        warnings.append("no_owner_2fa")
    if cfg["owner_password_short"]:
        warnings.append("owner_password_short")
    if not A.PLAY_ORIGIN:
        warnings.append("no_play_origin")
    if cfg["scan_engine"] == "builtin":
        warnings.append("builtin_scan_only")
    if st.get("capacity") and st.get("used", 0) / st["capacity"] > 0.85:
        warnings.append("storage_almost_full")
    if interval and last:
        try:
            if time.time() - datetime.fromisoformat(last).timestamp() > max(48, interval * 2) * 3600:
                warnings.append("backup_stale")
        except ValueError:
            pass
    elif interval and not last:
        warnings.append("no_backup_yet")
    return {"database": {"type": "postgresql" if A.database.IS_PG else "sqlite", "ping_ms": ping, "size": db_size, "rows": counts},
            "storage": st, "disk": disk,
            "server": {"python": platform.python_version(), "platform": platform.platform(terse=True),
                       "uptime_seconds": int(time.time() - A.PROCESS_STARTED), "rss": _rss_bytes(), "load": load,
                       "cpus": os.cpu_count(), "threads": threading.active_count(), "render": bool(os.environ.get("RENDER"))},
            "config": cfg, "backup": {"interval_hours": interval, "last": last, "keep": int(os.environ.get("BACKUP_KEEP", "7"))},
            "warnings": warnings}


# ------------------------------------------------------------------- backups
def make_backup(trigger="manual"):
    """Dump the database to a gzipped JSON file in storage (R2 bucket when configured, local disk otherwise).
    File contents (covers/builds/HTML5 packages) are NOT included: on R2 they are already durable."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    name = f"gamemarket-{stamp}.json.gz"
    tmp = A.TMP / name
    c, own = A._conn()
    try:
        with gzip.open(tmp, "wt", encoding="utf-8") as out:
            out.write('{"format":"gamemarket-backup-v1","created_at":%s,"database":%s,"tables":{' %
                      (json.dumps(A.now()), json.dumps("postgresql" if A.database.IS_PG else "sqlite")))
            for ti, t in enumerate(BACKUP_TABLES):
                cur = c.execute(f"SELECT * FROM {t}")
                cols = [d[0] for d in cur.description]
                out.write(("," if ti else "") + json.dumps(t) + ':{"columns":' + json.dumps(cols) + ',"rows":[')
                first = True
                while True:
                    rows = cur.fetchmany(1000)
                    if not rows:
                        break
                    for r in rows:
                        out.write(("" if first else ",") + json.dumps(list(r), ensure_ascii=False))
                        first = False
                out.write("]}")
            out.write("}}")
        size = tmp.stat().st_size
    finally:
        if own:
            c.close()
    A.storage.put_backup(name, tmp)
    A.set_setting("last_backup_at", A.now())
    keep = max(1, int(os.environ.get("BACKUP_KEEP", "7")))
    for old in A.storage.list_backups()[keep:]:
        A.storage.delete_backup(old["name"])
    A.audit("system", "backup_created", target=name, detail=f"{trigger}, {size} bytes", actor_type="system")
    return {"name": name, "size": size}


def maybe_scheduled_backup():
    interval = float(os.environ.get("BACKUP_INTERVAL_HOURS", "24") or 0)
    if interval <= 0:
        return
    c = A.connect()
    try:
        c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES('backup_claim','0')")
        c.commit()
        t = int(time.time())
        claimed = c.execute("UPDATE settings SET value=? WHERE key='backup_claim' AND CAST(value AS INTEGER)<=?",
                            (str(t), t - int(interval * 3600))).rowcount
        c.commit()
    finally:
        c.close()
    if not claimed:
        return                                   # another worker already took this round
    try:
        make_backup("scheduled")
    except Exception:
        A.app.logger.exception("scheduled backup failed")
        A.audit("system", "backup_failed", detail="scheduled", actor_type="system")
        c = A.connect()                           # retry in about an hour instead of waiting a full interval
        try:
            c.execute("UPDATE settings SET value=? WHERE key='backup_claim'", (str(int(time.time() - interval * 3600 + 3600)),))
            c.commit()
        finally:
            c.close()


def _scheduler():
    time.sleep(60)
    while True:
        try:
            maybe_scheduled_backup()
        except Exception:
            A.app.logger.exception("backup scheduler error")
        time.sleep(300)


# ------------------------------------------------------------------- routes
def register(app_module):
    global A
    A = app_module
    app, owner_required, ApiError, db, audit = A.app, A.owner_required, A.ApiError, A.db, A.audit

    @app.get("/api/owner/stats")
    @owner_required
    def owner_stats():
        c = db()
        d = _utc_day
        one = _one

        def window(since):
            return {"views": one("SELECT COUNT(*) FROM visits WHERE day>=?", (since,)),
                    "visitors": one("SELECT COUNT(DISTINCT visitor) FROM visits WHERE day>=?", (since,))}
        series = traffic_series(30)
        top_pages = [{"id": r["game_id"], "title": r["title"], "kind": r["kind"], "views": r["n"]} for r in c.execute(
            "SELECT v.game_id, g.title, g.kind, COUNT(*) AS n FROM visits v JOIN games g ON g.id=v.game_id "
            "WHERE v.day>=? GROUP BY v.game_id, g.title, g.kind ORDER BY n DESC LIMIT 10", (d(29),))]
        devices = {r["device"]: r["n"] for r in c.execute(
            "SELECT device, COUNT(*) AS n FROM visits WHERE day>=? GROUP BY device", (d(29),))}
        top_downloads = [{"id": r["id"], "title": r["title"], "kind": r["kind"], "downloads": r["downloads"],
                          "real_downloads": r["dl_count"], "avg_rating": r["avg_rating"]}
                         for r in c.execute(A.BASE_SELECT + "WHERE g.status='approved' ORDER BY dl_count DESC, downloads DESC, g.id DESC LIMIT 5")]
        developers = [dict(r) for r in c.execute(
            "SELECT u.id, u.name, u.email, u.active, u.created_at, "
            "(SELECT COUNT(*) FROM games x WHERE x.dev_id=u.id) AS games, "
            "(SELECT COUNT(*) FROM games x WHERE x.dev_id=u.id AND x.status='approved') AS published, "
            "(SELECT COUNT(*) FROM download_events de JOIN games x ON x.id=de.game_id WHERE x.dev_id=u.id) AS downloads "
            "FROM users u WHERE u.role='developer' ORDER BY downloads DESC, games DESC, u.id DESC LIMIT 25")]
        cc = content_counts()
        since24 = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec="seconds")
        since7 = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat(timespec="seconds")
        fail_actions = "('login_failed','owner_login_failed')"
        return jsonify(
            visits={"today": window(d(0)), "week": window(d(6)), "month": window(d(29)),
                    "total": {"views": one("SELECT COUNT(*) FROM visits"),
                              "visitors": one("SELECT COUNT(DISTINCT visitor) FROM visits")}},
            series=series, top_pages=top_pages, devices=devices,
            home_views_30d=one("SELECT COUNT(*) FROM visits WHERE path='/' AND day>=?", (d(29),)),
            users={"players": one("SELECT COUNT(*) FROM users WHERE role='player'"),
                   "developers": one("SELECT COUNT(*) FROM users WHERE role='developer'"),
                   "admins": one("SELECT COUNT(*) FROM users WHERE role='admin'"),
                   "banned": one("SELECT COUNT(*) FROM users WHERE active=0"),
                   "new_24h": one("SELECT COUNT(*) FROM users WHERE role!='admin' AND created_at>=?", (since24,)),
                   "new_7d": one("SELECT COUNT(*) FROM users WHERE role!='admin' AND created_at>=?", (d(6),)),
                   "new_30d": one("SELECT COUNT(*) FROM users WHERE role!='admin' AND created_at>=?", (d(29),))},
            games={"pending": cc["games"]["pending"] + cc["apps"]["pending"],
                   "approved": cc["games"]["approved"] + cc["apps"]["approved"],
                   "rejected": cc["games"]["rejected"] + cc["apps"]["rejected"]},
            content=cc,
            engagement={"downloads": one("SELECT COUNT(*) FROM library"), "real_downloads": one("SELECT COUNT(*) FROM download_events"),
                        "plays": one("SELECT COUNT(*) FROM play_events"),
                        "trials": one("SELECT COUNT(*) FROM play_trials WHERE substr(visitor,1,1)='a'"),
                        "favorites": one("SELECT COUNT(*) FROM favorites"), "ratings": one("SELECT COUNT(*) FROM ratings")},
            security={"failed_24h": one(f"SELECT COUNT(*) FROM audit_log WHERE action IN {fail_actions} AND ts>=?", (since24,)),
                      "failed_7d": one(f"SELECT COUNT(*) FROM audit_log WHERE action IN {fail_actions} AND ts>=?", (since7,)),
                      "blocked_24h": one("SELECT COUNT(*) FROM audit_log WHERE action LIKE '%blocked' AND ts>=?", (since24,)),
                      "events_24h": one("SELECT COUNT(*) FROM audit_log WHERE category='security' AND ts>=?", (since24,))},
            top_downloads=top_downloads, developers=developers,
            maintenance=A.get_setting("maintenance") == "1",
            system={"database": "postgresql" if A.database.IS_PG else "sqlite", "storage": A.storage.kind,
                    "data_may_be_lost": data_may_be_lost()})

    @app.get("/api/owner/traffic")
    @owner_required
    def owner_traffic():
        days = _clamp("days", 30, 7, 365)
        since = _utc_day(days - 1)
        c = db()
        devices = {r["device"]: r["n"] for r in c.execute("SELECT device, COUNT(*) AS n FROM visits WHERE day>=? GROUP BY device", (since,))}
        home = _one("SELECT COUNT(*) FROM visits WHERE day>=? AND path='/'", (since,))
        return jsonify(days=days, series=traffic_series(days), top=top_lists(since), devices=devices, home_views=home)

    # ---------------------------------------------------------------- content
    CONTENT_SQL = (
        "SELECT g.id,g.title,g.kind,g.status,g.visibility,g.version,g.scan_status,g.scan_note,g.created_at,g.updated_at,"
        "g.build_size,g.play_mode,g.play_file,g.cover,g.slug,g.dev_id,g.reject_reason,u.name AS dev_name,u.active AS dev_active,"
        " (SELECT COUNT(*) FROM visits v WHERE v.game_id=g.id) AS views_total,"
        " (SELECT COUNT(*) FROM visits v WHERE v.game_id=g.id AND v.day>=?) AS views_30d,"
        " (SELECT COUNT(*) FROM play_events p WHERE p.game_id=g.id) AS plays,"
        " (SELECT COUNT(*) FROM play_trials t WHERE t.game_id=g.id AND substr(t.visitor,1,1)='a') AS trials,"
        " (SELECT COUNT(*) FROM download_events d WHERE d.game_id=g.id) AS downloads,"
        " (SELECT COUNT(*) FROM library l WHERE l.game_id=g.id) AS library_adds,"
        " (SELECT CAST(ROUND(AVG(stars),1) AS REAL) FROM ratings r WHERE r.game_id=g.id) AS avg_rating,"
        " (SELECT COUNT(*) FROM game_versions gv WHERE gv.game_id=g.id) AS version_count "
        "FROM games g JOIN users u ON u.id=g.dev_id ")
    SORTS = {"newest": "g.id DESC", "views": "views_30d DESC, g.id DESC", "downloads": "downloads DESC, g.id DESC",
             "plays": "plays DESC, g.id DESC", "title": "g.title ASC"}

    def content_rows(where, args, order, limit, offset):
        rows = db().execute(f"{CONTENT_SQL} {where} ORDER BY {order} LIMIT ? OFFSET ?",
                            [_utc_day(29)] + args + [limit, offset]).fetchall()
        out = []
        for r in rows:
            d = {k: r[k] for k in r.keys() if k != "play_file"}
            d["has_play"] = bool(r["play_file"])
            d["cover"] = A.cover_url(r["cover"])
            d["url"] = A.item_url(r)
            out.append(d)
        return out

    @app.get("/api/owner/content")
    @owner_required
    def owner_content():
        where, args = [], []
        kind = request.args.get("kind")
        if kind in A.KINDS:
            where.append("g.kind=?"); args.append(kind)
        st = request.args.get("status")
        if st in ("pending", "approved", "rejected"):
            where.append("g.status=?"); args.append(st)
        vis = request.args.get("visibility")
        if vis in A.VISIBILITIES:
            where.append("g.visibility=?"); args.append(vis)
        if request.args.get("flagged") == "1":
            where.append("g.scan_status IN ('suspicious','unscanned','infected')")
        q = request.args.get("q", "").strip()[:60]
        if q:
            where.append("(g.title LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\')")
            args += [_like(q), _like(q)]
        w = ("WHERE " + " AND ".join(where)) if where else ""
        total = db().execute(f"SELECT COUNT(*) FROM games g JOIN users u ON u.id=g.dev_id {w}", args).fetchone()[0]
        per, page = 25, _page()
        items = content_rows(w, args, SORTS.get(request.args.get("sort"), SORTS["newest"]), per, (page - 1) * per)
        return jsonify(items=items, total=total, page=page, per_page=per)

    def get_game(gid):
        r = db().execute("SELECT * FROM games WHERE id=?", (gid,)).fetchone()
        if not r:
            raise ApiError("Item not found", 404)
        return r

    @app.post("/api/owner/games/<int:gid>/visibility")
    @owner_required
    def owner_visibility(gid):
        r = get_game(gid)
        d = A.body()
        v, reason = d.get("visibility"), str(d.get("reason", "")).strip()[:300]
        if v not in A.VISIBILITIES:
            raise ApiError("Unknown visibility")
        db().execute("UPDATE games SET visibility=? WHERE id=?", (v, gid))
        db().commit()
        audit("owner", "visibility_" + v, target=gid, detail=f"{r['title']} (was {r['visibility']})" + (f": {reason}" if reason else ""))
        return jsonify(ok=True, visibility=v)

    @app.post("/api/owner/games/<int:gid>/review")
    @owner_required
    def owner_review(gid):
        r = get_game(gid)
        d = A.body()
        action, reason = d.get("action"), str(d.get("reason", "")).strip()[:500]
        if action == "approve":
            new, reason = "approved", None
        elif action == "reject":
            if len(reason) < 3:
                raise ApiError("Give the developer a reason for the rejection")
            new = "rejected"
        elif action == "unpublish":
            new, reason = "pending", None
        else:
            raise ApiError("Unknown action")
        db().execute("UPDATE games SET status=?, reject_reason=?, reviewed_at=? WHERE id=?", (new, reason, A.now(), gid))
        db().commit()
        audit("owner", "review_" + action, target=gid, detail=r["title"] + (f": {reason}" if reason else ""))
        return jsonify(ok=True, status=new)

    @app.delete("/api/owner/games/<int:gid>")
    @owner_required
    def owner_delete(gid):
        r = get_game(gid)
        if not A.body().get("confirm"):
            raise ApiError("Deletion needs explicit confirmation")
        A.purge_game(r)
        audit("owner", "delete_" + r["kind"], target=gid, detail=r["title"])
        return jsonify(ok=True)

    @app.get("/api/owner/games/<int:gid>/versions")
    @owner_required
    def owner_versions(gid):
        r = get_game(gid)
        rows = db().execute("SELECT id,version,notes,build,build_size,created_at,created_by FROM game_versions "
                            "WHERE game_id=? ORDER BY id DESC", (gid,)).fetchall()
        return jsonify(current=r["version"], versions=[
            {"id": x["id"], "version": x["version"], "notes": x["notes"], "build_size": x["build_size"], "created_at": x["created_at"],
             "has_build": bool(x["build"]), "is_current": bool(x["build"]) and x["build"] == r["build"]} for x in rows])

    @app.post("/api/owner/versions/<int:vid>/make-current")
    @owner_required
    def owner_make_current(vid):
        v = db().execute("SELECT * FROM game_versions WHERE id=?", (vid,)).fetchone()
        if not v or not v["build"]:
            raise ApiError("This version has no stored build to roll back to", 404)
        r = get_game(v["game_id"])
        db().execute("UPDATE games SET build=?, build_size=?, version=?, updated_at=? WHERE id=?",
                     (v["build"], v["build_size"], v["version"], A.now(), r["id"]))
        db().commit()
        audit("owner", "version_make_current", target=r["id"], detail=f"{r['title']}: {r['version']} -> {v['version']}")
        return jsonify(ok=True)

    @app.delete("/api/owner/versions/<int:vid>")
    @owner_required
    def owner_delete_version(vid):
        v = db().execute("SELECT * FROM game_versions WHERE id=?", (vid,)).fetchone()
        if not v:
            raise ApiError("Version not found", 404)
        r = get_game(v["game_id"])
        A.remove_version(r, vid)
        audit("owner", "version_delete", target=r["id"], detail=f"{r['title']}: {v['version']}")
        return jsonify(ok=True)

    @app.get("/api/owner/updates")
    @owner_required
    def owner_updates():
        rows = db().execute(
            "SELECT gv.id, gv.version, gv.notes, gv.created_at, gv.build_size, g.id AS game_id, g.title, g.kind, g.status "
            "FROM game_versions gv JOIN games g ON g.id=gv.game_id ORDER BY gv.id DESC LIMIT 40").fetchall()
        return jsonify(updates=[dict(r) for r in rows])

    # ------------------------------------------------------------------ users
    @app.get("/api/owner/users")
    @owner_required
    def owner_users():
        where, args = [], []
        role = request.args.get("role")
        if role in ("player", "developer", "admin"):
            where.append("u.role=?"); args.append(role)
        status = request.args.get("status")
        if status in ("active", "banned"):
            where.append("u.active=?"); args.append(1 if status == "active" else 0)
        q = request.args.get("q", "").strip()[:60]
        if q:
            where.append("(u.email LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\')")
            args += [_like(q), _like(q)]
        w = ("WHERE " + " AND ".join(where)) if where else ""
        total = db().execute(f"SELECT COUNT(*) FROM users u {w}", args).fetchone()[0]
        per, page = 30, _page()
        rows = db().execute(
            "SELECT u.id,u.name,u.email,u.role,u.active,u.created_at,u.last_login_at,"
            "(SELECT COUNT(*) FROM games x WHERE x.dev_id=u.id) AS games,"
            "(SELECT COUNT(*) FROM library l WHERE l.user_id=u.id) AS library "
            f"FROM users u {w} ORDER BY u.id DESC LIMIT ? OFFSET ?", args + [per, (page - 1) * per]).fetchall()
        return jsonify(users=[dict(r) for r in rows], total=total, page=page, per_page=per)

    @app.post("/api/owner/users/<int:uid>/ban")
    @owner_required
    def owner_ban(uid):
        d = A.body()
        banned = bool(d.get("banned"))
        reason = str(d.get("reason", "")).strip()[:300]
        u = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not u:
            raise ApiError("User not found", 404)
        if banned and u["role"] == "admin" and not db().execute(
                "SELECT 1 FROM users WHERE role='admin' AND active=1 AND id!=?", (uid,)).fetchone():
            raise ApiError("At least one active admin must remain")
        db().execute("UPDATE users SET active=? WHERE id=?", (0 if banned else 1, uid))
        touched = 0
        if u["role"] == "developer":
            if banned and d.get("pause_games"):
                touched = db().execute("UPDATE games SET visibility='paused' WHERE dev_id=? AND visibility='public'", (uid,)).rowcount
            elif not banned and d.get("restore_games"):
                touched = db().execute("UPDATE games SET visibility='public' WHERE dev_id=? AND visibility='paused'", (uid,)).rowcount
        db().commit()
        what = ("suspend_developer" if u["role"] == "developer" else "ban_user") if banned else \
               ("unsuspend_developer" if u["role"] == "developer" else "unban_user")
        audit("owner", what, target=uid, detail=f"{u['email']}" + (f": {reason}" if reason else "") + (f" ({touched} items changed)" if touched else ""))
        return jsonify(ok=True, active=not banned, items_changed=touched)

    # -------------------------------------------------------- activity / security
    @app.get("/api/owner/activity")
    @owner_required
    def owner_activity():
        where, args = [], []
        cats = GROUPS.get(request.args.get("group"))
        if cats:
            where.append(f"category IN ({','.join('?' * len(cats))})"); args += list(cats)
        before = request.args.get("before", "")
        if before.isdigit():
            where.append("id<?"); args.append(int(before))
        q = request.args.get("q", "").strip()[:60]
        if q:
            where.append("(action LIKE ? ESCAPE '\\' OR target LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\' OR actor LIKE ? ESCAPE '\\')")
            args += [_like(q)] * 4
        w = ("WHERE " + " AND ".join(where)) if where else ""
        limit = _clamp("limit", 50, 10, 200)
        rows = db().execute(f"SELECT id,ts,category,actor_type,actor,action,target,detail,ip FROM audit_log {w} ORDER BY id DESC LIMIT ?",
                            args + [limit + 1]).fetchall()
        more = len(rows) > limit
        rows = rows[:limit]
        return jsonify(events=[dict(r) for r in rows], next=rows[-1]["id"] if (more and rows) else None)

    @app.get("/api/owner/security")
    @owner_required
    def owner_security():
        c = db()
        since24 = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec="seconds")
        fails = "action IN ('login_failed','owner_login_failed','login_disabled_account')"
        top_ips = [dict(r) for r in c.execute(
            f"SELECT ip, COUNT(*) AS n FROM audit_log WHERE {fails} AND ts>=? AND ip IS NOT NULL GROUP BY ip ORDER BY n DESC LIMIT 5", (since24,))]
        top_targets = [dict(r) for r in c.execute(
            f"SELECT target, COUNT(*) AS n FROM audit_log WHERE {fails} AND ts>=? AND target IS NOT NULL GROUP BY target ORDER BY n DESC LIMIT 5", (since24,))]
        owner_log = [dict(r) for r in c.execute(
            "SELECT id,ts,action,detail,ip FROM audit_log WHERE action LIKE 'owner_%' ORDER BY id DESC LIMIT 15")]
        flagged = [dict(r) for r in c.execute(
            "SELECT g.id, g.title, g.kind, g.scan_status, g.scan_note, g.status, g.visibility, u.name AS dev_name FROM games g "
            "JOIN users u ON u.id=g.dev_id WHERE g.scan_status IN ('suspicious','unscanned','infected') ORDER BY g.id DESC LIMIT 20")]
        return jsonify(
            failed_24h=_one(f"SELECT COUNT(*) FROM audit_log WHERE {fails} AND ts>=?", (since24,)),
            blocked_24h=_one("SELECT COUNT(*) FROM audit_log WHERE action LIKE '%blocked%' AND ts>=?", (since24,)),
            rate_limited_downloads_24h=_one("SELECT COUNT(*) FROM audit_log WHERE action='download_rate_limited' AND ts>=?", (since24,)),
            scan_events_24h=_one("SELECT COUNT(*) FROM audit_log WHERE action LIKE 'upload_scan_%' AND ts>=?", (since24,)),
            banned_users=_one("SELECT COUNT(*) FROM users WHERE active=0"),
            top_ips=top_ips, top_targets=top_targets, owner_log=owner_log, flagged=flagged,
            recent=[dict(r) for r in c.execute(
                "SELECT id,ts,actor_type,actor,action,target,detail,ip FROM audit_log WHERE category='security' ORDER BY id DESC LIMIT 40")])

    @app.get("/api/owner/system")
    @owner_required
    def owner_system():
        return jsonify(system_info())

    # --------------------------------------------------------------- settings
    @app.get("/api/owner/settings")
    @owner_required
    def owner_settings():
        s = A.all_settings()
        return jsonify(settings={k: s[k] for k in A.SETTING_DEFAULTS}, default_trial_seconds=A.TRIAL_SECONDS)

    @app.post("/api/owner/settings")
    @owner_required
    def owner_settings_save():
        d = A.body()
        changes = {}
        for k in A.SETTING_DEFAULTS:
            if k not in d:
                continue
            v = d[k]
            if k in BOOL_SETTINGS:
                v = "1" if v in (True, 1, "1", "true") else "0"
            elif k in ("maintenance_message", "announcement"):
                v = str(v or "").strip()[:300]
            elif k == "trial_seconds":
                v = str(v or "").strip()
                if v and not (v.isdigit() and 30 <= int(v) <= 86400):
                    raise ApiError("Trial length must be between 30 and 86400 seconds (or empty for the default)")
            changes[k] = v
        old = A.all_settings()
        for k, v in changes.items():
            if old.get(k) != v:
                A.set_setting(k, v)
                audit("owner", "setting_" + k, target=k, detail=f"{str(old.get(k))[:80]!r} -> {str(v)[:80]!r}")
        s = A.all_settings()
        return jsonify(ok=True, settings={k: s[k] for k in A.SETTING_DEFAULTS})

    # ---------------------------------------------------------------- backups
    @app.get("/api/owner/backups")
    @owner_required
    def owner_backups():
        return jsonify(backups=A.storage.list_backups(), interval_hours=float(os.environ.get("BACKUP_INTERVAL_HOURS", "24") or 0),
                       keep=int(os.environ.get("BACKUP_KEEP", "7")), last=A.all_settings().get("last_backup_at") or None,
                       storage=A.storage.kind)

    @app.post("/api/owner/backups")
    @owner_required
    def owner_backup_now():
        try:
            res = make_backup("manual")
        except Exception:
            app.logger.exception("manual backup failed")
            audit("system", "backup_failed", detail="manual")
            raise ApiError("The backup failed. Check the server logs.", 500)
        return jsonify(ok=True, **res)

    @app.get("/api/owner/backups/<name>")
    @owner_required
    def owner_backup_download(name):
        if not BACKUP_NAME_RE.match(name):
            raise ApiError("Not found", 404)
        audit("owner", "backup_download", target=name)
        resp = A.storage.backup_response(name)
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.delete("/api/owner/backups/<name>")
    @owner_required
    def owner_backup_delete(name):
        if not BACKUP_NAME_RE.match(name):
            raise ApiError("Not found", 404)
        A.storage.delete_backup(name)
        audit("owner", "backup_delete", target=name)
        return jsonify(ok=True)

    # ----------------------------------------------------------------- export
    @app.get("/api/owner/export.xlsx")
    @owner_required
    def owner_export():
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font
        except ImportError:
            raise ApiError("Excel export needs the openpyxl package (add it to requirements.txt).", 501)
        days = _clamp("days", 30, 7, 365)
        ar = request.args.get("lang") == "ar"
        wb = Workbook()

        def put(ws, row):
            ws.append(row)
            for cell in ws[ws.max_row]:
                if isinstance(cell.value, str) and cell.value[:1] in ("=", "+", "-", "@"):
                    cell.data_type = "s"          # never let user-controlled text become a formula
        def head(ws, labels):
            put(ws, labels)
            for cell in ws[1]:
                cell.font = Font(bold=True)
            ws.freeze_panes = "A2"
            if ar:
                ws.sheet_view.rightToLeft = True
        T = (lambda en, a: f"{en} / {a}") if ar else (lambda en, a: en)
        ws = wb.active
        ws.title = "Summary"
        head(ws, [T("Metric", "المؤشر"), T("Value", "القيمة")])
        eng = {"visits_total": _one("SELECT COUNT(*) FROM visits"), "visitors_total": _one("SELECT COUNT(DISTINCT visitor) FROM visits"),
               "players": _one("SELECT COUNT(*) FROM users WHERE role='player'"),
               "developers": _one("SELECT COUNT(*) FROM users WHERE role='developer'"),
               "banned": _one("SELECT COUNT(*) FROM users WHERE active=0"),
               "downloads_real": _one("SELECT COUNT(*) FROM download_events"), "library_adds": _one("SELECT COUNT(*) FROM library"),
               "plays": _one("SELECT COUNT(*) FROM play_events"), "favorites": _one("SELECT COUNT(*) FROM favorites"),
               "ratings": _one("SELECT COUNT(*) FROM ratings")}
        cc = content_counts()
        labels = {"visits_total": ("Page views (all time)", "مشاهدات الصفحات (الإجمالي)"),
                  "visitors_total": ("Unique visitors (all time)", "الزوار الفريدون (الإجمالي)"),
                  "players": ("Players", "اللاعبون"), "developers": ("Developers", "المطورون"), "banned": ("Banned/suspended", "محظور/موقوف"),
                  "downloads_real": ("Actual downloads", "التنزيلات الفعلية"), "library_adds": ("Library adds", "الإضافات للمكتبة"),
                  "plays": ("Browser plays", "مرات اللعب في المتصفح"), "favorites": ("Favorites", "المفضلة"), "ratings": ("Ratings", "التقييمات")}
        for k, v in eng.items():
            put(ws, [T(*labels[k]), v])
        for kind, (en, a) in (("games", ("Games", "الألعاب")), ("apps", ("Apps", "التطبيقات"))):
            for st, (sen, sa) in (("approved", ("published", "منشورة")), ("pending", ("pending", "قيد المراجعة")), ("rejected", ("rejected", "مرفوضة"))):
                put(ws, [f"{T(en, a)} - {T(sen, sa)}", cc[kind][st]])
        put(ws, [T("Hidden", "مخفية"), cc["hidden"]])
        put(ws, [T("Paused", "موقوفة مؤقتًا"), cc["paused"]])
        put(ws, [T("Flagged by upload scan", "مُعلَّمة من فحص الرفع"), cc["flagged"]])
        ws.column_dimensions["A"].width = 40
        ws2 = wb.create_sheet("Daily")
        head(ws2, [T("Day", "اليوم"), T("Views", "المشاهدات"), T("Visitors", "الزوار"), T("Plays", "اللعب"),
                   T("Downloads", "التنزيلات"), T("Sign-ups", "التسجيلات")])
        for r in traffic_series(days):
            put(ws2, [r["day"], r["views"], r["visitors"], r["plays"], r["downloads"], r["signups"]])
        ws3 = wb.create_sheet("Games & Apps")
        head(ws3, [T("ID", "المعرف"), T("Title", "العنوان"), T("Type", "النوع"), T("Developer", "المطور"), T("Status", "الحالة"),
                   T("Visibility", "الظهور"), T("Version", "الإصدار"), T("Scan", "الفحص"), T("Views 30d", "مشاهدات 30 يوم"),
                   T("Views total", "إجمالي المشاهدات"), T("Plays", "اللعب"), T("Trials", "التجارب"), T("Downloads", "التنزيلات"),
                   T("Library adds", "إضافات المكتبة"), T("Rating", "التقييم"), T("Created", "تاريخ الإضافة")])
        for r in content_rows("", [], "g.id DESC", 5000, 0):
            put(ws3, [r["id"], r["title"], r["kind"], r["dev_name"], r["status"], r["visibility"], r["version"], r["scan_status"],
                      r["views_30d"], r["views_total"], r["plays"], r["trials"], r["downloads"], r["library_adds"], r["avg_rating"], r["created_at"]])
        ws4 = wb.create_sheet("Users")
        head(ws4, [T("ID", "المعرف"), T("Name", "الاسم"), T("Email", "البريد"), T("Role", "الدور"), T("Active", "نشط"),
                   T("Joined", "تاريخ التسجيل"), T("Last login", "آخر دخول"), T("Items", "الأعمال")])
        for r in db().execute("SELECT u.id,u.name,u.email,u.role,u.active,u.created_at,u.last_login_at,"
                              "(SELECT COUNT(*) FROM games x WHERE x.dev_id=u.id) AS n FROM users u ORDER BY u.id DESC LIMIT 5000"):
            put(ws4, [r["id"], r["name"], r["email"], r["role"], "yes" if r["active"] else "no", r["created_at"], r["last_login_at"], r["n"]])
        ws5 = wb.create_sheet("Activity")
        head(ws5, [T("Time (UTC)", "الوقت (UTC)"), T("Category", "التصنيف"), T("Actor", "المنفّذ"), T("Action", "الإجراء"),
                   T("Target", "الهدف"), T("Detail", "التفاصيل")])
        for r in db().execute("SELECT ts,category,actor_type,actor,action,target,detail FROM audit_log ORDER BY id DESC LIMIT 3000"):
            put(ws5, [r["ts"], r["category"], f"{r['actor_type']}:{r['actor'] or ''}", r["action"], r["target"], r["detail"]])
        bio = io.BytesIO()
        wb.save(bio)
        bio.seek(0)
        audit("owner", "export_xlsx", detail=f"{days} days")
        resp = send_file(bio, as_attachment=True, download_name=f"gamemarket-report-{_utc_day()}.xlsx",
                         mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        resp.headers["Cache-Control"] = "no-store"
        return resp

    if os.environ.get("GM_BACKGROUND", "1") == "1" and float(os.environ.get("BACKUP_INTERVAL_HOURS", "24") or 0) > 0:
        threading.Thread(target=_scheduler, name="gm-backup", daemon=True).start()
