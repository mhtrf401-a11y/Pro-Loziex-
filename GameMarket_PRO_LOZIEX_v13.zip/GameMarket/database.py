"""Database layer: SQLite by default, PostgreSQL when DATABASE_URL is set.

The app code is written once with SQLite-style SQL ("?" placeholders). For PostgreSQL the
small translator below adapts it. Nothing else in the app needs to know which one is used.
"""
import os
import re
import sqlite3
from pathlib import Path

DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql://" + DATABASE_URL[len("postgres://"):]
IS_PG = DATABASE_URL.startswith("postgresql://")

if IS_PG:
    import psycopg2
    import psycopg2.extras
    import psycopg2.pool
    IntegrityErrors = (psycopg2.IntegrityError,)
else:
    IntegrityErrors = (sqlite3.IntegrityError,)

_pool = None
SQLITE_PATH = None


def configure(sqlite_path):
    global SQLITE_PATH
    SQLITE_PATH = sqlite_path


def to_pg(sql):
    """Translate the app's SQLite-flavoured SQL to PostgreSQL."""
    sql = sql.replace("%", "%%")
    sql = re.sub(r"INSERT OR IGNORE INTO (.*)", r"INSERT INTO \1 ON CONFLICT DO NOTHING", sql, flags=re.S)
    sql = sql.replace(" LIKE ", " ILIKE ")      # SQLite LIKE is case-insensitive, PG's is not
    return sql.replace("?", "%s")


class Conn:
    def __init__(self, raw, pg):
        self.raw, self.pg = raw, pg

    def execute(self, sql, args=()):
        if self.pg:
            cur = self.raw.cursor(cursor_factory=psycopg2.extras.DictCursor)
            cur.execute(to_pg(sql), tuple(args))
            return cur
        return self.raw.execute(sql, tuple(args))

    def insert_id(self, sql, args=()):
        """Run an INSERT into a table with an integer `id` and return the new id."""
        if self.pg:
            return self.execute(sql + " RETURNING id", args).fetchone()[0]
        return self.execute(sql, args).lastrowid

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        if self.pg:
            try:
                self.raw.rollback()
            finally:
                _pool.putconn(self.raw)
        else:
            self.raw.close()


def connect():
    global _pool
    if IS_PG:
        if _pool is None:
            _pool = psycopg2.pool.ThreadedConnectionPool(1, int(os.environ.get("DB_POOL_MAX", "5")), DATABASE_URL)
        return Conn(_pool.getconn(), True)
    c = sqlite3.connect(SQLITE_PATH, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA journal_mode=WAL")
    return Conn(c, False)


_COMMON_TAIL = [
    "CREATE INDEX IF NOT EXISTS idx_games_status ON games(status)",
    "CREATE INDEX IF NOT EXISTS idx_images_game ON game_images(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_visits_day ON visits(day)",
]

SQLITE_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
  password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN('player','developer','admin')),
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS games(
  id INTEGER PRIMARY KEY AUTOINCREMENT, dev_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT NOT NULL, platform TEXT NOT NULL, genre TEXT NOT NULL,
  price_cents INTEGER NOT NULL DEFAULT 0, old_price_cents INTEGER, cover TEXT NOT NULL, build TEXT,
  build_size INTEGER NOT NULL DEFAULT 0, demo_url TEXT, requirements TEXT, slug TEXT,
  play_file TEXT, play_mode TEXT NOT NULL DEFAULT 'none',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','approved','rejected')),
  reject_reason TEXT, created_at TEXT NOT NULL, reviewed_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS game_images(
  id INTEGER PRIMARY KEY AUTOINCREMENT, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  filename TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0)""",
    """CREATE TABLE IF NOT EXISTS visits(
  id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, ts TEXT NOT NULL, path TEXT NOT NULL,
  game_id INTEGER, visitor TEXT NOT NULL, device TEXT NOT NULL)""",
]

PG_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS users(
  id SERIAL PRIMARY KEY, email TEXT NOT NULL, name TEXT NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('player','developer','admin')),
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(LOWER(email))",
    """CREATE TABLE IF NOT EXISTS games(
  id SERIAL PRIMARY KEY, dev_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT NOT NULL, platform TEXT NOT NULL, genre TEXT NOT NULL,
  cover TEXT NOT NULL, build TEXT, build_size BIGINT NOT NULL DEFAULT 0, demo_url TEXT,
  requirements TEXT, slug TEXT, play_file TEXT, play_mode TEXT NOT NULL DEFAULT 'none',
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','approved','rejected')),
  reject_reason TEXT, created_at TEXT NOT NULL, reviewed_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS game_images(
  id SERIAL PRIMARY KEY, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  filename TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0)""",
    """CREATE TABLE IF NOT EXISTS visits(
  id SERIAL PRIMARY KEY, day TEXT NOT NULL, ts TEXT NOT NULL, path TEXT NOT NULL,
  game_id INTEGER, visitor TEXT NOT NULL, device TEXT NOT NULL)""",
]

_SHARED = [
    """CREATE TABLE IF NOT EXISTS favorites(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE, PRIMARY KEY(user_id, game_id))""",
    """CREATE TABLE IF NOT EXISTS library(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL, PRIMARY KEY(user_id, game_id))""",
    """CREATE TABLE IF NOT EXISTS ratings(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  stars INTEGER NOT NULL CHECK(stars BETWEEN 1 AND 5), PRIMARY KEY(user_id, game_id))""",
    """CREATE TABLE IF NOT EXISTS play_trials(
  visitor TEXT NOT NULL, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  started_at TEXT NOT NULL, PRIMARY KEY(visitor, game_id))""",
]


_PK = "SERIAL PRIMARY KEY" if IS_PG else "INTEGER PRIMARY KEY AUTOINCREMENT"

# ---- GameMarket v4 systems: reviews, support, dev contacts, XP/points/ranks, shops ----
_V4_TABLES = [
    f"""CREATE TABLE IF NOT EXISTS reviews(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  stars REAL NOT NULL CHECK(stars BETWEEN 0.5 AND 5),
  review_text TEXT NOT NULL DEFAULT '',
  sentiment TEXT NOT NULL DEFAULT 'positive' CHECK(sentiment IN('positive','negative')),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  PRIMARY KEY(user_id, game_id))""",
    f"""CREATE TABLE IF NOT EXISTS support_tickets(
  id {_PK}, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  subject TEXT NOT NULL, message TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'general',
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN('open','answered','closed')),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS support_replies(
  id {_PK}, ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author_role TEXT NOT NULL DEFAULT 'player', message TEXT NOT NULL, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS dev_contacts(
  id {_PK}, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  player_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  dev_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN('pending','accepted','rejected','closed')),
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS dev_messages(
  id {_PK}, contact_id INTEGER NOT NULL REFERENCES dev_contacts(id) ON DELETE CASCADE,
  sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message TEXT NOT NULL, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS player_progress(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 1,
  points_total INTEGER NOT NULL DEFAULT 0, points_balance INTEGER NOT NULL DEFAULT 0,
  rank TEXT NOT NULL DEFAULT 'none' CHECK(rank IN('none','bronze','silver','gold')))""",
    f"""CREATE TABLE IF NOT EXISTS xp_events(
  id {_PK}, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS points_events(
  id {_PK}, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount INTEGER NOT NULL, kind TEXT NOT NULL CHECK(kind IN('earn','spend')),
  reason TEXT NOT NULL, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS rank_history(
  id {_PK}, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rank TEXT NOT NULL, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS shop_items(
  id {_PK}, store TEXT NOT NULL CHECK(store IN('normal','pro','promax')),
  kind TEXT NOT NULL, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
  price INTEGER NOT NULL CHECK(price >= 0), css TEXT NOT NULL DEFAULT '{{}}',
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS player_items(
  id {_PK}, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  shop_item_id INTEGER NOT NULL REFERENCES shop_items(id) ON DELETE CASCADE,
  equipped INTEGER NOT NULL DEFAULT 0, acquired_at TEXT NOT NULL,
  UNIQUE(user_id, shop_item_id))""",
    f"""CREATE TABLE IF NOT EXISTS rank_perks(
  rank TEXT NOT NULL, perk_key TEXT NOT NULL, perk_value TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '', PRIMARY KEY(rank, perk_key))""",
    f"""CREATE TABLE IF NOT EXISTS achievements(
  id {_PK}, akey TEXT NOT NULL UNIQUE, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  xp_reward INTEGER NOT NULL DEFAULT 0, points_reward INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1)""",
    f"""CREATE TABLE IF NOT EXISTS player_achievements(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  achievement_id INTEGER NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  unlocked_at TEXT NOT NULL, PRIMARY KEY(user_id, achievement_id))""",
    f"""CREATE TABLE IF NOT EXISTS weekly_events(
  id {_PK}, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, min_rank TEXT NOT NULL DEFAULT 'none')""",
    f"""CREATE TABLE IF NOT EXISTS event_stages(
  id {_PK}, event_id INTEGER NOT NULL REFERENCES weekly_events(id) ON DELETE CASCADE,
  stage_no INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  reward_points INTEGER NOT NULL CHECK(reward_points >= 0), repeatable INTEGER NOT NULL DEFAULT 0,
  UNIQUE(event_id, stage_no))""",
    f"""CREATE TABLE IF NOT EXISTS event_claims(
  id {_PK}, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  stage_id INTEGER NOT NULL REFERENCES event_stages(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL DEFAULT 1, evidence TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL CHECK(status IN('pending','approved','rejected')),
  points_awarded INTEGER NOT NULL DEFAULT 0, reviewed_by INTEGER, created_at TEXT NOT NULL, reviewed_at TEXT)""",
    f"""CREATE TABLE IF NOT EXISTS shop_discounts(
  id {_PK}, item_id INTEGER NOT NULL REFERENCES shop_items(id) ON DELETE CASCADE,
  pct INTEGER NOT NULL CHECK(pct BETWEEN 1 AND 90), starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS rank_rewards(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rank TEXT NOT NULL CHECK(rank IN('bronze','silver','gold')), points INTEGER NOT NULL,
  granted_at TEXT NOT NULL, PRIMARY KEY(user_id, rank))""",
    f"""CREATE TABLE IF NOT EXISTS game_views(
  game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  viewer TEXT NOT NULL, day TEXT NOT NULL, PRIMARY KEY(game_id, viewer, day))""",
    "CREATE INDEX IF NOT EXISTS idx_claims_user_stage ON event_claims(user_id, stage_id)",
    "CREATE INDEX IF NOT EXISTS idx_stages_event ON event_stages(event_id)",
    "CREATE INDEX IF NOT EXISTS idx_discounts_item ON shop_discounts(item_id)",
    "CREATE INDEX IF NOT EXISTS idx_reviews_game ON reviews(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_tickets_user ON support_tickets(user_id)",
    "CREATE INDEX IF NOT EXISTS idx_contacts_game ON dev_contacts(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_contacts_dev ON dev_contacts(dev_id)",
    "CREATE INDEX IF NOT EXISTS idx_msgs_contact ON dev_messages(contact_id)",
]

# v3 tables: audit/security log, runtime settings, version history, real download + play events.
# download_events / play_events / audit_log deliberately have NO foreign keys so history survives deletions.
_V3_TABLES = [
    f"""CREATE TABLE IF NOT EXISTS audit_log(
  id {_PK}, ts TEXT NOT NULL, day TEXT NOT NULL, category TEXT NOT NULL, actor_type TEXT NOT NULL DEFAULT 'system',
  actor TEXT, action TEXT NOT NULL, target TEXT, detail TEXT, ip TEXT)""",
    "CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)",
    f"""CREATE TABLE IF NOT EXISTS game_versions(
  id {_PK}, game_id INTEGER NOT NULL REFERENCES games(id) ON DELETE CASCADE, version TEXT NOT NULL,
  notes TEXT, build TEXT, build_size BIGINT NOT NULL DEFAULT 0, created_at TEXT NOT NULL, created_by INTEGER)""",
    f"""CREATE TABLE IF NOT EXISTS download_events(
  id {_PK}, game_id INTEGER NOT NULL, user_id INTEGER, ts TEXT NOT NULL, day TEXT NOT NULL)""",
    f"""CREATE TABLE IF NOT EXISTS play_events(
  id {_PK}, game_id INTEGER NOT NULL, visitor TEXT NOT NULL, mode TEXT NOT NULL, ts TEXT NOT NULL, day TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts)",
    "CREATE INDEX IF NOT EXISTS idx_audit_cat ON audit_log(category, ts)",
    "CREATE INDEX IF NOT EXISTS idx_versions_game ON game_versions(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_dl_day ON download_events(day)",
    "CREATE INDEX IF NOT EXISTS idx_dl_game ON download_events(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_play_day ON play_events(day)",
    "CREATE INDEX IF NOT EXISTS idx_play_game ON play_events(game_id)",
    "CREATE INDEX IF NOT EXISTS idx_visits_game ON visits(game_id)",
]

# (table, column, definition) added to databases created by older versions. Idempotent.
_V3_COLUMNS = [
    ("games", "kind", "TEXT NOT NULL DEFAULT 'game'"),            # 'game' | 'app'
    ("games", "version", "TEXT"),
    ("games", "video_url", "TEXT"),
    ("games", "visibility", "TEXT NOT NULL DEFAULT 'public'"),    # 'public' | 'hidden' | 'paused' (owner-controlled)
    ("games", "scan_status", "TEXT"),                             # clean | suspicious | unscanned | infected
    ("games", "scan_note", "TEXT"),
    ("games", "updated_at", "TEXT"),
    ("users", "last_login_at", "TEXT"),
]


def _ensure_columns(c):
    if IS_PG:
        for table, col, ddl in _V3_COLUMNS:
            c.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {col} {ddl}")
        return
    have = {}
    for table, col, ddl in _V3_COLUMNS:
        if table not in have:
            have[table] = {r["name"] for r in c.execute(f"PRAGMA table_info({table})")}
        if col not in have[table]:
            c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")


def init_schema():
    c = connect()
    if IS_PG:                                   # several gunicorn workers may boot at once
        c.execute("SELECT pg_advisory_lock(727274)")
    try:
        for stmt in (PG_SCHEMA if IS_PG else SQLITE_SCHEMA) + _SHARED + _COMMON_TAIL:
            c.execute(stmt)
        if IS_PG:                               # upgrade a database created by an older version
            c.execute("ALTER TABLE games ADD COLUMN IF NOT EXISTS play_file TEXT")
            c.execute("ALTER TABLE games ADD COLUMN IF NOT EXISTS play_mode TEXT NOT NULL DEFAULT 'none'")
            c.execute("ALTER TABLE games ADD COLUMN IF NOT EXISTS requirements TEXT")
            c.execute("ALTER TABLE games ADD COLUMN IF NOT EXISTS slug TEXT")
        else:                                   # indexes below need these columns on very old SQLite files too
            have = {r["name"] for r in c.execute("PRAGMA table_info(games)")}
            for col in ("requirements", "slug", "play_file"):
                if col not in have:
                    c.execute(f"ALTER TABLE games ADD COLUMN {col} TEXT")
            if "play_mode" not in have:
                c.execute("ALTER TABLE games ADD COLUMN play_mode TEXT NOT NULL DEFAULT 'none'")
        _ensure_columns(c)
        for stmt in _V3_TABLES:
            c.execute(stmt)
        for stmt in _V4_TABLES:
            c.execute(stmt)
        # v7: events can require a minimum rank. Existing databases get the column added here.
        if IS_PG:
            c.execute("ALTER TABLE weekly_events ADD COLUMN IF NOT EXISTS min_rank TEXT NOT NULL DEFAULT 'none'")
        elif "min_rank" not in {r["name"] for r in c.execute("PRAGMA table_info(weekly_events)")}:
            c.execute("ALTER TABLE weekly_events ADD COLUMN min_rank TEXT NOT NULL DEFAULT 'none'")
        # ratings: allow half-star steps + review text (idempotent)
        if not IS_PG:
            cols = {r["name"] for r in c.execute("PRAGMA table_info(ratings)")}
            if "review_text" not in cols:
                c.execute("ALTER TABLE ratings ADD COLUMN review_text TEXT NOT NULL DEFAULT ''")
            if "updated_at" not in cols:
                c.execute("ALTER TABLE ratings ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''")
        else:
            c.execute("ALTER TABLE ratings ADD COLUMN IF NOT EXISTS review_text TEXT NOT NULL DEFAULT ''")
            c.execute("ALTER TABLE ratings ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''")
        c.commit()
    finally:
        if IS_PG:
            c.execute("SELECT pg_advisory_unlock(727274)")
            c.commit()
        c.close()
