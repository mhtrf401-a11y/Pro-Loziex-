"""Weekly game events and temporary store discounts.

Rules enforced on the server:
- No cap on total event points (no weekly/daily ceiling).
- A stage reward is granted only after an admin approves submitted evidence. A button press never grants points.
- Non-repeatable stages pay once per player. Repeatable stages pay once per approved completion.
- A player may have only one claim pending per stage at a time.
- Claims are accepted and approved only while the event window is open. Rejecting is allowed at any time.
- Developers cannot claim rewards for their own game.
- Discounts apply only inside their time window. Expired discounts stop applying; nothing is deleted.
- Each approval is guarded by a status check, so the same claim cannot pay twice.
"""
from datetime import datetime, timezone

import systems_v4 as S

MIN_EVIDENCE = 5
MAX_EVIDENCE = 1000
MAX_STAGE_REWARD = 10000
MAX_PCT = 90


def parse_ts(v):
    """Validate an ISO timestamp and return it normalised to UTC (sortable as text, same format as S.now())."""
    if not v or not isinstance(v, str):
        raise ValueError("timestamp required")
    d = datetime.fromisoformat(v.strip().replace("Z", "+00:00"))
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc).isoformat(timespec="seconds")


MIN_RANKS = ("none", "silver", "gold")


def validate_min_rank(v):
    """Returns the normalised rank, or None when invalid (callers turn None into a 400)."""
    v = str(v or "none").lower()
    return v if v in MIN_RANKS else None


def state_of(ev, ts=None):
    t = ts or S.now()
    if t < ev["starts_at"]:
        return "upcoming"
    if t >= ev["ends_at"]:
        return "ended"
    return "active"


def register(app, *, db, current_user, login_required, body, ApiError, audit):
    from flask import jsonify, request

    def me():
        u = current_user()
        if not u:
            raise ApiError("Please sign in first", 401)
        return u

    def event_row(c, eid):
        ev = c.execute("SELECT * FROM weekly_events WHERE id=?", (eid,)).fetchone()
        if not ev:
            raise ApiError("Event not found", 404)
        return ev

    def stages_of(c, eid):
        return [dict(s) for s in c.execute(
            "SELECT * FROM event_stages WHERE event_id=? ORDER BY stage_no", (eid,)).fetchall()]

    def event_json(c, ev):
        d = dict(ev)
        d["active"] = bool(ev["active"])
        d["state"] = state_of(ev)
        d["stages"] = stages_of(c, ev["id"])
        return d

    def validate_event_fields(d, current=None):
        cur = current or {}
        title = str(d.get("title", cur.get("title", "")) or "").strip()
        if not 1 <= len(title) <= 120:
            raise ApiError("Title must be 1-120 characters")
        desc = str(d.get("description", cur.get("description", "")) or "")[:4000]
        try:
            starts = parse_ts(d.get("starts_at", cur.get("starts_at")))
            ends = parse_ts(d.get("ends_at", cur.get("ends_at")))
        except (ValueError, TypeError):
            raise ApiError("starts_at and ends_at must be ISO timestamps")
        if ends <= starts:
            raise ApiError("ends_at must be after starts_at")
        return title, desc, starts, ends

    # ============================================================ public: events
    @app.get("/api/events")
    def ev_list():
        c = db()
        rows = c.execute(
            "SELECT e.*, g.title AS game_title, g.cover AS game_cover FROM weekly_events e "
            "JOIN games g ON g.id=e.game_id WHERE e.active=1 AND g.status='approved' AND g.visibility='public' "
            "ORDER BY e.starts_at DESC LIMIT 60").fetchall()
        out = []
        for r in rows:
            d = dict(r)
            d["state"] = state_of(r)
            d["stage_count"] = c.execute("SELECT COUNT(*) FROM event_stages WHERE event_id=?", (r["id"],)).fetchone()[0]
            out.append(d)
        return jsonify(events=out)

    @app.get("/api/events/<int:eid>")
    def ev_detail(eid):
        c = db()
        ev = event_row(c, eid)
        if not ev["active"]:
            raise ApiError("Event not found", 404)
        d = event_json(c, ev)
        g = c.execute("SELECT title, cover FROM games WHERE id=?", (ev["game_id"],)).fetchone()
        d["game_title"] = g["title"] if g else ""
        d["game_cover"] = g["cover"] if g else ""
        u = current_user()
        my_total = 0
        access = True
        if u:
            S.ensure_progress(c, u["id"])
            prank = c.execute("SELECT rank FROM player_progress WHERE user_id=?", (u["id"],)).fetchone()["rank"]
            access = S.rank_meets(prank, ev["min_rank"])
        d["my_access"] = access
        d["required_rank"] = ev["min_rank"]
        for s in d["stages"]:
            s["repeatable"] = bool(s["repeatable"])
            s["mine"] = {"approved": 0, "pending": 0, "points": 0, "can_claim": False}
            if u:
                rows = c.execute("SELECT status, points_awarded FROM event_claims WHERE user_id=? AND stage_id=?",
                                 (u["id"], s["id"])).fetchall()
                approved = sum(1 for x in rows if x["status"] == "approved")
                pending = sum(1 for x in rows if x["status"] == "pending")
                pts = sum(x["points_awarded"] for x in rows if x["status"] == "approved")
                my_total += pts
                can = (d["state"] == "active" and access and pending == 0 and
                       (s["repeatable"] or approved == 0))
                s["mine"] = {"approved": approved, "pending": pending, "points": pts, "can_claim": can}
        d["my_points"] = my_total
        return jsonify(event=d)

    @app.post("/api/events/stages/<int:sid>/claim")
    def ev_claim(sid):
        u = me()
        d = body()
        c = db()
        s = c.execute(
            "SELECT s.*, e.starts_at, e.ends_at, e.active AS ev_active, e.min_rank AS min_rank, g.dev_id FROM event_stages s "
            "JOIN weekly_events e ON e.id=s.event_id JOIN games g ON g.id=e.game_id WHERE s.id=?",
            (sid,)).fetchone()
        if not s or not s["ev_active"]:
            raise ApiError("Stage not found", 404)
        if s["dev_id"] == u["id"]:
            raise ApiError("Developers cannot claim rewards for their own game", 403)
        if state_of(s) != "active":
            raise ApiError("This event is not open", 409)
        S.ensure_progress(c, u["id"])
        prank = c.execute("SELECT rank FROM player_progress WHERE user_id=?", (u["id"],)).fetchone()["rank"]
        if not S.rank_meets(prank, s["min_rank"]):
            raise ApiError("This event is for %s and above" % s["min_rank"].capitalize(), 403)
        evidence = str(d.get("evidence") or "").strip()
        if not MIN_EVIDENCE <= len(evidence) <= MAX_EVIDENCE:
            raise ApiError("Describe how you completed the stage (5-1000 characters)")
        prior = c.execute("SELECT status FROM event_claims WHERE user_id=? AND stage_id=?",
                          (u["id"], sid)).fetchall()
        if any(x["status"] == "pending" for x in prior):
            raise ApiError("Your previous claim for this stage is still under review", 409)
        if not s["repeatable"] and any(x["status"] == "approved" for x in prior):
            raise ApiError("You already received the reward for this stage", 409)
        seq = len(prior) + 1
        c.execute("INSERT INTO event_claims(user_id,stage_id,seq,evidence,status,points_awarded,created_at) "
                  "VALUES(?,?,?,?, 'pending', 0, ?)", (u["id"], sid, seq, evidence, S.now()))
        c.commit()
        return jsonify(ok=True, status="pending"), 201

    # ============================================================ admin: events
    @app.get("/api/admin/events")
    @login_required("admin")
    def ev_admin_list():
        c = db()
        rows = c.execute("SELECT e.*, g.title AS game_title FROM weekly_events e JOIN games g ON g.id=e.game_id "
                         "ORDER BY e.starts_at DESC").fetchall()
        out = []
        for r in rows:
            j = event_json(c, r)
            j["game_title"] = r["game_title"]
            out.append(j)
        return jsonify(events=out)

    @app.post("/api/admin/events")
    @login_required("admin")
    def ev_create():
        d = body()
        try:
            gid = int(d.get("game_id"))
        except (TypeError, ValueError):
            raise ApiError("game_id required")
        c = db()
        if not c.execute("SELECT 1 FROM games WHERE id=?", (gid,)).fetchone():
            raise ApiError("Game not found", 404)
        title, desc, starts, ends = validate_event_fields(d)
        min_rank = validate_min_rank(d.get("min_rank", "none"))
        if min_rank is None:
            raise ApiError("min_rank must be none, silver or gold")
        eid = c.execute("INSERT INTO weekly_events(game_id,title,description,starts_at,ends_at,active,created_at,min_rank) "
                        "VALUES(?,?,?,?,?,1,?,?) RETURNING id", (gid, title, desc, starts, ends, S.now(), min_rank)).fetchone()[0]
        c.commit()
        audit("content", "event_create", target=eid, detail=title)
        return jsonify(ok=True, id=eid), 201

    @app.put("/api/admin/events/<int:eid>")
    @login_required("admin")
    def ev_update(eid):
        d = body()
        c = db()
        ev = event_row(c, eid)
        title, desc, starts, ends = validate_event_fields(d, dict(ev))
        active = 1 if d.get("active", bool(ev["active"])) else 0
        min_rank = validate_min_rank(d.get("min_rank", ev["min_rank"]))
        if min_rank is None:
            raise ApiError("min_rank must be none, silver or gold")
        c.execute("UPDATE weekly_events SET title=?,description=?,starts_at=?,ends_at=?,active=?,min_rank=? WHERE id=?",
                  (title, desc, starts, ends, active, min_rank, eid))
        c.commit()
        audit("content", "event_update", target=eid, detail=title)
        return jsonify(ok=True)

    @app.post("/api/admin/events/<int:eid>/stages")
    @login_required("admin")
    def ev_add_stage(eid):
        d = body()
        c = db()
        event_row(c, eid)
        title = str(d.get("title") or "").strip()
        if not 1 <= len(title) <= 120:
            raise ApiError("Stage title required (1-120 characters)")
        try:
            reward = int(d.get("reward_points"))
        except (TypeError, ValueError):
            raise ApiError("reward_points must be a whole number")
        if not 0 <= reward <= MAX_STAGE_REWARD:
            raise ApiError("reward_points must be 0-%d" % MAX_STAGE_REWARD)
        nxt = c.execute("SELECT COALESCE(MAX(stage_no),0)+1 FROM event_stages WHERE event_id=?", (eid,)).fetchone()[0]
        c.execute("INSERT INTO event_stages(event_id,stage_no,title,description,reward_points,repeatable) "
                  "VALUES(?,?,?,?,?,?)",
                  (eid, nxt, title, str(d.get("description") or "")[:2000], reward,
                   1 if d.get("repeatable") else 0))
        c.commit()
        audit("content", "event_stage_add", target=eid, detail=title)
        return jsonify(ok=True), 201

    @app.put("/api/admin/stages/<int:sid>")
    @login_required("admin")
    def ev_update_stage(sid):
        d = body()
        c = db()
        s = c.execute("SELECT * FROM event_stages WHERE id=?", (sid,)).fetchone()
        if not s:
            raise ApiError("Stage not found", 404)
        title = str(d.get("title", s["title"]) or "").strip()
        if not 1 <= len(title) <= 120:
            raise ApiError("Stage title required (1-120 characters)")
        try:
            reward = int(d.get("reward_points", s["reward_points"]))
        except (TypeError, ValueError):
            raise ApiError("reward_points must be a whole number")
        if not 0 <= reward <= MAX_STAGE_REWARD:
            raise ApiError("reward_points must be 0-%d" % MAX_STAGE_REWARD)
        rep = 1 if d.get("repeatable", bool(s["repeatable"])) else 0
        c.execute("UPDATE event_stages SET title=?,description=?,reward_points=?,repeatable=? WHERE id=?",
                  (title, str(d.get("description", s["description"]) or "")[:2000], reward, rep, sid))
        c.commit()
        audit("content", "event_stage_update", target=sid, detail=title)
        return jsonify(ok=True)

    # ============================================================ admin: claim review
    @app.get("/api/admin/claims")
    @login_required("admin")
    def ev_admin_claims():
        status = request.args.get("status", "pending")
        if status not in ("pending", "approved", "rejected", "all"):
            raise ApiError("status must be pending, approved, rejected or all")
        q = ("SELECT cl.id, cl.status, cl.evidence, cl.created_at, cl.points_awarded, cl.user_id, "
             "u.name AS user_name, s.id AS stage_id, s.title AS stage_title, s.reward_points, "
             "e.id AS event_id, e.title AS event_title, e.starts_at, e.ends_at FROM event_claims cl "
             "JOIN users u ON u.id=cl.user_id JOIN event_stages s ON s.id=cl.stage_id "
             "JOIN weekly_events e ON e.id=s.event_id")
        params = ()
        if status != "all":
            q += " WHERE cl.status=?"
            params = (status,)
        q += " ORDER BY cl.created_at DESC LIMIT 200"
        rows = db().execute(q, params).fetchall()
        out = []
        for r in rows:
            j = dict(r)
            j["event_state"] = state_of(r)
            out.append(j)
        return jsonify(claims=out)

    @app.post("/api/admin/claims/<int:cid>/review")
    @login_required("admin")
    def ev_review(cid):
        d = body()
        action = d.get("action")
        if action not in ("approve", "reject"):
            raise ApiError("action must be approve or reject")
        c = db()
        cl = c.execute(
            "SELECT cl.*, s.reward_points, s.repeatable, s.event_id, e.starts_at, e.ends_at, e.active AS ev_active "
            "FROM event_claims cl JOIN event_stages s ON s.id=cl.stage_id "
            "JOIN weekly_events e ON e.id=s.event_id WHERE cl.id=?", (cid,)).fetchone()
        if not cl:
            raise ApiError("Claim not found", 404)
        if cl["status"] != "pending":
            raise ApiError("This claim was already reviewed", 409)
        reviewer = current_user()
        ts = S.now()
        if action == "reject":
            c.execute("UPDATE event_claims SET status='rejected', reviewed_by=?, reviewed_at=? "
                      "WHERE id=? AND status='pending'", (reviewer["id"], ts, cid))
            c.commit()
            audit("content", "event_claim_reject", target=cid)
            return jsonify(ok=True, status="rejected")

        if not cl["ev_active"] or state_of(cl) != "active":
            raise ApiError("The event window is closed, so this claim cannot be approved", 409)
        if not cl["repeatable"] and c.execute(
                "SELECT 1 FROM event_claims WHERE user_id=? AND stage_id=? AND status='approved'",
                (cl["user_id"], cl["stage_id"])).fetchone():
            raise ApiError("This player already received the reward for this stage", 409)
        pts = int(cl["reward_points"])
        cur = c.execute("UPDATE event_claims SET status='approved', points_awarded=?, reviewed_by=?, reviewed_at=? "
                        "WHERE id=? AND status='pending'", (pts, reviewer["id"], ts, cid))
        if getattr(cur, "rowcount", 1) == 0:
            raise ApiError("This claim was already reviewed", 409)
        if pts > 0:
            S.add_points(c, cl["user_id"], pts, "event:%d:claim:%d" % (cl["event_id"], cid))
        c.commit()
        audit("content", "event_claim_approve", target=cid, detail="%d points" % pts)
        return jsonify(ok=True, status="approved", points=pts)

    # ============================================================ admin: discounts
    def discount_row(c, did):
        r = c.execute("SELECT d.*, i.name_en, i.price AS base_price FROM shop_discounts d "
                      "JOIN shop_items i ON i.id=d.item_id WHERE d.id=?", (did,)).fetchone()
        if not r:
            raise ApiError("Discount not found", 404)
        return r

    @app.get("/api/admin/discounts")
    @login_required("admin")
    def disc_list():
        rows = db().execute("SELECT d.*, i.name_en, i.price AS base_price, i.store FROM shop_discounts d "
                            "JOIN shop_items i ON i.id=d.item_id ORDER BY d.starts_at DESC").fetchall()
        out = []
        for r in rows:
            j = dict(r)
            j["state"] = state_of(r)
            out.append(j)
        return jsonify(discounts=out)

    @app.post("/api/admin/discounts")
    @login_required("admin")
    def disc_create():
        d = body()
        c = db()
        try:
            item_id = int(d.get("item_id"))
            pct = int(d.get("pct"))
        except (TypeError, ValueError):
            raise ApiError("item_id and pct (whole numbers) are required")
        if not 1 <= pct <= MAX_PCT:
            raise ApiError("pct must be 1-%d" % MAX_PCT)
        if not c.execute("SELECT 1 FROM shop_items WHERE id=?", (item_id,)).fetchone():
            raise ApiError("Item not found", 404)
        try:
            starts = parse_ts(d.get("starts_at"))
            ends = parse_ts(d.get("ends_at"))
        except (ValueError, TypeError):
            raise ApiError("starts_at and ends_at must be ISO timestamps")
        if ends <= starts:
            raise ApiError("ends_at must be after starts_at")
        c.execute("INSERT INTO shop_discounts(item_id,pct,starts_at,ends_at,active,created_at) VALUES(?,?,?,?,1,?)",
                  (item_id, pct, starts, ends, S.now()))
        c.commit()
        audit("content", "discount_create", target=item_id, detail="%d%%" % pct)
        return jsonify(ok=True), 201

    @app.put("/api/admin/discounts/<int:did>")
    @login_required("admin")
    def disc_update(did):
        d = body()
        c = db()
        r = discount_row(c, did)
        pct = int(d.get("pct", r["pct"]))
        if not 1 <= pct <= MAX_PCT:
            raise ApiError("pct must be 1-%d" % MAX_PCT)
        try:
            starts = parse_ts(d.get("starts_at", r["starts_at"]))
            ends = parse_ts(d.get("ends_at", r["ends_at"]))
        except (ValueError, TypeError):
            raise ApiError("starts_at and ends_at must be ISO timestamps")
        if ends <= starts:
            raise ApiError("ends_at must be after starts_at")
        active = 1 if d.get("active", bool(r["active"])) else 0
        c.execute("UPDATE shop_discounts SET pct=?,starts_at=?,ends_at=?,active=? WHERE id=?",
                  (pct, starts, ends, active, did))
        c.commit()
        audit("content", "discount_update", target=did, detail="active=%d" % active)
        return jsonify(ok=True)

    @app.get("/api/admin/shop-items")
    @login_required("admin")
    def admin_shop_items():
        rows = db().execute("SELECT id, store, name_en, price, active FROM shop_items ORDER BY store, price").fetchall()
        return jsonify(items=[dict(r) for r in rows])
