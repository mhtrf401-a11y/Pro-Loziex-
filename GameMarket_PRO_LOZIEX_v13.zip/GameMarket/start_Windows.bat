@echo off
title GameMarket
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 goto nopython

echo Installing the required packages - first run only, this can take a minute...
python -m pip install -q -r requirements.txt
if errorlevel 1 goto failed

set ADMIN_EMAIL=admin@local.test
set ADMIN_PASSWORD=admin-local-123
set SECRET_KEY=local-test-secret-key-change-me-0123456789
set HOST=127.0.0.1
set PORT=5000

echo.
echo ==========================================================
echo  GameMarket is starting at http://127.0.0.1:5000
echo  Admin login:  admin@local.test  /  admin-local-123
echo  Admin panel:  http://127.0.0.1:5000/admin
echo  Keep this window open while you browse. Close it to stop.
echo ==========================================================
echo.
start "" http://127.0.0.1:5000
python app.py
pause
exit /b 0

:nopython
echo Python is not installed on this computer.
echo Install it once from https://www.python.org/downloads/
echo During installation tick "Add Python to PATH", then run this file again.
pause
exit /b 1

:failed
echo Could not install the packages. Check your internet connection and try again.
pause
exit /b 1
