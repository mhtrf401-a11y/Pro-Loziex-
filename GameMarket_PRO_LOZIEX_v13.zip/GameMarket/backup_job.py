"""One-shot database backup, for a Render Cron Job (or any scheduler):  python backup_job.py
Uses the same environment as the web service (DATABASE_URL, S3_*, ...). Safe to run while the site is live."""
import os

os.environ.setdefault("GM_BACKGROUND", "0")       # do not start the web app's own scheduler thread
import app  # noqa: E402

if __name__ == "__main__":
    print(app.owner_mod.make_backup("cron"))
