"""File storage: local disk by default, or any S3-compatible bucket (Cloudflare R2, Backblaze B2, ...).

Set S3_ENDPOINT_URL, S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY (and optionally S3_REGION)
to switch to the bucket. Images are served through the app (cached); game files are never public:
downloads are permission-checked by the app, then redirected to a short-lived signed URL.
"""
import logging
import os
import shutil
import tempfile
import time
from pathlib import Path

from flask import Response, abort, redirect, send_file, send_from_directory

log = logging.getLogger("gamemarket.storage")
IMG_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".webp": "image/webp"}


class LocalStorage:
    kind = "local"

    def __init__(self, root):
        self.covers, self.builds, self.plays = root / "covers", root / "builds", root / "plays"
        self.backups = root.parent / "backups"
        for p in (self.covers, self.builds, self.plays, self.backups):
            p.mkdir(parents=True, exist_ok=True)

    def put_cover(self, name, data):
        (self.covers / name).write_bytes(data)

    def put_build(self, name, tmp_path):
        os.replace(tmp_path, self.builds / name)

    def put_play(self, name, tmp_path):
        os.replace(tmp_path, self.plays / name)

    def delete_play(self, name):
        (self.plays / name).unlink(missing_ok=True)

    def play_local_path(self, name):
        return self.plays / name

    def delete_cover(self, name):
        (self.covers / name).unlink(missing_ok=True)

    def delete_build(self, name):
        (self.builds / name).unlink(missing_ok=True)

    def cover_response(self, name):
        return send_from_directory(self.covers, name)

    def build_response(self, name, download_name):
        return send_file(self.builds / name, as_attachment=True, download_name=download_name)

    # ---- backups (JSON dumps of the database) ----
    def put_backup(self, name, tmp_path):
        os.replace(tmp_path, self.backups / name)

    def list_backups(self):
        out = [{"name": p.name, "size": p.stat().st_size, "modified": p.stat().st_mtime}
               for p in self.backups.glob("gamemarket-*.json.gz")]
        return sorted(out, key=lambda x: x["name"], reverse=True)

    def backup_response(self, name):
        return send_file(self.backups / name, as_attachment=True, download_name=name, mimetype="application/gzip")

    def delete_backup(self, name):
        (self.backups / name).unlink(missing_ok=True)

    def usage(self):
        def tree(p):
            return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
        parts = {"covers": tree(self.covers), "builds": tree(self.builds), "plays": tree(self.plays),
                 "backups": tree(self.backups)}
        du = shutil.disk_usage(self.covers)
        return {"kind": "local", "used": sum(parts.values()), "parts": parts,
                "capacity": du.total, "free": du.free, "capacity_note": "disk"}


class S3Storage:
    kind = "s3"

    def __init__(self):
        import boto3
        from botocore.config import Config
        self.bucket = os.environ["S3_BUCKET"]
        self.client = boto3.client(
            "s3", endpoint_url=os.environ["S3_ENDPOINT_URL"],
            aws_access_key_id=os.environ["S3_ACCESS_KEY_ID"],
            aws_secret_access_key=os.environ["S3_SECRET_ACCESS_KEY"],
            region_name=os.environ.get("S3_REGION", "auto"),
            config=Config(signature_version="s3v4", retries={"max_attempts": 3}))
        self._cache = Path(tempfile.gettempdir()) / "gm_play_cache"
        self._cache.mkdir(parents=True, exist_ok=True)
        self._usage = (0.0, None)

    def put_cover(self, name, data):
        ctype = IMG_TYPES.get(Path(name).suffix.lower(), "application/octet-stream")
        self.client.put_object(Bucket=self.bucket, Key="covers/" + name, Body=data, ContentType=ctype)

    def put_build(self, name, tmp_path):
        try:
            self.client.upload_file(str(tmp_path), self.bucket, "builds/" + name)
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def put_play(self, name, tmp_path):
        try:
            self.client.upload_file(str(tmp_path), self.bucket, "plays/" + name)
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def delete_play(self, name):
        self._delete("plays/" + name)
        (self._cache / name).unlink(missing_ok=True)

    def play_local_path(self, name):
        """HTML games are read from a ZIP, so keep a local cached copy of the bucket object."""
        p = self._cache / name
        if not p.exists():
            tmp = self._cache / (name + ".part")
            self.client.download_file(self.bucket, "plays/" + name, str(tmp))
            os.replace(tmp, p)
        return p

    def _delete(self, key):
        try:
            self.client.delete_object(Bucket=self.bucket, Key=key)
        except Exception:
            log.exception("Could not delete %s", key)

    def delete_cover(self, name):
        self._delete("covers/" + name)

    def delete_build(self, name):
        self._delete("builds/" + name)

    def cover_response(self, name):
        try:
            obj = self.client.get_object(Bucket=self.bucket, Key="covers/" + name)
        except Exception:
            abort(404)
        return Response(obj["Body"].read(), mimetype=IMG_TYPES.get(Path(name).suffix.lower(), "application/octet-stream"))

    def build_response(self, name, download_name):
        url = self.client.generate_presigned_url(
            "get_object", ExpiresIn=60,
            Params={"Bucket": self.bucket, "Key": "builds/" + name,
                    "ResponseContentDisposition": f'attachment; filename="{download_name}"'})
        return redirect(url)


    # ---- backups (JSON dumps of the database) ----
    def put_backup(self, name, tmp_path):
        try:
            self.client.upload_file(str(tmp_path), self.bucket, "backups/" + name)
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def list_backups(self):
        out = []
        for page in self.client.get_paginator("list_objects_v2").paginate(Bucket=self.bucket, Prefix="backups/"):
            for o in page.get("Contents", []):
                n = o["Key"][len("backups/"):]
                if n.startswith("gamemarket-") and n.endswith(".json.gz"):
                    out.append({"name": n, "size": o["Size"], "modified": o["LastModified"].timestamp()})
        return sorted(out, key=lambda x: x["name"], reverse=True)

    def backup_response(self, name):
        url = self.client.generate_presigned_url(
            "get_object", ExpiresIn=60,
            Params={"Bucket": self.bucket, "Key": "backups/" + name,
                    "ResponseContentDisposition": f'attachment; filename="{name}"',
                    "ResponseContentType": "application/gzip"})
        return redirect(url)

    def delete_backup(self, name):
        self._delete("backups/" + name)

    def usage(self):
        """Bucket usage by prefix (cached 10 minutes). Cloudflare R2 has no quota API: set STORAGE_QUOTA_BYTES."""
        ts, cached = self._usage
        if cached is None or time.time() - ts > 600:
            parts = {"covers": 0, "builds": 0, "plays": 0, "backups": 0, "other": 0}
            for page in self.client.get_paginator("list_objects_v2").paginate(Bucket=self.bucket):
                for o in page.get("Contents", []):
                    k = o["Key"].split("/", 1)[0]
                    parts[k if k in parts else "other"] += o["Size"]
            cached = parts
            self._usage = (time.time(), cached)
        quota = int(os.environ.get("STORAGE_QUOTA_BYTES", "0") or 0)
        used = sum(cached.values())
        return {"kind": "s3", "used": used, "parts": cached, "capacity": quota or None,
                "free": (quota - used) if quota else None, "capacity_note": "STORAGE_QUOTA_BYTES" if quota else "not configured"}



def make_storage(local_root):
    if all(os.environ.get(k) for k in ("S3_ENDPOINT_URL", "S3_BUCKET", "S3_ACCESS_KEY_ID", "S3_SECRET_ACCESS_KEY")):
        return S3Storage()
    return LocalStorage(local_root)
